/*
 * Copyright (c) 2010 Martin Aigner, Andreas Haas, Stephanie Stroka
 * http://cs.uni-salzburg.at/~maigner
 * http://cs.uni-salzburg.at/~ahaas
 * http://cs.uni-salzburg.at/~sstroka
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <string.h>
#include <unistd.h>

#ifndef REGMALLOC_H_
#define REGMALLOC_H_

#ifndef REGION_PAGE_SIZE
#define REGION_PAGE_SIZE 4096
#endif /* REGION_PAGE_SIZE */

/* The max. amount of memory that fits into a region page */
#define REGION_PAGE_PAYLOAD_SIZE (REGION_PAGE_SIZE - sizeof(void*) - sizeof(size_t))

typedef struct region region_t;
typedef struct region_page region_page_t;

/**
 * region_page contains a pointer to the next region_page,
 * a field for counting the amount of used memory and a
 * memory chunk. region_page is allocated page-aligned.
 */
struct region_page {
    region_page_t* nextPage;
    unsigned long used_memory;
    char memory[REGION_PAGE_PAYLOAD_SIZE];
};

/**
 * region contains the descriptor counter for the SCM implementation,
 * a field to count the amount of region pages and pointers to the
 * first and last region page.
 */
struct region {
    unsigned long dc;
    unsigned long number_of_region_pages;
    region_page_t* firstPage;
    region_page_t* lastPage;
    unsigned int age;
};


#endif /* REGMALLOC_H_ */
