/*
 * Copyright (c) 2010 Martin Aigner, Andreas Haas, Stephanie Stroka
 * http://cs.uni-salzburg.at/~maigner
 * http://cs.uni-salzburg.at/~ahaas
 * http://cs.uni-salzburg.at/~sstroka
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#ifndef HASHTABLE_H_
#define HASHTABLE_H_

typedef struct _node{
	char *name;
	char *desc;
	struct _node *next;
} node;

#define HASHSIZE 101

/**
 * inithashtab() creates, initializes and returns a new hashtable
 */
extern node** inithashtab();

/**
 * get() returns the value for the given key
 */
extern char* get(node** hashtab, char* name);

/**
 * put() inserts a value for a given key
 */
extern int put(node** hashtab, char* name,char* desc);

/**
 * rem() removes the entry for a given key
 */
extern void rem(node** hashtab, char* name);

/**
 * cleanup() removes all hashtable entries
 */
extern void cleanup(node** hashtab);

/**
 * A pretty useless but good debugging function,
 * which simply displays the hashtable in (key.value) pairs
 */
extern void displaytable(node** hashtab);

#endif /* HASHTABLE_H_ */
