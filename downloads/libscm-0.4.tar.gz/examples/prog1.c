/*
 * Copyright (c) 2011 Martin Aigner, Andreas Haas, Stephanie Stroka
 * http://cs.uni-salzburg.at/~maigner
 * http://cs.uni-salzburg.at/~ahaas
 * http://cs.uni-salzburg.at/~sstroka
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdlib.h>
#include "stm.h"
#include <stdio.h>

void *pointer2 = NULL;

void use_some_memory() {
	//this pointer is only used within this scope
	void *pointer1 = scm_malloc(10);
	//let pointer1 expire after this round
	scm_refresh(pointer1, 0);
	
	if (pointer2 != NULL) {
		//memory at pointer2 from previous round
		//.. do something with pointer2
	}
	//create new memory for pointer2
	pointer2 = scm_malloc(20);
	//refresh pointer2 to be vaid in the next round
	scm_refresh(pointer2, 1);
}

int main(int argc, char** argv) {

	const int region_index = scm_create_region();
	void* ptr = scm_malloc_in_region(10, region_index);

	int i;
	
	for (i = 0; i < 10; i++) {
		//...
		use_some_memory();
		scm_tick();
		//...
	}
	
	printf("success\n");
	return 0;
}
