#!/bin/bash

export LD_LIBRARY_PATH=../dist 
./prog1
./prog2
./prog3
