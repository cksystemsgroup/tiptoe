/*
 * Copyright (c) 2011 Martin Aigner, Andreas Haas, Stephanie Stroka
 * http://cs.uni-salzburg.at/~maigner
 * http://cs.uni-salzburg.at/~ahaas
 * http://cs.uni-salzburg.at/~sstroka
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "stm.h"
#include "scm-desc.h"
#include "regmalloc.h"
#include "meter.h"
#include "arch.h"


#ifdef SCM_PRINTMEM
#include <malloc.h>
#endif //SCM_PRINTMEM

static descriptor_page_t *new_descriptor_page();

static inline void recycle_descriptor_page(descriptor_page_t *page);

/**
 * Recycles a region in O(1) by pooling
 * the list of free region_pages except the
 * first region page iff the region_page_pool
 * limit is not exceeded, otherwise the region_pages
 * except the first one are deallocated and
 * the memory is handed back to the OS in O(n),
 * n = amount of region pages - 1.
 *
 * The remaining first region page indicates that the region
 * once existed, which is necessary to differentiate
 * it from regions which have not yet been used.
 * This indicates how many not-yet-used regions
 * are available.
 * Returns if no or just one region_page
 * has been allocated in the region.
 */
static void recycle_region(region_t* region);

static void* get_expired_mem(
    expired_descriptor_page_list_t *list);

static descriptor_page_t *new_descriptor_page() {

    descriptor_root_t *descriptor_root = get_descriptor_root();
    descriptor_page_t *new_page = NULL;

    if (descriptor_root->number_of_pooled_descriptor_pages > 0) {
        descriptor_root->number_of_pooled_descriptor_pages--;
        new_page = descriptor_root->descriptor_page_pool
                   [descriptor_root->number_of_pooled_descriptor_pages];
#ifdef SCM_PRINTMEM
        dec_pooled_mem(sizeof (descriptor_page_t));
#endif
    } else {

        new_page = __real_malloc(sizeof (descriptor_page_t));
        if (!new_page) {
            perror("new_descriptor_page");
            return NULL;
        }

#ifdef SCM_PRINTOVERHEAD
        inc_overhead(__real_malloc_usable_size(new_page));
#endif
#ifdef SCM_PRINTMEM
        printf("descriptor page size: %lu\n", sizeof(descriptor_page_t));
        inc_allocated_mem(sizeof(descriptor_page_t));
#endif
    }
    new_page->number_of_descriptors = 0;
    new_page->next = NULL;
    return new_page;
}

static inline void recycle_descriptor_page(descriptor_page_t *page) {

    descriptor_root_t *descriptor_root = get_descriptor_root();

    if (descriptor_root->number_of_pooled_descriptor_pages <
            SCM_DESCRIPTOR_PAGE_FREELIST_SIZE) {
        descriptor_root->descriptor_page_pool
        [descriptor_root->number_of_pooled_descriptor_pages] = page;
        descriptor_root->number_of_pooled_descriptor_pages++;
#ifdef SCM_PRINTMEM
        inc_pooled_mem(sizeof(descriptor_page_t));
#endif
    } else {
#ifdef SCM_PRINTOVERHEAD
        dec_overhead(__real_malloc_usable_size(page));
#endif
#ifdef SCM_PRINTMEM
        inc_freed_mem(__real_malloc_usable_size(page));
#endif
        __real_free(page);
    }
}

/**
 * Recycles a region in O(1) by pooling
 * the list of free region_pages except the
 * first region page iff the region_page_pool
 * limit is not exceeded, otherwise the region_pages
 * except the first one are deallocated and
 * the memory is handed back to the OS in O(n),
 * n = amount of region pages - 1.
 *
 * The remaining first region page indicates that the region
 * once existed, which is necessary to differentiate
 * it from regions which have not yet been used.
 * This indicates how many not-yet-used regions
 * are available.
 */
static void recycle_region(region_t* region) {
#ifdef SCM_DEBUG
    printf("Recycle region: %lx \n", (unsigned long) region);
#endif

// check pre-conditions
#ifdef SCM_CHECK_CONDITIONS
    if (region == NULL) {
        perror("NULL region should not appear in the descriptor buffers\n");
        return;
    } else if (region->firstPage == NULL || region->lastPage == NULL) {
        perror("Descriptor points to a region which was not correctly initialized\n");
        return;
    }

    if (region->dc != 0) {
        perror("Region seems to be still alive\n");
        return;
    }
    region_t* invar_region = region;
#endif

    descriptor_root_t* descriptor_root = get_descriptor_root();
    region_page_t* legacy_pages;

    unsigned long number_of_recycle_region_pages;

    // if the region has been used in the current thread...
    if (region->age == descriptor_root->current_time) {
        //.. recycle everything except the first page
        region_page_t* firstPage = region->firstPage;
        legacy_pages = firstPage->nextPage;
        memset(firstPage, 0, REGION_PAGE_SIZE);

        // nothing to put into the pool
        if (legacy_pages == NULL) {

// check post-conditions
#ifdef SCM_CHECK_CONDITIONS
            if (region->number_of_region_pages != 1) {
                perror("Number of region pages is not one, but only one region page exists\n");
                return;
            } else {
                if (region->firstPage != region->lastPage) {
                    perror("Last region page is not equal to first region page, but only one region page exists\n");
                    return;
                }
                if (region != invar_region) {
                    perror("The region changed during recycling\n");
                    return;
                }
            }
#endif
            region->dc = 0;
            return;
        }

        number_of_recycle_region_pages =
            region->number_of_region_pages - 1;

    }
    // if the region was a zombie in the current thread...
    else {

#ifdef SCM_DEBUG
        printf("Region expired\n");
#endif
        //.. recycle everything, also the first page
        legacy_pages = region->firstPage;

        // nothing to put into the pool
        if (legacy_pages == NULL) {

// check post-conditions
#ifdef SCM_CHECK_CONDITIONS
            if (region->number_of_region_pages != 0) {
                perror("Number of region pages is not zero, no region pages exist\n");
                return;
            } else {
                if (region->firstPage != region->lastPage) {
                    perror("Last region page is not equal to first region page, but only one region page exists\n");
                    return;
                }
                if (region != invar_region) {
                    perror("The region changed during recycling\n");
                    return;
                }
            }
#endif
            region->dc = 0;
            return;
        }

        number_of_recycle_region_pages =
            region->number_of_region_pages;
    }

    unsigned long number_of_pooled_region_pages =
        descriptor_root->number_of_pooled_region_pages;

    if ((number_of_pooled_region_pages
            + number_of_recycle_region_pages) <
            SCM_REGION_PAGE_FREELIST_SIZE) {
        region_page_t* first_in_pool = descriptor_root->region_page_pool;
        region_page_t* last_page = region->lastPage;
        last_page->nextPage = first_in_pool;
        descriptor_root->region_page_pool = legacy_pages;

#ifdef SCM_PRINTMEM
        printf("Pooling %lu bytes\n", number_of_recycle_region_pages * REGION_PAGE_SIZE);
        inc_pooled_mem(number_of_recycle_region_pages * REGION_PAGE_SIZE);
#endif

    } else {
        size_t freed_bytes = 0;

        // If the first region page is not NULL,
        // deallocate all region pages
        region_page_t* page2free = legacy_pages;
        while (page2free != NULL) {
            freed_bytes += REGION_PAGE_SIZE;
            region_page_t* next = page2free->nextPage;
            __real_free(page2free);
            page2free = next;
        }

#ifdef SCM_PRINTMEM
        inc_freed_mem(freed_bytes);
#endif
    }

    if (region->age == descriptor_root->current_time) {
        region->number_of_region_pages = 1;
        region->lastPage = region->firstPage;

#ifdef SCM_CHECK_CONDITIONS
        if (region->number_of_region_pages != 1) {
            perror("Number of region pages is not one, but only one region page exists\n");
            return;
        } else {
            if (region->firstPage != region->lastPage) {
                perror("Last region page is not equal to first region page, but only one region page exists\n");
                return;
            }
            if (region != invar_region) {
                perror("The region changed during recycling\n");
                return;
            }
        }
#endif
    } else {
        region->number_of_region_pages = 0;
        region->lastPage = region->firstPage = NULL;

#ifdef SCM_CHECK_CONDITIONS
        if (region->number_of_region_pages != 0) {
            perror("Number of region pages is not zero, but no region pages exist\n");
            return;
        } else {
            if (region->firstPage != NULL) {
                perror("First page is not null as expected\n");
                return;
            }
            if (region != invar_region) {
                perror("The region changed during recycling\n");
                return;
            }
        }
#endif
    }
}


/**
 * get_expired_mem() returns an expired
 * object or region from the expired descriptor page
 */
static void* get_expired_mem(
    expired_descriptor_page_list_t *list) {

    //remove from the first page
    descriptor_page_t *page = list->first;

    if (page == NULL) {
        //list is empty
        return NULL;
    }

#ifdef SCM_DEBUG
    printf("list->begin: %lu, p->num_of_desc: %lu\n", list->collected,
           page->number_of_descriptors);
#endif

    if (list->collected == page->number_of_descriptors) {
        //page has already been emptied
        //free this page and proceed with next one at index 0
        list->collected = 0;

        if (list->first == list->last) {
            //this was the last page in list

            recycle_descriptor_page(list->first);

            list->first = NULL;
            list->last = NULL;

            return NULL;
        } else {
            //there are more pages left
            page = list->first->next;

            recycle_descriptor_page(list->first);

            list->first = page;
        }
    }

#ifdef SCM_DEBUG
    if (list->collected == page->number_of_descriptors) {
        printf("more than one empty page in list\n");
        return NULL;
    }
#endif

    void* expired_mem = page->descriptors[list->collected];
    list->collected++;
    return expired_mem;
}

/*
 * this function returns 0 iff no more expired object descriptors exist.
 */
int expire_obj_descriptor_if_exists(expired_descriptor_page_list_t *list) {

// check pre-conditions
#ifdef SCM_CHECK_CONDITIONS
    if (list == NULL) {
        perror("Expired descriptor page list is NULL, but was expected to exist");
        return 0;
    }
#endif

    object_header_t *expired_object = (object_header_t*) get_expired_mem(list);
    if (expired_object != NULL) {

        if (atomic_int_dec_and_test((int*) & expired_object->dc_or_region_id)) {

            int finalizer_result = run_finalizer(expired_object);

            if (finalizer_result != 0) {
#ifdef SCM_DEBUG
                printf("WARNING: finalizer returned %d\n", finalizer_result);
                printf("WARNING: %lx is a leak\n",
                       (unsigned long) PAYLOAD_OFFSET(expired_object));
#endif
                return 1; //do not free the object
            }

#ifdef SCM_DEBUG
            printf("object FREE(%lx)\n",
                   (unsigned long) PAYLOAD_OFFSET(expired_object));
#endif

#ifdef SCM_PRINTOVERHEAD
            dec_overhead(sizeof (object_header_t));
#endif

#ifdef SCM_PRINTMEM
            inc_freed_mem(__real_malloc_usable_size(expired_object));
#endif
            __real_free(expired_object);
            return 1;

        } else {
#ifdef SCM_DEBUG
            printf("decrementing DC==%u\n", expired_object->dc_or_region_id);
#endif
            return 1;
        }
    } else {
#ifdef SCM_DEBUG
        printf("no expired object found\n");
#endif
        return 0;
    }
}

/*
 * This function returns 0 iff no more expired region descriptors exist.
 * Otherwise, the region pages are recycled.
 */
int expire_reg_descriptor_if_exists(expired_descriptor_page_list_t *list) {

// check pre-conditions
#ifdef SCM_CHECK_CONDITIONS
    if (list == NULL) {
        perror("Expired descriptor page list is NULL, but was expected to exist");
        return 0;
    }
#endif

    region_t* expired_region = (region_t*) get_expired_mem(list);
    if (expired_region != NULL) {

        if (atomic_int_dec_and_test((int*) & expired_region->dc)) {

#ifdef SCM_DEBUG
            printf("region FREE(%lx)\n",
                   (unsigned long) expired_region);
#endif

            recycle_region(expired_region);
            return 1;
        } else {
#ifdef SCM_DEBUG
            printf("decrementing DC==%lu\n", expired_region->dc);
#endif
            return 1;
        }
    } else {
#ifdef SCM_DEBUG
        printf("no expired object found\n");
#endif
        return 0;
    }
}


/*
 * insert_descriptor() inserts a descriptor for the object or region
 * provided as parameter 'ptr' */
void insert_descriptor(void* ptr, descriptor_buffer_t *buffer,
                       unsigned int expiration) {

    unsigned int insert_index = (buffer->current_index + expiration) %
                                buffer->not_expired_length;

    descriptor_page_list_t *list = &buffer->not_expired[insert_index];

    if (list->first == NULL) {
        list->first = new_descriptor_page();
        list->last = list->first;
    }

    //insert in the last page
    descriptor_page_t *page = list->last;

    if (page->number_of_descriptors == SCM_DESCRIPTORS_PER_PAGE) {
        //page is full. create new page and append to end of list
        page = new_descriptor_page();
        list->last->next = page;
        list->last = page;
    }

    page->descriptors[page->number_of_descriptors] = ptr;
    page->number_of_descriptors++;
}

/*
 * expire buffer operates always on the current_index-1 list of the buffer
 */
void expire_buffer(descriptor_buffer_t *buffer,
                   expired_descriptor_page_list_t *exp_list) {

    int to_be_expired_index = buffer->current_index - 1;
    if (to_be_expired_index < 0)
        to_be_expired_index += buffer->not_expired_length;

    descriptor_page_list_t *just_expired_page_list =
        &buffer->not_expired[to_be_expired_index];

    if (just_expired_page_list->first != NULL) {

        if (just_expired_page_list->first->number_of_descriptors != 0) {

            //append page_list to expired_page_list
            if (exp_list->first == NULL) {
                exp_list->first = just_expired_page_list->first;
                exp_list->last = just_expired_page_list->last;
                exp_list->collected = 0;
            } else {
                exp_list->last->next = just_expired_page_list->first;
                exp_list->last = just_expired_page_list->last;
            }

            //reset just_expired_page_list
            just_expired_page_list->first = NULL;
            just_expired_page_list->last = just_expired_page_list->first;
        }
    } else {
        //buffer to expire is empty
    }
}

inline void increment_current_index(descriptor_buffer_t *buffer) {
    buffer->current_index = (buffer->current_index + 1) %
                            buffer->not_expired_length;
}
