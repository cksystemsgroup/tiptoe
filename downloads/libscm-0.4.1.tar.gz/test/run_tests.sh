#!/bin/sh

export LD_LIBRARY_PATH=../dist
./regionbufferTest
./mixedScmTest
./multiThreadTest
./multiThreadTest2
