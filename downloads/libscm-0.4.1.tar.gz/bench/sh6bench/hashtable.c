/*
 * Copyright (c) 2010 Martin Aigner, Andreas Haas, Stephanie Stroka
 * http://cs.uni-salzburg.at/~maigner
 * http://cs.uni-salzburg.at/~ahaas
 * http://cs.uni-salzburg.at/~sstroka
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "hashtable.h"

/**
 * hash() creates an unsigned integer < HASHSIZE which allows
 * constant lookup of values in the best case.
 */
static unsigned int hash(char *s);
/**
 * lookup() returns a value for a given key or NULL if the key did not
 * exist in the hashtable.
 */
static node* lookup(node** hashtab, char *n);
/**
 * m_strdup() duplicates a given string
 * and returns the new string.
 */
static char* m_strdup(char *o);

/**
 * inithashtab() creates, initializes and returns a new hashtable
 */
node** inithashtab(){
	int i;
	node** hashtab = (node**) malloc(HASHSIZE * sizeof(node*));
	for(i=0;i<HASHSIZE;i++)
		hashtab[i]=NULL;
	return hashtab;
}

/**
 * hash() creates an unsigned integer < HASHSIZE which allows
 * constant lookup of values in the best case.
 */
static unsigned int hash(char* s){
	unsigned int h=0;
	for(;*s;s++)
		h=*s+h*31;
	return h % HASHSIZE;
}

/**
 * lookup() returns a value for a given key or NULL if the key did not
 * exist in the hashtable.
 */
static node* lookup(node** hashtab, char *n) {
	unsigned int hi=hash(n);
	node* np=hashtab[hi];
	for(;np!=NULL;np=np->next){
		if(!strcmp(np->name,n))
			return np;
	}

	return NULL;
}

/**
 * m_strdup() duplicates a given string
 * and returns the new string.
 */
static char* m_strdup(char *o) {
	int l=strlen(o)+1;
	char *ns=(char*)malloc(l*sizeof(char));
	strcpy(ns,o);
	if(ns==NULL)
		return NULL;
	else
		return ns;
}

/**
 * get() returns the value for the given key
 */
char* get(node** hashtab, char* name) {
	node* n=lookup(hashtab, name);
	if(n==NULL)
		return NULL;
	else
		return m_strdup(n->desc);
}

/**
 * rem() removes the entry for a given key
 */
void rem(node** hashtab, char* name) {
	unsigned int hi=hash(name);
	node* np = hashtab[hi];
	node* prev_np = NULL;
	for(;np!=NULL;np=np->next) {
		if(!strcmp(np->name,name)) {
			if(prev_np == NULL) {
				hashtab[hi] = np->next;
			} else {
				prev_np->next = np->next;
			}
			free(np);
		}
		prev_np = np;
	}
}

/**
 * put() inserts a value for a given key
 */
int put(node** hashtab, char* name,char* desc2) {
	unsigned int hi;
	node* np;
	if((np=lookup(hashtab, name))==NULL) {
		hi=hash(name);
		np=(node*)malloc(sizeof(node));
		if(np==NULL)
			return 0;
		np->name=m_strdup(name);
		if(np->name==NULL) return 0;
		np->next=hashtab[hi];
			hashtab[hi]=np;
	}
	else
	{
		free(np->desc);
	}
		np->desc=m_strdup(desc2);
	if(np->desc==NULL) return 0;

	return 1;
}

/**
 * A pretty useless but good debugging function,
 * which simply displays the hashtable in (key.value) pairs
 */
void displaytable(node** hashtab) {
	int i;
	node *t;
	for(i=0;i<HASHSIZE;i++){
		if(hashtab[i]==NULL)
			printf("()");
		else{
			t=hashtab[i];
			printf("(");
			for(;t!=NULL;t=t->next)
				printf("(%s.%s) ",t->name,t->desc);
			printf(")");
		}
	}
}

/**
 * cleanup() removes all hashtable entries
 */
void cleanup(node** hashtab) {
	int i;
	node *np,*t;
	for(i=0;i<HASHSIZE;i++){
		if(hashtab[i]!=NULL){
			np=hashtab[i];
			while(np!=NULL){
				t=np->next;
				free(np->name);
				free(np->desc);
				free(np);
				np=t;
			}
		}
	}
}


