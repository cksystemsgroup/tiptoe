/*
 * Copyright (c) 2010 Stephanie Stroka
 * http://cs.uni-salzburg.at/~sstroka
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#ifndef TRACER_H_
#define TRACER_H_

#include <stdlib.h>

/**
 * Collects allocation information and prints it to standard output
 */
extern void add_allocated_mem(void* address, unsigned long size, unsigned long allocation_site);

/**
 * Collects deallocation information and prints it to standard output
 */
extern void add_freed_mem(void* address, size_t new_size /*, unsigned long deallocation_site*/);

#endif /* TRACER_H_ */
