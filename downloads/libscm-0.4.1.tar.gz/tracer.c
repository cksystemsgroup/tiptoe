/*
 * Copyright (c) 2010 Martin Aigner, Andreas Haas, Stephanie Stroka
 * http://cs.uni-salzburg.at/~maigner
 * http://cs.uni-salzburg.at/~ahaas
 * http://cs.uni-salzburg.at/~sstroka
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "hashtable.h"
#include <malloc.h>
#include <errno.h>

//#define DEBUG


typedef struct heap_info heap_info_t;

static unsigned long net_mem = 0;
static unsigned long gross_mem = 0;//mallinfo().uordblks;

//for testing the best gross_mem value
static unsigned long info_arena = 0;
static unsigned long info_ordblks = 0;
static unsigned long info_usmblks = 0;
static unsigned long info_fordblks = 0;

static unsigned long info_smblks=0;
static unsigned long info_hblks=0;
static unsigned long info_hblkhd=0;
static unsigned long info_fsmblks=0;
static unsigned long info_keepcost=0;

static node** address_size;

static unsigned long malloc_free_counter = 0;
static unsigned long amount_of_memory_objects = 0;

/**
 * Initializes the
 * hashtable addresses and alloc_sites.
 */
static void init_measurement() 
{
	address_size = inithashtab();
	malloc_free_counter++;
}


/**
 * Collects allocation information and prints it to standard output
 */
void add_allocated_mem(void* address, unsigned long size, unsigned long allocation_site) 
{
#ifdef DEBUG
printf("add alloc\n");
#endif
	
	if(malloc_free_counter == 0) 
	{
		init_measurement();
	}

	// get some important values
	net_mem += size;
	struct mallinfo info = mallinfo();
	gross_mem = (unsigned long) info.uordblks;
	//for testing the best gross_mem value
	info_arena = info.arena;
	info_ordblks = info.ordblks;
	info_usmblks = info.usmblks;
	info_fordblks = info.fordblks;
	
	info_smblks = info.smblks;
	info_hblks = info.hblks;
	info_hblkhd = info.hblkhd;
	info_fsmblks = info.fsmblks;
	info_keepcost = info.keepcost;
	
	amount_of_memory_objects++;

	char* key = (char*) __libc_malloc( sizeof(void*)+1 );
	sprintf(key, "%lu", (unsigned long) address);
	char allocation_info[100];
	sprintf(allocation_info, "%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu",
			malloc_free_counter,
			(unsigned long) address,
			size,
			allocation_site,
			net_mem,
			gross_mem,
			amount_of_memory_objects,
			info_arena,
			info_ordblks,
			info_usmblks,
			info_fordblks,
			info_smblks,
			info_hblks,
			info_hblkhd,
			info_fsmblks,
			info_keepcost);
	char str_size[8];
	sprintf(str_size, "%lu", size);

	if(get(address_size, key) != NULL) 
	{
		errno= EFAULT;
		printf("Memory from this address has never been deallocated: %s\n", key);
		perror("\tMemory from this address has never been deallocated ");
		exit(0);
	}
	put(address_size, key,str_size);

	// printf memory information in the following format to stdout:
	// [mallocat]malloc_free_counter;allocation_addr;size;allocation_site;net_memory;gross_memory;amount_of_mem_objects
	printf("\n[mallocat]%s\n", allocation_info);
	malloc_free_counter++;
}


/**
 * Collects deallocation or reallocation information and prints it to standard output
 */
void add_freed_mem(void* address, unsigned long new_size /*, unsigned long deallocation_site*/)
{
#ifdef DEBUG
	if (new_size>0L)
		printf("add realloc\n");
	else
		printf("add free\n");
#endif

	if(malloc_free_counter == 0) 
	{
		init_measurement();
	}

	char* key = (char*) __libc_malloc( sizeof(address) );
	sprintf(key, "%lu", (unsigned long) address);
	char* str_size = get(address_size, key);
	
	if(str_size == NULL) 
	{
		errno= EFAULT;
		printf("Attempting to deallocate memory that has never been allocated "
				"with malloc, calloc, realloc or memalign: %s\n", key);
		perror("\tAttempting to deallocate memory that has never been allocated "
				"with malloc, calloc, realloc or memalign ");
		exit(0);
	}

	struct mallinfo info = mallinfo();
	gross_mem = (unsigned long) info.uordblks;
	//for testing the best gross_mem value
	info_arena = info.arena;
	info_ordblks = info.ordblks;
	info_usmblks = info.usmblks;
	info_fordblks = info.fordblks;
	
	info_smblks = info.smblks;
	info_hblks = info.hblks;
	info_hblkhd = info.hblkhd;
	info_fsmblks = info.fsmblks;
	info_keepcost = info.keepcost;
	
	if (new_size == 0L)
		amount_of_memory_objects--;

	unsigned long size = strtoul(str_size, NULL, 10);

	net_mem =net_mem + new_size-size;

	char deallocation_info[100];
	sprintf(deallocation_info, "%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu;%lu",
			malloc_free_counter,
			(unsigned long) address,
			new_size,
			0L,
			net_mem,
			gross_mem,
			amount_of_memory_objects,
			info_arena,
			info_ordblks,
			info_usmblks,
			info_fordblks,
			info_smblks,
			info_hblks,
			info_hblkhd,
			info_fsmblks,
			info_keepcost);

	printf("\n[mallocat]%s\n", deallocation_info);
	malloc_free_counter++;
	if (new_size==0L)
		rem(address_size, key);
	else
	{
		sprintf(str_size, "%lu", new_size);
		if(get(address_size, key) == NULL) 
		{
			errno= EFAULT;
			printf("Attempting to reallocate memory that has never been allocated "
					"with malloc, calloc, realloc or memalign: %s\n", key);
			perror("\tAttempting to reallocate memory that has never been allocated "
					"with malloc, calloc, realloc or memalign");
			exit(0);
		}

		put(address_size, key,str_size);
	}
}
