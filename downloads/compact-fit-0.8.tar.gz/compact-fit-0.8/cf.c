/* 
 * Copyright (c) Hannes Payer hpayer@cs.uni-salzburg.at
 * cs.uni-salzburg.at/~hpayer
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "cf.h"
#include "arch_dep.h"
#include <stdio.h>
#include <string.h>


////////////////////Constants////////////////////

/**
 * The size of a page
 */
#define PAGESIZE 16384

/*
 * min size of a page block
 * has to be >= 16B
 */
#define MINPAGEBLOCKSIZE 32


/**
 * max amount of page blocks that can be placed into a page
 */
#define MAXAMOUNTOFPAGEBLOCKS (PAGESIZE/MINPAGEBLOCKSIZE)

/**
 * memory amount of a page + page header
 */
#define PAGEMEMORY (sizeof(struct page))

/**
 * size of an abstract address
 */
#define ABSTRACTADDRESSSIZE sizeof(void **)

/**
 * proposed by berger et. al - size class differences
 */
#define SIZECLASSESFACTOR 1.125

/**
 * number of size classes TODO:automatic calculation
 * (page size 16384)
 * n >= SIZECLASSESFACTOR log 256
 */
#define SIZECLASSES 46//34



////////////////////Structures////////////////////


/**
 * The block_frame represents a defined size of physical memory.
 * Real data is stored in the memory of a block frame.
 * (non-moving version only)
 */
 #if NONMOVING
struct block_frame{
	char memory[MINPAGEBLOCKSIZE]; /**< physical memory*/
};
#endif

/**
 * recursiv definition of freelist
 */
struct free_list{
	struct free_list *fl; /**< pointer to next free list element */
};

/**
 * the page
 */
struct page{
	#if NONMOVING //include the block table (virtual memory)
	struct block_frame *block_table[MAXAMOUNTOFPAGEBLOCKS];		/**< block table*/
	#else //physical memory
	char memory[PAGESIZE];										/**< the memory of the page */
	#endif
				 							
	struct page *next; 											/**< next points to the next used page of the same class*/
	struct page *previous; 										/**< previous points to the prevoius used page of the same class*/
	uint16_t nr_used_page_blocks; 								/**< the amount of used page blocks of the page*/
	uint32_t free_page_block_list_head;							/**< head (array index) of first free page block of the free list (stack)*/
	uint32_t used_page_block_bitmap[17];						/**< 2dimensional bitmap to find used page blocks*/
	uint16_t free_page_block_list_next;							/**< if this flag is true, than the free block frame list has to be used*/
	struct sizeClass *sc;										/**< reference to the page class (the page belongs to)*/
};

/**
 * a size class
 */
struct sizeClass{
	struct page *head_full_pages; 	/**< reference to the first full element (page) of the size class*/
	struct page *head_nfull_pages; 	/**< reference to the first not full element (page) of the size class*/
	uint16_t nfullentries;			/**< free entries*/
	uint16_t series_counter;		/**< series counter for partial compaction*/
};


//////////Globals//////////

#if NONMOVING // block frame stuff

/**
 * block frame space
 */
static struct block_frame *block_frames;

/**
 * block frames free list
 */
static struct free_list *bf_free_list;

/**
 * number of block frames
 */
static uint32_t nr_block_frames;
#endif


/**
 * size of memory in bytes
 */
static uint32_t memory_size;

/**
 * number of pages
 */
static uint32_t nr_pages;

/**
 * number of max proxy entries
 * (used for static preallocation)
 */
static uint32_t nr_max_page_blocks;

/**
 * memory of the pages
 */
static struct page *pages;

/**
 * free pages list
 */
static struct free_list *pFreeList;

/**
 * memory of the abstract address space
 */
static void **abstract_address_space;

/**
 * number of abstract addresses
 */
static uint32_t nr_abstract_addresses;

/**
 * abstract addresses free list
 * (just for the moving version)
 */
#if !NONMOVING
static struct free_list *aa_free_list;
#endif

/**
 * size class instances
 */
static struct sizeClass size_classes[SIZECLASSES];

/**
 * ratio of not full pages
 * partial compaction
 */
static uint16_t not_full_pages_ratio[SIZECLASSES];

/**
 * map allocation request to size class
 * (size to size classes map)
 */
static uint16_t size_2_size_class_map[2000];

/*
 * map size class index to max page block size of the given size class
 * (size class to size map)
 */
static uint16_t size_class_2_size_map[SIZECLASSES];


/////////////////////////////////////////////////////


/////////////////////////////////////////////////////
// Free List
/////////////////////////////////////////////////////

/**
 * add element to free list
 * @param fl pointer to free list
 * @param ptr to first word of memory location
 */
void add_element_to_free_list(struct free_list **fl, void *ptr){
	struct free_list *tmp;
	tmp = (struct free_list *)ptr;
	
	/*free list is empty => new first element in free list*/
	if(*fl==NULL){
		*fl = tmp;
		(*fl)->fl = NULL;
	}
	/*add block frame to the beginning of the free list*/
	else{
		tmp->fl = *fl;
		*fl = tmp;
	}
}

/**
 * get element from free list
 * @param fl pointer to free list
 */
void *get_element_from_free_list(struct free_list **fl){
	/*no blocks in free list - out of memory error*/
	if(*fl == NULL){
		return NULL;
	}
	
	struct free_list *result;//	printf("PROXY: start: %p %p\n", proxy, &proxy[address]);
	result = *fl;
	
	/*new free list head*/
	*fl = (*fl)->fl;
	
	/*set used link in result memory to 0
	 * eleminates conflicts*/
	*(uint32_t *)result = 0;
	
	return result;
}

/**
 * print free list (debugging)
 * @param fl pointer to free list
 */
void print_free_list(struct free_list **fl){
	struct free_list *tmp;
	
	printf("\nFree List:\n");
	
	if(*fl==NULL){
		printf("no elements available\n");
	}
	else{
		tmp = *fl;
		
		uint32_t i;
		i=1;
		while(tmp!=NULL){
			printf("%d: %p ", i, tmp);
			tmp = tmp->fl;
			i++;
		}
	}
	printf("\n\n");
}

/////////////////////////////////////////////////////

/////////////////////////////////////////////////////
// Block Frames
/////////////////////////////////////////////////////

#if NONMOVING

static void init_free_block_frame_list(){
	bf_free_list = NULL;
	
	/*create the free block frame list incrementally*/
	uint32_t i;
	for(i=0; i<nr_block_frames; i++){
		add_element_to_free_list(&bf_free_list, block_frames+i);
	}
}

/**
 * init the block frame space
 * @param bf_amount amount of block frames
 * @param bf_memory block frame memory pointer
 */
static void init_block_frame_space(uint32_t bf_amount, void *bf_memory){
	nr_block_frames = bf_amount;
	
	/*init block frame memory*/
	//block_frames = (struct block_frame *)malloc(sizeof(struct block_frame)*block_framesAmount);
	block_frames = bf_memory;
	memset(block_frames, 0, sizeof(struct block_frame)*bf_amount);
	
	/*build free block frame list*/
	init_free_block_frame_list();
}

/**
 * determine the index of the block frame
 * @param bf pointer to the  block frame
 * @return index
 */
static inline uint32_t block_frame_index(struct block_frame *bf){
	uint32_t val;;
	
	/*difference between the block frame memory start address
	 *and the start address of a block frame*/
	val = ((uint32_t)&*bf) - ((uint32_t)&*block_frames);
	
	/*to get incremental indices*/
	val /= MINPAGEBLOCKSIZE;
	
	return val;
}

/**
 * returns a block frame from the block frame free list
 * @return pointer to a free block frame
 */
static inline struct block_frame *get_free_block_frame(){
	/*free list get operation*/
	return get_element_from_free_list(&bf_free_list);
}

/**
 * adds a block frame to the block frame free list
 * @param bf free block frame
 */
static inline void add_free_block_frame(struct block_frame *bf){
	/*free list add operation*/
	add_element_to_free_list(&bf_free_list, bf);
}

/**
 * print free block frame list (debugging)
 */
void cf_print_block_frames_free_list(){
	/*free list print operation*/
	print_free_list(&bf_free_list);
}
#endif

/////////////////////////////////////////////////////
// Abstract Address Space
/////////////////////////////////////////////////////

#if !NONMOVING
/**
 * free list is just needed in the moving version
 */
static void init_aa_free_list(){
	aa_free_list = NULL;
	
	/*add pages to free list*/
	uint32_t i;
	for(i=0; i<nr_abstract_addresses; i++){
		add_element_to_free_list(&aa_free_list, abstract_address_space+i);
	}
}
#endif


/**
 * init the abstract address space
 * @param aa_amount number of abstract addresses
 * @param aa_memory abstract address space pointer
 */
static void init_abstract_address_space(uint32_t aa_amount, void *aa_memory){
	nr_abstract_addresses = aa_amount;
	
	abstract_address_space = aa_memory;
	memset(abstract_address_space, 0, ABSTRACTADDRESSSIZE*nr_abstract_addresses);
	
	#if !NONMOVING
	/*init free proxy list*/
	init_aa_free_list();
	#endif
}

#if NONMOVING //the non moving implementation

/**
 * get an abstract address
 * @param address block frame index
 * @param bf block frame pointer
 * @return abstract address
 */
static inline void **get_abstract_address(uint32_t address, struct block_frame **bf){
	//printf("PROXY: address: %d; bf: %p %p\n", address, bf, *bf);
	abstract_address_space[address] = bf;
	return &abstract_address_space[address];	
}

/**
 * set abstract address
 * @param address block frame index
 * @param bf block frame pointer
 */
static inline void set_abstract_address(uint32_t address, struct block_frame **bf){
	abstract_address_space[address] = bf;
}

/**
 * clear an abstract address
 * @param aa abstract address
 */
static inline void clear_abstract_address(void **aa){
	*aa = 0;
}

#else // the moving implementation

/**
 * get an abstract address
 * @param page_block page block pointer
 * @return abstract address
 */
static inline void **get_abstract_address(void *page_block){
//	printf("PROXY: start: %p %p\n", proxy, &proxy[address]);
//	printf("PROXY: address: %d; bf: %p %p\n", address, bf, *bf);
	
	void **proxyEntry;
	proxyEntry = get_element_from_free_list(&aa_free_list);
	*proxyEntry = page_block;

	return proxyEntry;	
}

/**
 * set abstract address
 * @param address block frame index
 * @param bf block frame pointer
 */
static inline void set_abstract_address(void **aa, void *page_block){
	//printf("setProxy %p %p %p\n", proxyEntry, *proxyEntry, memoryRange);
	void **pe;
	pe = (void **)*aa;
	*pe = page_block;
}

/**
 * clear an abstract address
 * @param aa abstract address
 */
void clear_abstract_address(void *aa){
	add_element_to_free_list(&aa_free_list, aa);
}
#endif

/**
 * print the abstract address space
 */
void print_abstract_address_space(){
	
	printf("\nProxy Table:\n");
	
	uint32_t i;
	for(i=0; i<nr_abstract_addresses; i++){
		printf("%d: %p ", i, abstract_address_space[i]);
	}
	printf("\n\n");
}

/////////////////////////////////////////////////////
// Pages
/////////////////////////////////////////////////////

/**
 * init the free pages
 */
static void init_free_pages_list(){
	pFreeList = NULL;
	
	/*add pages to free list*/
	size_t i;
	for(i=0; i<nr_pages; i++){
		add_element_to_free_list(&pFreeList, pages+i);
	}
}

/**
 * init the pages memory space
 */
static void init_pages(size_t pages_amount, void *p_memory){
	nr_pages = pages_amount;
	
	/*init memory*/
	//pages = (struct page *)malloc(pagesAmount*sizeof(struct page));
	pages = p_memory;
	memset(pages, 0, nr_pages*sizeof(struct page));
	
	/*init free pages list*/
	init_free_pages_list();
}

/**
 * returns a page from the page free list
 * @return pointer to a free page
 */
static inline struct page *get_free_page(){
	/*free list get operation*/
	return get_element_from_free_list(&pFreeList);
}

/**
 * adds a free page to the page free list
 * @param p free page
 */
static inline void add_free_page(struct page *p){
	/*free list add operation*/
	add_element_to_free_list(&pFreeList, p);
	//printPageFreeList();
}

/**
 * prints the page free list (debugging)
 */
void print_pages_free_list(){
	print_free_list(&pFreeList);
}


#if NONMOVING //exclusive functions of the non-moving version

/**
 * returns the block table index of a block frame
 * @param bf pointer to the block frame pointer in the page
 * @return index of the block table
 */
static inline uint16_t get_block_table_index(struct block_frame **bf){
	/*reference to block frame in page*/
	uint32_t address;
	address = (uint32_t)&*bf;
	
	/*pages memory start address */
	uint32_t base;
	base = (uint32_t)pages;
	
	/*offset of block frame page entry*/
	uint32_t diff;
	diff = address - base;
	
	/*index of block frame entry in page*/
	uint32_t bfIndex;
	bfIndex = (diff%sizeof(struct page))/sizeof(uint32_t);
	
	//printf("calc index: %d %d %d %d %p %p\n", address, base, diff, bfIndex, *bf, pages);
	
	return bfIndex;
}

/**
 * returns the page which holds a given block frame
 * @param bf pointer to the block frame pointer in the page
 * @return page of block frame
 */
static inline struct page *get_page_to_block(struct block_frame **bf){
	/*reference to block frame in page*/
	uint32_t address;	
	address = (uint32_t)&*bf;
	
	/*pages memory start address */
	uint32_t base;
	base = (uint32_t)pages;
	
	/*offset of block frame page entry*/
	uint32_t diff;
	diff = address - base;
	
	/*determine page number*/
	uint16_t pageNr;
	pageNr = diff/sizeof(struct page);

	//printf("address: %d %p; base: %p %p %d\n", address, &*bf, &pages[0], pages, base);
	//printf("result: %p\n", &pages[pageNr]);
	return &pages[pageNr];	
}

#else

/**
 * return the memory offset of a page block within a page
 * @param page_block the page block
 * @return memory offset
 */
static inline uint32_t get_memory_offset(void *page_block){
	/*reference to block frame in page*/
	uint32_t address;
	address = (uint32_t)page_block;
	
	/*pages memory start address */
	uint32_t base;
	base = (uint32_t)pages;
	
	/*offset of block frame page entry*/
	uint32_t diff;
	diff = address - base;
	
	return diff;	
}

/**
 * return the index of the page block within a page
 * @param diff address difference
 * @param size page block size
 * @return index 
 */
static inline uint16_t get_index_of_page_block(uint32_t diff, uint32_t size){
	/*index of block frame entry in page*/
	//TODO: error - rangesize instead of u_int
	uint16_t index;
	index = (diff%sizeof(struct page))/size;
	
	//printf("calc index: %d %d %d %d %p\n", address, base, diff, bfIndex, pages);
	
	return index;
}

/**
 * return the page of a page block
 * @param diff address difference
 * @return page of page block
 */
static inline struct page *get_page_of_page_block(uint32_t diff){
	
	/*determine page number*/
	uint16_t pageNr;
	pageNr = diff/sizeof(struct page);

	//printf("address: %d; base: %p %p %d\n", address, &pages[0], pages, base);
	//printf("result: %p\n", &pages[pageNr]);
	return &pages[pageNr];	
}
#endif

/**
 * remove bitmap entry
 * @param p page
 * @param index page block index
 */
static inline void remove_bitmap_entry(struct page *p, uint16_t index){
	
	
	//set index of used block to 0 - 2 dimensions
	uint16_t bitmap_index;
	uint16_t bitmap_2D_index;
	
	bitmap_index = index/32;
	bitmap_2D_index = index%32;
	
	//set bit in second dimension to 0
	p->used_page_block_bitmap[bitmap_index+1] -= (1 << bitmap_2D_index);
	//clearbit(p->usedBitmap[bitmapIndex+1], bitmap2DIndex);
	
	
	int is_set;
	is_set = _ffs(p->used_page_block_bitmap[bitmap_index+1]);
	
	if(is_set < 0){
		p->used_page_block_bitmap[0] -= (1 << bitmap_index);
		//clearbit(p->usedBitmap[0], bitmapIndex);
	}	
}

/**
 * return a free bitmap entry
 * @param p page
 * @return bitmap index
 */
static inline uint16_t get_bitmap_entry(struct page *p){
	
	int bitmap_index;
	int bitmap_2D_index;
	
	bitmap_index = _ffs(p->used_page_block_bitmap[0]);
	bitmap_2D_index = _ffs(p->used_page_block_bitmap[bitmap_index+1]);
	
	
	p->used_page_block_bitmap[bitmap_index+1] -= (1 << bitmap_2D_index);
	
	int is_set;
	is_set = _ffs(p->used_page_block_bitmap[bitmap_index+1]);
//	printf("SETBIT1 %d\n", setBit);
	
	if(is_set < 0){
//		printf("SETBIT %d\n", setBit);
		p->used_page_block_bitmap[0] -= (1 << bitmap_index);
		//clearbit(p->usedBitmap[0], bitmapIndex);
	}

	return bitmap_index*32 + bitmap_2D_index;
}	

/**
 * add entry to the bitmpa
 * @param p page
 * @param index bitmap index
 */
static inline void add_bitmap_entry(struct page *p, uint16_t index){
	int bitmap_index;
	int bitmap_2D_index;
	
	bitmap_index = index/32;
	bitmap_2D_index = index%32;
	
	//printf("ADD INDEX TO PAGE USED LIST %d: %d %d; %d\n", index, bitmapIndex, bitmap2DIndex, p->usedBitmap[0]);
	
	p->used_page_block_bitmap[0] |= (1 << bitmap_index);
	p->used_page_block_bitmap[bitmap_index+1] |= (1 << bitmap_2D_index);
}

#if NONMOVING
/**
 * find a free page block
 * @param p page
 * @param size size
 * @return page block position in page
 */
static inline uint16_t get_free_page_block(struct page *p, uint16_t size){
	uint16_t pos;
	//printf("inside\n");
	
	/*flag set - use free list*/
	if(p->free_page_block_list_next == 0xffff){
		pos = p->free_page_block_list_head;
		
		/*the next element of the free list*/
		uint16_t *next;
		next = (uint16_t *)(&p->block_table[pos]);
		
		p->free_page_block_list_head = *next;
	}
	/*flag not set - incrementally the block frames*/
	else{
		//printf("flag not set\n");
		pos = p->free_page_block_list_next;
		p->free_page_block_list_next += size;
		
		/*set flag if all block frames of the page were in use*/
		if(MAXAMOUNTOFPAGEBLOCKS < (p->free_page_block_list_next+size)){
			p->free_page_block_list_next = 0xffff;
		}
	}
	
	
	return pos;
}

#else
/**
 * find a free page block
 * @param p page
 * @param size size
 * @return page block position in page
 */
static inline uint16_t get_free_page_block(struct page *p, uint16_t size){//TODO
	uint16_t pos;
	//printf("inside rangeSize: %d %d\n", rangeSize, p->freeBFList);
	
	/*flag set - use free list*/
	if(p->free_page_block_list_next == 0xffff){
		pos = p->free_page_block_list_head;
		
		/*the next element of the free list*/
		uint16_t *next;
		next = (uint16_t *)(p->memory + pos*size);

		
		p->free_page_block_list_head = *next;
	}
	/*flag not set - incrementally the block frames*/
	else{
		//printf("flag not set\n");
		pos = p->free_page_block_list_next;
		p->free_page_block_list_next += 1;
		
		/*set flag if all block frames of the page were in use*/
		if(PAGESIZE < (p->free_page_block_list_next*size+size)){
			p->free_page_block_list_next = 0xffff;
		}
	}
	return pos;
}
#endif

/**
 * add free page block
 * @param p page
 * @param index page block index
 * @param size page block size
 */
void add_free_page_block(struct page *p, uint16_t index, uint16_t size){
	/*old free list head, stored in first block frame in the first word*/
	uint16_t *ptr;
	
	#if NONMOVING //difference in the position
	ptr = (void *)&(p->block_table[index]);
	#else
	ptr = (uint16_t *)(p->memory + index*size);
	#endif
	
	*ptr = p->free_page_block_list_head;
	
	#if NONMOVING
	uint32_t i;
	for(i=1; i<size; i++){
		ptr = (void *)&(p->block_table[index+i]);
		*ptr = 0;
	}
	#endif
	
	/*set new free list head*/
	p->free_page_block_list_head = index;
}


/////////////////////////////////////////////////////
// Size Classes
/////////////////////////////////////////////////////

/**
 * init the size class instances
 */
static void init_size_class_instances(){
	int i;
	
	for(i=0; i<=SIZECLASSES;i++){
		size_classes[i].head_full_pages = NULL;
		size_classes[i].head_nfull_pages = NULL;
		size_classes[i].nfullentries = 0;
		size_classes[i].series_counter = 0;
	}
}

/**
 * set the not full pages ratio
 * (for partial compaction)
 */
static void init_not_full_pages_ratio(){
	
	int i;
	for(i=0; i<=SIZECLASSES;i++){
		not_full_pages_ratio[i] = 1;
	}
}

/**
 * init the size class mappings
 */
static void initSizeClasses(){
	int i;	
	
	/*init size classes map*/
	uint16_t base;
	uint16_t res;
	uint16_t tmp;
	uint16_t class;

	class = 0;

	for(i=0; i<MINPAGEBLOCKSIZE/4; i++){
 		//printf("mapping[%d] = %d\n", i, class);
		size_2_size_class_map[i] = class;
	}
	size_class_2_size_map[class] = MINPAGEBLOCKSIZE;

	class++;
    
	for(base=MINPAGEBLOCKSIZE; base<8000;){
		tmp = base;
		base = (int)base*SIZECLASSESFACTOR;
		res = base % 4;

		if(res!=0){
			#if NONMOVING
			base += (MINPAGEBLOCKSIZE -res);
			#else
			base += (4 -res);
			#endif
		}
    
		uint16_t j;
        	for(j=0; j<(base-tmp)/4; j++, i++){
			//printf("mapping[%d] = %d\n", i, class);
			size_2_size_class_map[i] = class;
		}
		size_class_2_size_map[class] = base;
		//printf("mapping2[%d] = %d\n", class, base);

		class++;

		if(base*SIZECLASSESFACTOR>=8000){
			break;
		}
	}
	
	for(; i<2000; i++){
		size_2_size_class_map[i] = class;
	}
	size_class_2_size_map[class] = 8000;
	size_class_2_size_map[class+1] = 16384;

	init_size_class_instances();
	init_not_full_pages_ratio();
}

/**
 * increment series counter of size class
 * @param class class number
 */
static inline void increment_series_counter(uint16_t class){
	size_classes[class].series_counter++;
}

/**
 * decrement series counter of size class
 * @param class class number
 */
static inline void decrement_series_counter(uint16_t class){
	if(size_classes[class].series_counter > 0){
		size_classes[class].series_counter--;
	}
}

/**
 * return series counter
 * @param class class number
 * @return series counter
 */
static inline uint16_t get_series_counter(uint16_t class){
	return size_classes[class].series_counter;
}

/**
 * return the head of the full pages list of a size class
 * @param class size class number
 * @return full pages head
 */
static inline struct page *get_full_pages_head(uint16_t class){
	/*head of the size class list*/
	return size_classes[class].head_full_pages;
}

/**
 * return the head of the not full pages list of a size class
 * @param class size class number
 * @return not full pages head
 */
static inline struct page *get_nfull_pages_head(uint16_t class){
	/*last page of size class*/
	return size_classes[class].head_nfull_pages;
}

/**
 * return the tail of the not full pages list of a size class
 * @param class size class number
 * @return not full pages tail
 */
static inline struct page *get_nfull_pages_tail(uint16_t class){
	/*last page of size class*/
	return size_classes[class].head_nfull_pages->previous;
}

/**
 * check not full pages ratio (partial compaction
 * @param class size class number
 * @param add increment
 * @return 1/0 boolean
 */
static inline uint16_t valid_nfull_pages_ratio(uint16_t class, uint16_t add){
	if((size_classes[class].nfullentries + add) > not_full_pages_ratio[class]){
		return 0;
	}
	return 1;
}

/**
 * return the size class of a page
 * @param p page
 * @return size class number
 */
static inline uint16_t get_size_class_of_page(struct page *p){
	/*size classes memory start address*/
	uint32_t base;
	base = (uint32_t)&size_classes[0];
	
	/*size class of page*/
	uint32_t refClass;
	refClass = (uint32_t)p->sc;
	
	//printf("get size class of page: %d %d; %p %p\n", base, refClass, &size_classes[0], &size_classes[1]);
	
	/*index of class*/
	uint32_t class;
	class = refClass - base;
	class /= sizeof(struct sizeClass);

	return class;
}

/**
 * return the size class number
 * @param size page block size
 * @return size class index
 */
static inline uint16_t get_size_class_index (size_t size){
	//return (size/32);
	if(size<=8000){
		return size_2_size_class_map[size/4];
	}
	return SIZECLASSES-1;
}

/**
 * return the page block size of a size class
 * @param class size class number
 * @return page block size
 */
static inline uint16_t get_page_block_size_of_size_class(uint16_t class){
	//return (class+1)*32;
	return size_class_2_size_map[class];
}

/**
 * add new page to size class
 * @param class size class number
 * @param p page
 */
static inline void add_page_to_size_class(uint16_t class, struct page *p){
	/*if size class is empty => create first entry*/
	if(size_classes[class].head_nfull_pages == NULL){	
		p->next = p;
		p->previous = p;
		size_classes[class].head_nfull_pages = p;
	}
	else{
		struct page *tmp;
		tmp = size_classes[class].head_nfull_pages; /*save first element*/
		p->next = tmp; /*and the double link*/
		p->previous = tmp->previous; /*link new last element with start*/
		tmp->previous->next = p;
		tmp->previous = p;	/*append new page after last element*/
		size_classes[class].head_nfull_pages = p; /*link start with last element*/
	}
	
	//printf("add page to size class: %d\n", class);
	/*save size class reference in page*/
	p->sc = &size_classes[class];
	size_classes[class].nfullentries++;
}

/**
 * remove page from size class not full list
 * @param class size class number
 * @param p page
 */
static inline void remove_page_from_nfull_list(uint16_t class, struct page *p){
	/*REMOVE page from not full page*/
	/*just one element exists in size class*/
	if(p == p->next){
		size_classes[class].head_nfull_pages = NULL;
		p->next = NULL;
		p->previous = NULL;
	}
	/*if page ist head of size class (should not be possible)*/
	else if(p == size_classes[class].head_nfull_pages){
		p->previous->next = p->next;
		p->next->previous = p->previous;
		size_classes[class].head_nfull_pages = p->next;
	}
	else{
		p->previous->next = p->next;
		p->next->previous = p->previous;
	}
	
	size_classes[class].nfullentries--;
}

/**
 * add new page to size class full list
 * @param class size class number
 * @param p page
 */
static void add_page_to_full_list(uint16_t class, struct page *p){
	/*if size class is empty => create first entry*/
	if(size_classes[class].head_full_pages == NULL){	
		p->next = p;
		p->previous = p;
		size_classes[class].head_full_pages = p;
	}
	else{
		struct page *tmp;
		tmp = size_classes[class].head_full_pages->previous; /*save last element*/
		tmp->next = p;	/*append new page after last element*/
		p->previous = tmp; /*and the double link*/
		p->next = size_classes[class].head_full_pages; /*link new last element with start*/
		size_classes[class].head_full_pages->previous = p; /*link start with last element*/
	}
}

/**
 * remove page from size class full list
 * @param class size class number
 * @param p page
 */
static void remove_page_from_full_list(uint16_t class, struct page *p){
	/*just one element exists in size class*/
	if(p == p->next){
		size_classes[class].head_full_pages = NULL;
		p->next = NULL;
		p->previous = NULL;
	}
	/*if page ist head of size class (should not be possible)*/
	else if(p == size_classes[class].head_full_pages){
		p->previous->next = p->next;
		p->next->previous = p->previous;
		size_classes[class].head_full_pages = p->next;
	}
	else{
		p->previous->next = p->next;
		p->next->previous = p->previous;
	}
}

/**
 * add page to size class not full list
 * @param class size class number
 * @param p page
 */
static void add_page_to_nfull_list(uint16_t class, struct page *p){
	/*if size class is empty => create first entry*/
	if(size_classes[class].head_nfull_pages == NULL){	
		p->next = p;
		p->previous = p;
		size_classes[class].head_nfull_pages = p;
	}
	else{
		struct page *tmp;
		tmp = size_classes[class].head_nfull_pages->previous; /*save last element*/
		tmp->next = p;	/*append new page after last element*/
		p->previous = tmp; /*and the double link*/
		p->next = size_classes[class].head_nfull_pages; /*link new last element with start*/
		size_classes[class].head_nfull_pages->previous = p; /*link start with last element*/
	}
	
	size_classes[class].nfullentries++;
}


/**
 * remove page from size class
 * @param class size class number
 * @param p page
 */
static void remove_page_from_size_class(uint16_t class, struct page *p){
	/*just one element exists in size class*/
	if(p == p->next){
		size_classes[class].head_nfull_pages = NULL;
		p->next = NULL;
		p->previous = NULL;
	}
	/*if page ist head of size class (should not be possible)*/
	else if(p == size_classes[class].head_nfull_pages){
		p->previous->next = p->next;
		p->next->previous = p->previous;
		size_classes[class].head_nfull_pages = p->next;
	}
	else{
		p->previous->next = p->next;
		p->next->previous = p->previous;
	}
	
	/*reset free block frame list incremental counter*/
	p->free_page_block_list_next = 0;
	p->free_page_block_list_head = 0;
	//p->usedBFListHead = 0;
	
	size_classes[class].nfullentries--;
	
	/*adds page to the global pages free list*/
	add_free_page(p);
}

/**
 * perform compaction
 * @param class size class
 * @param page p
 * @param size page block size
 */
void do_compaction(uint16_t class, struct page *p, uint16_t size){

		struct page *nf_page;
		nf_page = size_classes[class].head_nfull_pages;
		
		uint16_t index_insert;
		index_insert = get_free_page_block(p, size);
		
		uint16_t index_remove;
		index_remove = get_bitmap_entry(nf_page);
		
	
		#if NONMOVING//memcpy
		memcpy(&p->block_table[index_insert], &nf_page->block_table[index_remove], size*4);
		#else
		memcpy(p->memory + (index_insert)*size, nf_page->memory + (index_remove)*size, size);
		
		//handle explicit reference (moving version only)
		uint32_t *explicitReference1;
		explicitReference1 = (uint32_t *)&p->memory[(index_insert+1)*size-sizeof(uint32_t)];
		
		void *ptr;
		ptr = (void *)*explicitReference1;
		#endif

		nf_page->nr_used_page_blocks =  nf_page->nr_used_page_blocks - 1;

		add_free_page_block(nf_page, index_remove, size);
		add_bitmap_entry(p, index_insert);
		
		
		if(nf_page->nr_used_page_blocks == 0){
			remove_page_from_size_class(class, nf_page);
		}
		
		#if NONMOVING //abstract address update
		uint32_t aa_index;
		aa_index = block_frame_index(p->block_table[index_insert]);
		get_abstract_address(aa_index, &p->block_table[index_insert]);
		#else
		set_abstract_address(&ptr, &p->memory[(index_insert)*size]);
		#endif
}

static void print_pages_status(){
	
	printf("\nPages Status: \n");
	uint32_t i;
	for(i=0; i<SIZECLASSES; i++){
		if(size_classes[i].head_full_pages == NULL){
			//printf("size class %d full pages: empty\n", i);
		}
		else{
			struct page *p;
			p = size_classes[i].head_full_pages;
			
			uint32_t j;
			j=1;
			printf("size class %d full pages: ", i);
			do{
				printf("%d: %d entries; ", j, p->nr_used_page_blocks);
				j++;
				p = p->next;
			}while(p!=size_classes[i].head_full_pages);
			
			printf("\n");
		}
		if(size_classes[i].head_nfull_pages == NULL){
			//printf("size class %d not full pages: empty\n", i);
		}
		else{
			struct page *p;
			p = size_classes[i].head_nfull_pages;
			
			uint32_t j;
			j=1;
			printf("size class %d not full pages (val: %d; counter:%d): ", i, size_classes[i].nfullentries, size_classes[i].series_counter);
			do{
				printf("%d: %d entries; ", j, p->nr_used_page_blocks);
				j++;
				p = p->next;
			}while(p!=size_classes[i].head_nfull_pages);
			
			printf("\n");
		}
	}	
}
 

/////////////////////////////////////////////////////
// Public functions
/////////////////////////////////////////////////////

void cf_init(uint32_t size, void *memory){
	memory_size = size;
	nr_pages = 0;

	uint32_t step;
	#if NONMOVING //step size
	step = PAGEMEMORY+PAGESIZE+ABSTRACTADDRESSSIZE*MAXAMOUNTOFPAGEBLOCKS*2;
	#else
	step = PAGEMEMORY+ABSTRACTADDRESSSIZE*MAXAMOUNTOFPAGEBLOCKS;
	#endif

	/*calculate the amount of pages that can fit the given memory size*/
	uint32_t i;
	for(i=0; i<=(memory_size-step); i+=step){
		nr_pages++;
	}
	
	/*amount max proxy entries*/
	nr_max_page_blocks = nr_pages*(PAGESIZE/MINPAGEBLOCKSIZE);
	
	/*init main entities at start up*/
	#if NONMOVING //block frames just needed in the non-moving version
	init_block_frame_space(nr_max_page_blocks, (memory + nr_max_page_blocks*sizeof(void **) + nr_pages*sizeof(struct page)));
	#endif
	
	init_pages(nr_pages, (memory + nr_max_page_blocks*sizeof(void **)));
	initSizeClasses();
	init_abstract_address_space(nr_max_page_blocks, memory);
}

void **cf_malloc(size_t size){
	/*add size of explicit reference*/
	size += sizeof(uint32_t);

	/*size class index*/
	uint16_t class;
	class = get_size_class_index(size);
	
	/*page block size size class*/
	uint16_t max_size;
	max_size = get_page_block_size_of_size_class(class);
	struct page *p;
	
	
	/*first page in class or size class is full => beginn new page*///last ELEMENT
	if(get_nfull_pages_head(class)==NULL/* || get_nfull_pages_head(class)->entries == PAGESIZE/rangeSize*/){
		p = get_free_page();
		/*no page available*/
		if(p==NULL){
			printf("no page\n");
			return NULL;
		}
		add_page_to_size_class(class, p);		
	}
	/*last page of size class offers enough space*/
	else{
		p = get_nfull_pages_tail(class);
		//printf("get mostly empty page: %p %d\n", p, p->entries);
	}

	decrement_series_counter(class);
		
	/*get a page block index from the free list of the page*/
	uint16_t index;
	//printf("position: %d\n", index);
	
	#if NONMOVING //handle block frames
	uint32_t nr_block_frames;
	nr_block_frames = max_size/MINPAGEBLOCKSIZE;
	
	index = get_free_page_block(p, nr_block_frames);
	
	struct block_frame *bf;
	uint32_t i;
	for(i=0; i<nr_block_frames; i++){
		bf = get_free_block_frame();
		p->block_table[index+i] = bf;
		//printf("block frame: %p %p %p\n", bf, p->block_table[index+i], &p->block_table[index+i]);
	}
	#else
	index = get_free_page_block(p, max_size);
	#endif
	
	/*increment entries*/
	p->nr_used_page_blocks += 1;
	
	if(p->nr_used_page_blocks == PAGESIZE/max_size){
		remove_page_from_nfull_list(class, p);
		add_page_to_full_list(class, p);
	}

	/*add entry to used page block list of page*/
	add_bitmap_entry(p, index);
	
	void **adr;
	
	#if NONMOVING// abstract address
	/*physical memory index of block frame*/
	uint32_t aa_index;
	aa_index = block_frame_index(p->block_table[index]);
			
	/*set proxy*/
	adr = get_abstract_address(aa_index, &p->block_table[index]);

	#else
	//printf("BEFORE PROXY: %p; index: %d; ramgesize: %d;\n", p->memory + index*rangeSize, index, rangeSize);
	adr = get_abstract_address(&p->memory[index*max_size]);
	
	uint32_t *explicit_reference;
	explicit_reference = (uint32_t *)&p->memory[(index+1)*max_size-sizeof(uint32_t)];
	*explicit_reference = (uint32_t)adr;
	#endif
	
	//printf("proxyIndex: %d %d %d %p %p %p %p\n", proxyIndex, index, sizeof(p->bf[0]), &p->bf[index], &p->bf[0], &p->bf[2], &p->bf[4] );
	return adr;
}


void cf_free(void **address){
	/*dereference the proxy*/
	void *page_block;
	page_block = *address;
	
	struct page *p;
	
	#if NONMOVING //get page
	/*get the page which contains the referenced block frame*/
	p = (struct page *)get_page_to_block((struct block_frame **)page_block);
	#else
	/*geht index of block frame in page*/
	//printf("index: %d\n", indexOfBf);
	
	uint32_t offset;
	offset = get_memory_offset(page_block);
	
	/*get the page which contains the referenced page block*/
	p = (struct page *)get_page_of_page_block(offset);
	//printf("page: %p\n", p);
	#endif
	
	/*get the size class of the page*/
	uint16_t class;
	class = get_size_class_of_page(p);
	
	increment_series_counter(class);

	/*get the size*/
	uint16_t page_block_size;
	page_block_size = get_page_block_size_of_size_class(class);
	
	uint16_t page_block_index;
	#if NONMOVING // page block index
	page_block_index = get_block_table_index((struct block_frame **)page_block);
	#else
	page_block_index = get_index_of_page_block(offset, page_block_size);
	#endif

	/*remove the element from the used block frame free list*/
	remove_bitmap_entry(p, page_block_index);
	
	#if NONMOVING //block frame
	uint16_t bfs;
	bfs = page_block_size/MINPAGEBLOCKSIZE;
	
	uint32_t i;
	for(i=0; i<bfs; i++){
		//printf("%p %p %p\n", p, p->bf[indexOfBf+i], p->bf[indexOfBf+i+1]);
		add_free_block_frame(p->block_table[page_block_index+i]);
	}
	#endif
	
	/*add block frame to page block frame free list*/
	#if NONMOVING
	add_free_page_block(p, page_block_index, bfs);
	#else
	add_free_page_block(p, page_block_index, page_block_size);
	#endif
	
	/*clear the proxy entry*/
	clear_abstract_address(address);
	
	//the full page case
	if(p->nr_used_page_blocks == PAGESIZE/page_block_size){
		if(valid_nfull_pages_ratio(class, 1)){
			p->nr_used_page_blocks--;
			remove_page_from_full_list(class, p);
			add_page_to_nfull_list(class, p);
		}
		else{
			#if NONMOVING
			do_compaction(class, p, bfs);
			#else
			do_compaction(class, p, page_block_size);
			#endif
		}
	}
	else{
		p->nr_used_page_blocks--;
		if(p->nr_used_page_blocks == 0){
	//		printf("REMOVE PAGE\n");
			remove_page_from_size_class(class, p);
		}
	}

// old stuff	
//	/*remove page*/
//	if(p->entries == 0){
////		printf("REMOVE PAGE\n");
//		removePageFromSizeClass(class, p);
//	}
//	else if(p->entries+1 == PAGESIZE/rangeSize && valid_nfull_pages_ratio(class, 1)){
//		printf("change list\n");
//		remove_page_from_full_list(class, p);
//		add_page_to_nfull_list(class, p);
//	}
//	/*maybe some compaction has to be done*/
//	else if(!valid_nfull_pages_ratio(class, 0)){
//		printf("do compaction\n");
//		doCompaction(class, p, rangeSize);
//	}
}

void cf_print_memory_information(){
	printf("\nMemory Information:\n");
	printf("memory size: %d\n", memory_size);
	printf("pages amount: %d\n", nr_pages);
	printf("proxy entriest: %d\n", nr_max_page_blocks);
	printf("\n");
}

void cf_print_free_pages(){
	printf("Free Pages List\n");
	print_pages_free_list();
}

void cf_print_abstract_address_space(){
	print_abstract_address_space();
}

void cf_print_pages_status(){
	print_pages_status();
}
