/*
 * Copyright (c) 2010 Martin Aigner, Andreas Haas, Stephanie Stroka
 * http://cs.uni-salzburg.at/~maigner
 * http://cs.uni-salzburg.at/~ahaas
 * http://cs.uni-salzburg.at/~sstroka
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <stdlib.h>
#include <stdio.h>
#include "stm.h"
#include "meter.h"

#define LOOPRUNS 30
#define MEMSIZE1 512
#define MEMSIZE2 256


void *pointer2 = NULL;
static int region1;

void use_some_memory() {

	//this pointer is only used within this scope
	printf("|-------------- clock1-malloc --------------|\n");

	int i=0;
	for(i=0; i<LOOPRUNS; i++) {
		void* ptr = scm_malloc_in_region(MEMSIZE1, region1);
		scm_refresh(ptr, 0);
#ifdef SCM_PRINTMEM
		inc_needed_mem(MEMSIZE1);
		print_memory_consumption();
#endif
	}
	printf("|-------------------------------------------|\n");
}

int main(int argc, char** argv) {

	int i, j;

	region1 = scm_create_region();
	const int region2 = scm_create_region();

	for (i = 0; i < 10; i++) {
		//...
		use_some_memory();
		//create new memory for pointer2
		if(i % 2 == 0) {
			printf("|-------------- clock2-malloc --------------|\n");
//			pointer2 = scm_malloc_clock(20, &clock2);
			for(j=0; j<LOOPRUNS; j++) {
				void* ptr = scm_malloc_in_region(MEMSIZE2, region2);
				scm_refresh(ptr, 0);
#ifdef SCM_PRINTMEM
				inc_needed_mem(MEMSIZE1);
				print_memory_consumption();
#endif
			}
			printf("|-------------------------------------------|\n");
		}
#ifdef SCM_PRINTMEM
		for(i=0; i<LOOPRUNS; i++) {
			inc_not_needed_mem(MEMSIZE1);
			if(i % 2 == 0) {
				inc_not_needed_mem(MEMSIZE2);
			}
			print_memory_consumption();
		}
#endif
		scm_tick();
		//...
	}

	printf("------------- deallocation: --------------\n");
	for(i=0; i<60; i++) {
#ifdef SCM_PRINTMEM
		inc_not_needed_mem(MEMSIZE1);
		if(i % 2 == 0) {
			inc_not_needed_mem(MEMSIZE2);
		}
#endif
		scm_tick();
	}
	printf("success\n");

	return 0;
}
