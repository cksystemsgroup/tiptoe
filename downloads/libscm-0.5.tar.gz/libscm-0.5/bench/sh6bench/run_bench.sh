#!/bin/bash

export LD_LIBRARY_PATH=../../dist/

LOOPRUN=10
ALLOCATOR=( MALLOC MALLOC_LEAK STR STR_LEAK STM STM_LEAK STRMC STRMC_LEAK )

CALLCOUNT=( 250 500 750 1000 5000 10000 )

CASES=( singlethreaded multithreaded )

mkdir -p bench_results;

for cas in ${CASES[@]}
do
	if [ $cas = "multithreaded" ]; then
		o="-DSYS_MULTI_THREAD -pthread"
	fi
	echo $o

	for c in ${CALLCOUNT[@]}
	do

		echo "";
		echo "";
		echo "-------------------- Throughput --------------------";
		echo "";
		echo "";

		cd ../../; make clean; make > bench/sh6bench/buildlog.txt ; cd -;
		if test -f ../../dist/libscm.so; then

			make clean
			echo "make BENCH_OPTION=\"-DCALL_COUNT='$c' -DPRINTTHROUGHPUT $o\""
			make BENCH_OPTION="-DCALL_COUNT='$c' -DPRINTTHROUGHPUT $o" > buildlog.txt
			for a in ${ALLOCATOR[@]}
			do
				if test -f dist/sh6bench${a}; then
					echo "Started measurement of $a throughput performance. sh6bench call count is $c";
					echo "" > bench_results/throughput_${cas}_${a}_${c}.dat;
					sum=0
					for ((i=1;i<=$LOOPRUN;i++))
					do
						cputime=$(./dist/sh6bench$a | sed -n 's/throughput //p');
						sum=$(( $sum + $cputime ));
						#echo "cputime: $cputime"
						#echo "sum: $sum"
						echo "$cputime" >> bench_results/throughput_${cas}_${a}_${c}.dat;
					done
					avg=$(( $sum / $LOOPRUN ));
					sd=
					echo "AVG total execution time: $avg";
					echo "---" >> bench_results/throughput_${cas}_${a}_${c}.dat;
					echo "$avg" >> bench_results/throughput_${cas}_${a}_${c}.dat;
				else
					echo "Build of sh6bench${a} (throughput) failed";
					exit
				fi
			done
		else
			echo "Build of libscm.so failed";
			exit
		fi
	done

	
	for c in 250
	do
		cd ../../; make clean; make > bench/sh6bench/buildlog.txt ; cd -;
		
		if test -f ../../dist/libscm.so; then
			echo "";
			echo "";
			echo "-------------------- Latency --------------------";
			echo "";
			echo "";

			make clean
			echo "make BENCH_OPTION=\"-DCALL_COUNT='$c' -DPRINTLATENCY $o\""
			make BENCH_OPTION="-DCALL_COUNT='$c' -DPRINTLATENCY $o" > buildlog.txt
			for a in ${ALLOCATOR[@]}
			do
				if test -f dist/sh6bench${a}; then
					echo "Started measurement of $a latency. sh6bench call count is $c";
					dist/sh6bench$a | sed -n 's/latency //p' >bench_results/latency_${cas}_${a}_${c}.dat;
				else
                    echo "Build of sh6bench failed";
					exit
				fi
			done
			sed -n 's/scm_create_region //p' <bench_results/latency_${cas}_STR_${c}.dat | gzip >bench_results/latency_scm_create_region_${cas}_STR_${c}.gz
			sed -n 's/scm_create_region //p' <bench_results/latency_${cas}_STRMC_${c}.dat | gzip >bench_results/latency_scm_create_region_${cas}_STRMC_${c}.gz
			sed -n 's/scm_refresh_region //p' <bench_results/latency_${cas}_STR_${c}.dat | gzip >bench_results/latency_scm_refresh_region_${cas}_STR_${c}.gz
			sed -n 's/scm_refresh_region_with_clock //p' <bench_results/latency_${cas}_STRMC_${c}.dat | gzip >bench_results/latency_scm_refresh_region_with_clock_${cas}_STRMC_${c}.gz
			sed -n 's/scm_refresh //p' <bench_results/latency_${cas}_STM_${c}.dat | gzip >bench_results/latency_scm_refresh_${cas}_STM_${c}.gz
			sed -n 's/scm_malloc //p' <bench_results/latency_${cas}_STM_${c}.dat | gzip >bench_results/latency_scm_malloc_${cas}_STM_${c}.gz
			sed -n 's/scm_malloc_in_region //p' <bench_results/latency_${cas}_STR_${c}.dat | gzip >bench_results/latency_scm_malloc_in_region_${cas}_STR_${c}.gz
			sed -n 's/scm_malloc_in_region //p' <bench_results/latency_${cas}_STRMC_${c}.dat | gzip >bench_results/latency_scm_malloc_in_region_${cas}_STRMC_${c}.gz
			sed -n 's/scm_tick //p' <bench_results/latency_${cas}_STR_${c}.dat | gzip >bench_results/latency_scm_tick_${cas}_STR_${c}.gz
			sed -n 's/scm_tick //p' <bench_results/latency_${cas}_STM_${c}.dat | gzip >bench_results/latency_scm_tick_${cas}_STM_${c}.gz
			sed -n 's/scm_tick_clock //p' <bench_results/latency_${cas}_STRMC_${c}.dat | gzip >bench_results/latency_scm_tick_clock_${cas}_STRMC_${c}.gz
			sed -n 's/scm_unregister_region //p' <bench_results/latency_${cas}_STR_${c}.dat | gzip >bench_results/latency_scm_unregister_region_${cas}_STR_${c}.gz
			sed -n 's/scm_unregister_region //p' <bench_results/latency_${cas}_STRMC_${c}.dat | gzip >bench_results/latency_scm_unregister_region_${cas}_STRMC_${c}.gz
			
			sed -n 's/malloc //p' <bench_results/latency_${cas}_MALLOC_${c}.dat | gzip >bench_results/latency_malloc_${cas}_MALLOC_${c}.gz
			sed -n 's/free //p' <bench_results/latency_${cas}_MALLOC_${c}.dat | gzip >bench_results/latency_free_${cas}_MALLOC_${c}.gz

			sed -n 's/scm_create_region //p' <bench_results/latency_${cas}_STR_LEAK_${c}.dat | gzip >bench_results/latency_scm_create_region_${cas}_STR_LEAK_${c}.gz
			sed -n 's/scm_create_region //p' <bench_results/latency_${cas}_STRMC_LEAK_${c}.dat | gzip >bench_results/latency_scm_create_region_${cas}_STRMC_LEAK_${c}.gz
			sed -n 's/scm_refresh_region //p' <bench_results/latency_${cas}_STR_LEAK_${c}.dat | gzip >bench_results/latency_scm_refresh_region_${cas}_STR_LEAK_${c}.gz
			sed -n 's/scm_refresh_region_with_clock //p' <bench_results/latency_${cas}_STRMC_LEAK_${c}.dat | gzip >bench_results/latency_scm_refresh_region_with_clock_${cas}_STRMC_LEAK_${c}.gz
			sed -n 's/scm_refresh //p' <bench_results/latency_${cas}_STM_LEAK_${c}.dat | gzip >bench_results/latency_scm_refresh_${cas}_STM_LEAK_${c}.gz
			sed -n 's/scm_malloc //p' <bench_results/latency_${cas}_STM_LEAK_${c}.dat | gzip >bench_results/latency_scm_malloc_${cas}_STM_LEAK_${c}.gz
			sed -n 's/scm_malloc_in_region //p' <bench_results/latency_${cas}_STR_LEAK_${c}.dat | gzip >bench_results/latency_scm_malloc_in_region_${cas}_STR_LEAK_${c}.gz
			sed -n 's/scm_malloc_in_region //p' <bench_results/latency_${cas}_STRMC_LEAK_${c}.dat | gzip >bench_results/latency_scm_malloc_in_region_${cas}_STRMC_LEAK_${c}.gz
			sed -n 's/scm_tick //p' <bench_results/latency_${cas}_STR_LEAK_${c}.dat | gzip >bench_results/latency_scm_tick_${cas}_STR_LEAK_${c}.gz
			sed -n 's/scm_tick //p' <bench_results/latency_${cas}_STM_LEAK_${c}.dat | gzip >bench_results/latency_scm_tick_${cas}_STM_LEAK_${c}.gz
			sed -n 's/scm_tick_clock //p' <bench_results/latency_${cas}_STRMC_LEAK_${c}.dat | gzip >bench_results/latency_scm_tick_clock_${cas}_STRMC_LEAK_${c}.gz
			sed -n 's/scm_unregister_region //p' <bench_results/latency_${cas}_STR_LEAK_${c}.dat | gzip >bench_results/latency_scm_unregister_region_${cas}_STR_LEAK_${c}.gz
			sed -n 's/scm_unregister_region //p' <bench_results/latency_${cas}_STRMC_LEAK_${c}.dat | gzip >bench_results/latency_scm_unregister_region_${cas}_STRMC_LEAK_${c}.gz
			
			sed -n 's/malloc //p' <bench_results/latency_${cas}_MALLOC_LEAK_${c}.dat | gzip >bench_results/latency_malloc_${cas}_MALLOC_LEAK_${c}.gz
			sed -n 's/free //p' <bench_results/latency_${cas}_MALLOC_LEAK_${c}.dat | gzip >bench_results/latency_free_${cas}_MALLOC_LEAK_${c}.gz


		else
			echo "Build of libscm.so failed";
			exit
		fi
		echo "";
		echo "";
		echo "-------------------- Memory --------------------";
		echo "";
		echo "";

		cd ../../; make clean; make > bench/sh6bench/buildlog.txt; cd -;
		if test -f ../../dist/libscm.so; then

			make clean
			echo "make BENCH_OPTION=\"-DCALL_COUNT='$c' -DPRINTMEMINFO $o\""
			make BENCH_OPTION="-DCALL_COUNT='$c' -DPRINTMEMINFO $o" > buildlog.txt
			for a in ${ALLOCATOR[@]}
			do
				if test -f dist/sh6bench${a}; then
					echo "Started memory measurement for $a. sh6bench call count is $c";
				dist/sh6bench$a 2>&1 | gzip >bench_results/memory_${cas}_${a}_${c}.gz;
			else
                echo "Build of sh6bench failed";
				exit
			fi
			done
		else
			echo "Build of libscm.so failed";
			exit
		fi
	done
done
