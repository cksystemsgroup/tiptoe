//
package main

import (
	"flag"
	//"fmt"
	"runtime"
	//"time"
)

var n = flag.Int("n", 16, "depth")

type Node struct {
	item        int
	left, right *Node
}

func bottomUpTreeStm(item, depth int) *Node {
    var n *Node
    if depth <= 0 {
        n = &Node{item: item}
        runtime.StmRefresh0(n)
        return n
    }
    n = &Node{item, bottomUpTreeStm(2*item-1, depth-1), bottomUpTreeStm(2*item, depth-1)}
    runtime.StmRefresh0(n)
    return n
}

func bottomUpTree(item, depth int) *Node {
	if depth <= 0 {
		return &Node{item: item}
	}
	return &Node{item, bottomUpTree(2*item-1, depth-1), bottomUpTree(2*item, depth-1)}
}

func (n *Node) itemCheck() int {
	if n.left == nil {
		return n.item
	}
	return n.item + n.left.itemCheck() - n.right.itemCheck()
}

const minDepth = 4

func main() {
    runtime.MemProfileRate = 0
    runtime.MemStats.EnableGC = false
	flag.Parse()

	//t0 := time.Nanoseconds()

	maxDepth := *n
	if minDepth+2 > *n {
		maxDepth = minDepth + 2
	}
	stretchDepth := maxDepth + 1

    check := bottomUpTreeStm(0, stretchDepth).itemCheck()
    runtime.StmTick()
    //fmt.Printf("%d\n", time.Nanoseconds()-t0)
	longLivedTree := bottomUpTree(0, maxDepth)

	for depth := minDepth; depth <= maxDepth; depth += 2 {
		iterations := 1 << uint(maxDepth-depth+minDepth)
		check = 0

		for i := 1; i <= iterations; i++ {
			check += bottomUpTreeStm(i, depth).itemCheck()
            runtime.StmTick()
			check += bottomUpTreeStm(-i, depth).itemCheck()
            runtime.StmTick()
		}
	}
	a := longLivedTree.itemCheck()
    if a==0 {
        return
    }
	//t1 := time.Nanoseconds()
	//fmt.Printf("%d\n", t1-t0)
    //println(t1-t0)
}
