package main

import (
    "fmt"
    "http"
    "io/ioutil"
    "runtime"
)

func handler(w http.ResponseWriter, r *http.Request) {
    body, _ := ioutil.ReadFile("Google.html")
    fmt.Fprintf(w, string(body))
    if body == nil {
    }
}

func main() {
    // benchmark setup
    //runtime.MemStats.EnableGC = false
    runtime.MemProfileRate = 0

    http.HandleFunc("/test", handler)
    http.ListenAndServe(":8080", nil)
}
