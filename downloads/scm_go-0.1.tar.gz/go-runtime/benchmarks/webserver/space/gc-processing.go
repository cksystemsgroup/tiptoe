package main

import (
    "http"
    "io/ioutil"
    "runtime"
)

func handler(w http.ResponseWriter, r *http.Request) {
    body, _ := ioutil.ReadFile("Google.html")
    if body == nil {
    }
}

func main() {
    // benchmark setup
    //runtime.MemStats.EnableGC = false
    runtime.MemProfileRate = 0

    http.HandleFunc("/test", handler)
    http.ListenAndServe(":8080", nil)
}
