package main

import (
    "http"
    "io/ioutil"
    "time"
    "runtime"
)

func handler(w http.ResponseWriter, r *http.Request) {
    t0 := time.Nanoseconds()

    body, _ := ioutil.ReadFile("Google.html")
    runtime.StmRefresh0(body)
    if body!= nil {
    }
    runtime.StmTick()

    println(time.Nanoseconds()-t0)
}

func main() {
    // benchmark setup
    //runtime.MemStats.EnableGC = false
    runtime.MemProfileRate = 0

    http.HandleFunc("/test", handler)
    http.ListenAndServe(":8080", nil)
}
