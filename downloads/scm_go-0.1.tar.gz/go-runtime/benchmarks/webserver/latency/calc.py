#!/usr/bin/env python

import sys
from math import sqrt

file = open(sys.argv[1], 'r')
max = 0
avg = 0
cnt = 0
for line in file:
    cnt += 1
    val = float(line)
    if val > max:
        max = val
    avg += val
avg /= cnt
file.close()

file = open(sys.argv[1], 'r')
dev=0
cnt=0
for line in file:
   val = float(line)
   cnt +=1
   dev += (val-avg)**2
dev /= cnt
dev = sqrt(dev)
file.close()

print sys.argv[1] 
print "mean [ms]: "+ str(avg/1000000)
print "std [ms]: "+ str(dev/1000000)
print "max [ms]: "+ str(max/1000000)
