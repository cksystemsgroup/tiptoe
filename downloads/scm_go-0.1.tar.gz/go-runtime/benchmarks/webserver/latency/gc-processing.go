package main

import (
    "http"
    "io/ioutil"
    "time"
    "runtime"
)

func handler(w http.ResponseWriter, r *http.Request) {
    t0 := time.Nanoseconds()

    body, _ := ioutil.ReadFile("Google.html")
    if body == nil {
    }

    println(time.Nanoseconds()-t0)
}

func main() {
    // benchmark setup
    //runtime.MemStats.EnableGC = false
    runtime.MemProfileRate = 0

    http.HandleFunc("/test", handler)
    http.ListenAndServe(":8080", nil)
}
