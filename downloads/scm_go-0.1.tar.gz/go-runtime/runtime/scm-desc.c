//
// Copyright (c) 2010 Martin Aigner, Andreas Haas, Michael Lippautz
// http://cs.uni-salzburg.at/~maigner
// http://cs.uni-salzburg.at/~ahaas
// http://cs.uni-salzburg.at/~mlippautz
//
// University Salzburg, www.uni-salzburg.at
// Department of Computer Science, cs.uni-salzburg.at
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#include "runtime.h"
#include "malloc.h"
#include "scm-desc.h"

// Global pool to store roots of terminated g's.
static DescriptorRoot *root_terminated = nil;

// Fixed size alocator information that is used for internal mm.
FixAlloc descriptorroot_alloc;
FixAlloc descriptorpage_alloc;

DescriptorRoot*
DescriptorRoot_New() {
    DescriptorRoot *root;

    root = FixAlloc_Alloc(&descriptorroot_alloc);
    runtime_memclr((byte*)root, sizeof(DescriptorRoot));
    return root;    
}


void 
scm_init_mm(void *(*alloc)(uintptr)) {
    FixAlloc_Init(&descriptorroot_alloc, sizeof(DescriptorRoot), alloc, nil, 
        nil);
    FixAlloc_Init(&descriptorpage_alloc, SCM_DESCRIPTOR_PAGE_SIZE, alloc, nil, 
        nil);
}

DescriptorRoot*
scm_register_g() {
    DescriptorRoot *root;

    if (root_terminated == nil) {
        root = DescriptorRoot_New();
    } else {
        stm_global_lock();
        root = root_terminated;
        root_terminated = root_terminated->next;
        stm_global_unlock();
    }
    return root;
}

void 
scm_unregister_g(G* g) {
    g->root->next = root_terminated;
    root_terminated = g->root;
    g->root = nil;
}

