//
// Copyright (c) 2010 Martin Aigner, Andreas Haas, Michael Lippautz
// http://cs.uni-salzburg.at/~maigner
// http://cs.uni-salzburg.at/~ahaas
// http://cs.uni-salzburg.at/~mlippautz
//
// University Salzburg, www.uni-salzburg.at
// Department of Computer Science, cs.uni-salzburg.at
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#include "runtime.h"
#include "malloc.h"
#include "type.h"
#include "scm-desc.h"
#include "scm-arch.h"

extern FixAlloc descriptorpage_alloc;
struct ScmStats scmmem;

DescriptorPage*
DescriptorPage_New(DescriptorRoot *root) {
    DescriptorPage *new_page;

    if(root->number_of_pooled_descriptor_pages > 0) {
        root->number_of_pooled_descriptor_pages--;
        scmmem.pages_pooled--;
        new_page = root->descriptor_page_pool
            [root->number_of_pooled_descriptor_pages];
    } else {
        if (SCM_DEBUG_LEVEL > 5) {
            printf("stm: Creating new DescriptorPage\n");
        }
        scmmem.overhead += (uint64)descriptorpage_alloc.size;
        new_page = FixAlloc_Alloc(&descriptorpage_alloc);
    }
    new_page->number_of_descriptors = 0;
    new_page->next = nil;

    return new_page;
}

void 
DescriptorPage_Recycle(DescriptorPage *page) {
    DescriptorRoot *root;

    root = m->curg->root;
    if(root->number_of_pooled_descriptor_pages <
            SCM_DECRIPTOR_PAGE_FREELIST_SIZE) {
        root->descriptor_page_pool
            [root->number_of_pooled_descriptor_pages] = page;
        root->number_of_pooled_descriptor_pages++;   
        scmmem.pages_pooled++;
    } else {
        scmmem.overhead -= (uint64)descriptorpage_alloc.size;
        FixAlloc_Free(&descriptorpage_alloc, page);
    }
}

void
Expire_If_Exists(DescriptorRoot *root) {
	void *object;
	ObjectHeader *expired_object;

	expired_object = Get_Expired_Object(root);
    if(expired_object != nil) {
        if (atomic_int32_dec_test((int32*)(&expired_object->descriptor_counter))) {
            object = (void*) PAYLOAD_OFFSET(expired_object);
            scm_free(object);
        }
    }
}

void
scm_free(void *object) {
    // TODO: finalizers
    
	int32 sizeclass, size;
	MSpan *s;
	MCache *c;
	uint32 prof, *refsmall, reflarge;
    byte *p;

	if(object == nil)
		return;

	if(m->mallocing)
		throw("malloc/free - deadlock");
	m->mallocing = 1;
	
    sizeclass = OBJECT_HEADER(object)->sizeclass;
	if(sizeclass == 0) { // Large object
	    reflarge = s->gcref0;
	    s = OBJECT_HEADER_LARGE(object)->span;
	    p = (byte*)(s->start << PageShift);
        mstats.alloc -= s->npages<<PageShift;
		runtime_memclr(p, s->npages<<PageShift); // stm: IMPORTANT! header is 
		                                         // cleared automatically
		if(reflarge & RefProfiled)
			MProf_Free(p, s->npages<<PageShift);
		s->gcref0 = RefFree;
		MHeap_Free(&mheap, s, 1);
	} else { // Small object
	    refsmall = (uint32*)((uintptr)object+
	        OBJECT_HEADER(object)->gcref_offset);
	    prof = *refsmall & RefProfiled;
	    *refsmall = RefFree;
		c = m->mcache;
		size = class_to_size[sizeclass];
		if(size > sizeof(uintptr))
			((uintptr*)object)[1] = 1;	// mark as "needs to be zeroed"
		if(prof)
			MProf_Free(object, size);
		mstats.alloc -= size;
		mstats.by_size[sizeclass].nfree++;
		MCache_Free(c, object, sizeclass, size);
	}
	m->mallocing = 0;
}

ObjectHeader*
Get_Expired_Object(DescriptorRoot* root) {
	DescriptorPage *page;
    ObjectHeader *expired_object;

	page = root->first_expired;
	if(page == nil) return nil;

	if(root->expired_begin == page->number_of_descriptors) {
		root->expired_begin = 0;
		if(root->first_expired == root->last_expired) {
			//last page
			DescriptorPage_Recycle(root->first_expired);
			root->first_expired = nil;
			root->last_expired = nil;
			return nil;
		} else {
			page = root->first_expired->next;
			DescriptorPage_Recycle(root->first_expired);
			root->first_expired = page;
		}
	}

	if(page == nil) return nil;
	expired_object = page->descriptors[root->expired_begin];
	root->expired_begin++;
	return expired_object;
}

void 
Descriptor_Insert_Local(ObjectHeader *object, DescriptorRoot *root, 
		uint32 extension) {
	uint32 insert_index;
	DescriptorPage *page;

	insert_index = (root->current_local + extension) % 
		(SCM_MAX_EXPIRATION_EXTENSION + 1);
	if(root->first_local[insert_index] == nil) {
		// get page (new/pooled) and set first/last
        page = DescriptorPage_New(m->curg->root);
        root->last_local[insert_index] = page;
        root->first_local[insert_index] = page;
	} else {
        // already pages in array
    	// insert in last page
    	page = root->last_local[insert_index]; 
    }

	if(page->number_of_descriptors == SCM_DESCRIPTORS_PER_PAGE) {
        //page is full. get new page and append to end of list
        page = DescriptorPage_New(m->curg->root);
        root->last_local[insert_index]->next = page;
        root->last_local[insert_index] = page;
	}
    page->descriptors[page->number_of_descriptors] = object;
    page->number_of_descriptors++;
}

void
Expire_Local(DescriptorRoot *root) {
    int32 to_be_expired_index;

    to_be_expired_index = root->current_local - 1;
    if (to_be_expired_index < 0)
        to_be_expired_index += SCM_MAX_EXPIRATION_EXTENSION + 1;

    if(root->first_local[to_be_expired_index] != nil &&
            root->first_local[to_be_expired_index]->number_of_descriptors != 0){

        // concat
        if(root->first_expired == nil) {
            root->first_expired = root->first_local[to_be_expired_index];
            root->last_expired = root->last_local[to_be_expired_index];
        } else {
            root->last_expired->next = root->first_local[to_be_expired_index];
            root->last_expired = root->last_local[to_be_expired_index];
        }

        //create empty page for the next round
        //root->local_begin[to_be_expired_index] = 0;
        root->first_local[to_be_expired_index] = DescriptorPage_New(root);
        root->last_local[to_be_expired_index] = root->first_local
            [to_be_expired_index];
    }
}

