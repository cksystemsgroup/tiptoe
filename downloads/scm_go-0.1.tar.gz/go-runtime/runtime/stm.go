//
// This file contains the Go part of functions and external declarations that
// are used in the modified runtime.
//

package runtime

func StmFree(obj interface{})

func StmRefresh(obj interface{}, ext int32)

func StmRefresh0(obj interface{}) {
    StmRefresh(obj, 0)
}

func StmTick()
