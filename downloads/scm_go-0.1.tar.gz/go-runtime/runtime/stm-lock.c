//
// Copyright (c) 2010 Martin Aigner, Andreas Haas, Michael Lippautz
// http://cs.uni-salzburg.at/~maigner
// http://cs.uni-salzburg.at/~ahaas
// http://cs.uni-salzburg.at/~mlippautz
//
// University Salzburg, www.uni-salzburg.at
// Department of Computer Science, cs.uni-salzburg.at
//

//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#include "runtime.h"
#include "malloc.h"
#include "scm-desc.h"

// We provide a lock/unlock/trylock that yields the m to another g.
// Use cas from <arch>/asm.s.

static uint32 memory_lock = 0;
static uint32 global_lock = 0; // currently unused; needed for global sync

void
stm_global_lock() {
    while( !cas(&memory_lock, 0, 1) ) {
        gosched(); // yield
    }
}

void
stm_global_unlock() {
    cas(&memory_lock, 1, 0);
}

uint32
stm_global_trylock() {
    return cas(&memory_lock, 0, 1);
}

