enum {
	thechar = '5'
};
