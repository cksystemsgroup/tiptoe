//
// Copyright (c) 2010 Martin Aigner, Andreas Haas, Michael Lippautz
// http://cs.uni-salzburg.at/~maigner
// http://cs.uni-salzburg.at/~ahaas
// http://cs.uni-salzburg.at/~mlippautz
//
// University Salzburg, www.uni-salzburg.at
// Department of Computer Science, cs.uni-salzburg.at
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

//
// Debugging/verbose flags
//

#define SCM_DEBUG_LEVEL 0
#define SCM_PRINT_MEM 0
#define SCM_PRINT_TIME 0

//
// Configuration parameters
//

#define SCM_MAX_EXPIRATION_EXTENSION 3

#define SCM_DESCRIPTOR_PAGE_SIZE 32

#define SCM_DECRIPTOR_PAGE_FREELIST_SIZE 20

//
// Convinience macros 
//

#define SCM_DESCRIPTORS_PER_PAGE \
        ((SCM_DESCRIPTOR_PAGE_SIZE \
        - sizeof(DescriptorPage*) \
        - sizeof(uint32))/sizeof(ObjectHeader*))

//
// Macro converting a payload pointer to an ObjectHeader.
//
#define OBJECT_HEADER(_ptr) \
    ((ObjectHeader*)((byte*)_ptr - ScmObjectOverhead))

#define OBJECT_HEADER_LARGE(_ptr) \
    ((ObjectHeaderLarge*)((byte*)_ptr - ScmObjectOverheadLarge))

//
// Macro converting a ObjectHeader pointer to a payload (byte*) pointer.
//
#define PAYLOAD_OFFSET(_o) \
    ((byte*)(_o) + ScmObjectOverhead)

#define PAYLOAD_OFFSET_LARGE(_o) \
    ((byte*)(_o) + ScmObjectOverheadLarge)

//
// Types
//

typedef struct ObjectHeader ObjectHeader;
typedef struct ObjectHeaderLarge ObjectHeaderLarge;
typedef struct DescriptorPage DescriptorPage;

//
// Object header preceding all objects.
// May be converted to a large object header, if the sizeclass is 0.
//
struct ObjectHeader {
    uint32 descriptor_counter; 
    // Offset to the gcref flag used by Go. Needed for a fast free call.
    uint16 gcref_offset;
    // Sizeclass of the object. Needed for fast free call.
    uint16 sizeclass;
};

//
// Object header preceeding large objects. This is binary compatible with
// the small header, as the last fields are the same. 
// The distinction is needed because large objects can only be freed without
// a lookup if the span is known. Since objects are already large we can pay
// the additional space overhead.
//
struct ObjectHeaderLarge {
    MSpan *span;
    ObjectHeader;
};

enum {
    ScmObjectOverhead = sizeof(ObjectHeader),
    ScmObjectOverheadLarge = sizeof(ObjectHeaderLarge)
};

//
// A so-called page holding pointers do descriptors.
// Adjusting is done via SCM_DESCRIPTOR_PAGE_SIZE.
//
struct DescriptorPage {
    DescriptorPage *next;
    uint32 number_of_descriptors;
    ObjectHeader *descriptors[SCM_DESCRIPTORS_PER_PAGE];
};

//
// Per goroutine struct that is used for housekeeping all
// self-collecting mutator stuff.
//
struct DescriptorRoot {
    // Pointer for terminated list
    DescriptorRoot *next;

    // Expired round-robin buffer
	DescriptorPage *first_expired;
	DescriptorPage *last_expired;
	uint32 expired_begin;

    // Locally clocked buffer
	DescriptorPage *first_local[SCM_MAX_EXPIRATION_EXTENSION+1];
	DescriptorPage *last_local[SCM_MAX_EXPIRATION_EXTENSION+1];
	uint32 current_local;

    // Descriptor pool
    DescriptorPage *descriptor_page_pool[SCM_DECRIPTOR_PAGE_FREELIST_SIZE];
    uint32 number_of_pooled_descriptor_pages;
   
    // Per goroutine flag to indicated whether gc usage is _useful_. This
    // enabled a gc-less pattern using new/refresh/new/refresh/...
    int32 do_gc;
};

struct ScmStats {
    uint64 pages_pooled;
    uint64 pages_in_use;
    uint64 overhead;
};

extern struct ScmStats scmmem;

// Registers a new descriptor root for the current goroutine.
// This is usually done automatically on first invocation of a 
// stm function.
DescriptorRoot* scm_register_g(void);

// Unregisters a descriptor root from a given goroutine.
// This is done automatically on g destruction.
void scm_unregister_g(G*);

// Initializing function for fixed sizes allocators that are used 
// internally.
void scm_init_mm(void *(*alloc)(uintptr));

// Internal free called by scm.
// Can handle small and large objects. Needs an stm object since it
// does not call lookup!
void scm_free(ObjectHeader*);

// Function allocating a new DescriptorRoot. Zeroed.
DescriptorRoot* DescriptorRoot_New(void);

// Function allocating a new DescriptorPage that can be used for
// list.
DescriptorPage* DescriptorPage_New(DescriptorRoot *root);

// Function recycling an empty DescriptorPage into the goroutine local pool.
void DescriptorPage_Recycle(DescriptorPage *page);

// Function expiring the current local list index. Be that the time is already
// incremented!
void Expire_Local(DescriptorRoot *root);

// Inserts a object into the local list, making it a goroutine locally managed
// variable.
void Descriptor_Insert_Local(ObjectHeader *object, DescriptorRoot *root, uint32 
    extension);

// Function fetching an expired object from the goroutine local expired object 
// list.
ObjectHeader* Get_Expired_Object(DescriptorRoot* root);

// Function freeing an object if there exists an expired one.
void Expire_If_Exists(DescriptorRoot *root);

//
// Global locking functions
// Only needed for pool sharing!
//

void stm_global_lock(void);
void stm_global_unlock(void);
uint32 stm_global_trylock(void);

