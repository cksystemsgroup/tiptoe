// c:\Users\Hector\Code\go\bin\godefs.exe defs.c

// MACHINE GENERATED - DO NOT EDIT.

// Constants
enum {
	PROT_NONE = 0,
	PROT_READ = 0x1,
	PROT_WRITE = 0x2,
	PROT_EXEC = 0x4,
	MAP_ANON = 0x1,
	MAP_PRIVATE = 0x2,
};

// Types
#pragma pack on
#pragma pack off
