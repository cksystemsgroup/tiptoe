enum {
	thechar = '8'
};
