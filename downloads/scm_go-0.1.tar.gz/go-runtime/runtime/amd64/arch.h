enum {
	thechar = '6'
};
