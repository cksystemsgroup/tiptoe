#!/bin/sh

if [ "x${GOROOT}" == "x" ]; then
    echo " * GOROOT not set, aborting ..."
    exit 1
fi

mv ${GOROOT}/src/pkg/runtime ${GOROOT}/src/pkg/runtime-$(date '+%s')
cp -R $(pwd)/runtime ${GOROOT}/src/pkg/runtime
cd ${GOROOT}/src/pkg/runtime
gomake clean && gomake install
