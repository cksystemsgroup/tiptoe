/*
 * Copyright (c) 2010 Martin Aigner, Andreas Haas
 * http://cs.uni-salzburg.at/~maigner
 * http://cs.uni-salzburg.at/~ahaas
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _SCM_DESC_H
#define	_SCM_DESC_H

#include <stdlib.h>
#include <pthread.h>

#ifdef SCM_MT_DEBUG
#define printf printf("%lu: ", pthread_self());printf
#endif

#ifndef SCM_DESCRIPTORS_PER_PAGE
#define SCM_DESCRIPTORS_PER_PAGE \
        ((SCM_DESCRIPTOR_PAGE_SIZE - 2 * sizeof(void*))/sizeof(void*))
#endif

    extern void *__real_malloc(size_t size);
    extern void *__real_calloc(size_t nelem, size_t elsize);
    extern void *__real_realloc(void *ptr, size_t size);
    extern void __real_free(void *ptr);
    extern size_t __real_malloc_usable_size(void *ptr);


    /*
     * objects allocated using libscm haven an additional object header that
     * is added before the chunk returned by the malloc implemented in the
     * standard library.
     *
     * -------------------------  <- pointer to object_header_t
     * | descriptor counter dc |
     * -------------------------  <- pointer to the payload data that is
     * | payload data          |     returned to the user
     * ~ returned by malloc    ~
     * |                       |
     * -------------------------
     *
     */
#define OBJECT_HEADER(_ptr) \
    (object_header_t*)(_ptr - sizeof (object_header_t))
#define PAYLOAD_OFFSET(_o) \
    ((void*)(_o) + sizeof(object_header_t))

    typedef struct thread_data thread_data_t;
    typedef struct object_header object_header_t;
    typedef struct descriptor_list descriptor_list_t;
    typedef struct descriptor_page descriptor_page_t;
    typedef struct descriptor_buffer descriptor_buffer_t;
    typedef struct terminated_thread_data terminated_thread_data_t;

    struct object_header {
        unsigned int dc;
        unsigned int filler; //used for alignment
    };

    struct descriptor_buffer {
        descriptor_list_t **not_expired;
        unsigned int not_expired_length;
        unsigned int current_index;
    };

    struct thread_data {
        long global_phase;

        descriptor_list_t *list_of_expired_descriptors;
        descriptor_buffer_t globally_clocked_buffer;
        descriptor_buffer_t locally_clocked_buffer;

        descriptor_page_t * descriptor_page_pool[SCM_DECRIPTOR_PAGE_FREELIST_SIZE];
        unsigned int number_of_pooled_descriptor_pages;
    };

    struct descriptor_list {
        descriptor_page_t *first;
        descriptor_page_t *last;
        unsigned int begin;
    };

    struct descriptor_page {
        descriptor_page_t *next;
        unsigned int number_of_descriptors;
        object_header_t * descriptors[SCM_DESCRIPTORS_PER_PAGE];
    };

    struct terminated_thread_data {
        thread_data_t *thread_data;
        terminated_thread_data_t *next;
    };

    thread_data_t *get_thread_data(void)
    __attribute__((visibility("hidden")));
    
    void expire_descriptor_if_exists(descriptor_list_t *list)
    __attribute__((visibility("hidden")));

    void insert_descriptor(object_header_t *o,
            descriptor_buffer_t *buffer, unsigned int expiration)
    __attribute__((visibility("hidden")));

    void expire_buffer(descriptor_buffer_t *buffer,
            descriptor_list_t *exp_list)
    __attribute__((visibility("hidden")));

    inline void increment_current_index(descriptor_buffer_t *buffer)
    __attribute__((visibility("hidden")));
    
    descriptor_list_t *new_descriptor_list(thread_data_t *t, int init_page)
    __attribute__((visibility("hidden")));

#endif	/* _SCM_DESC_H */
