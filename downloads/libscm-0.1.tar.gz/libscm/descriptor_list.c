/*
 * Copyright (c) 2010 Martin Aigner, Andreas Haas
 * http://cs.uni-salzburg.at/~maigner
 * http://cs.uni-salzburg.at/~ahaas
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "stm.h"
#include "scm-desc.h"
#include "meter.h"
#include "arch.h"

#ifdef SCM_PRINTMEM
#include <malloc.h>
#endif //SCM_PRINTMEM

static descriptor_page_t *new_descriptor_page(thread_data_t *thread_data);
static inline void concat_descriptor_lists(descriptor_list_t *a,
        descriptor_list_t *b);
static inline void recycle_descriptor_page(descriptor_page_t *page);
static object_header_t *get_expired_object(descriptor_list_t *list);

static descriptor_page_t *new_descriptor_page(thread_data_t *thread_data) {

    descriptor_page_t *new_page = NULL;

    if (thread_data->number_of_pooled_descriptor_pages > 0) {
        thread_data->number_of_pooled_descriptor_pages--;
        new_page = thread_data->descriptor_page_pool
                [thread_data->number_of_pooled_descriptor_pages];
    } else {

#ifdef SCM_DEBUG
        if (SCM_DESCRIPTOR_PAGE_SIZE != getpagesize()) {
            printf("WARNING: SCM_DESCRIPTOR_PAGE_SIZE "
                    "does not fit system page size of %d\n", getpagesize());
        }
#endif
        int retval = posix_memalign((void**) & new_page,
                SCM_DESCRIPTOR_PAGE_SIZE,
                sizeof (descriptor_page_t));
        
        if (retval != 0 || new_page == NULL) {
            printf("posix_memalign failed with error: %d\n", retval);
            exit(retval);
        }

#ifdef SCM_PRINTOVERHEAD
        inc_overhead(__real_malloc_usable_size(new_page));
#endif
#ifdef SCM_PRINTMEM
        inc_used_mem(__real_malloc_usable_size(new_page));
#endif
    }
    new_page->number_of_descriptors = 0;
    new_page->next = NULL;
    return new_page;
}

descriptor_list_t *new_descriptor_list(thread_data_t *thread_data,
        int init_page) {

    descriptor_list_t *new_list = __real_malloc(sizeof (descriptor_list_t));
#ifdef SCM_PRINTOVERHEAD
    inc_overhead(__real_malloc_usable_size(new_list));
#endif
#ifdef SCM_PRINTMEM
    inc_used_mem(__real_malloc_usable_size(new_list));
#endif
    new_list->begin = 0;
    if (init_page != 0) {
        new_list->first = new_descriptor_page(thread_data);
    } else {
        new_list->first = NULL;
    }
    new_list->last = new_list->first;

    return new_list;
}

static inline void recycle_descriptor_page(descriptor_page_t *page) {

    thread_data_t *thread_data = get_thread_data();

    if (thread_data->number_of_pooled_descriptor_pages <
            SCM_DECRIPTOR_PAGE_FREELIST_SIZE) {
        thread_data->descriptor_page_pool
                [thread_data->number_of_pooled_descriptor_pages] = page;
        thread_data->number_of_pooled_descriptor_pages++;
    } else {
#ifdef SCM_PRINTOVERHEAD
        dec_overhead(__real_malloc_usable_size(page));
#endif
#ifdef SCM_PRINTMEM
        inc_freed_mem(__real_malloc_usable_size(page));
#endif
        __real_free(page);
    }
}

static object_header_t *get_expired_object(descriptor_list_t *list) {
    //remove from the first page
    descriptor_page_t *page = list->first;

    if (page == NULL) {
        //list is empty
        return NULL;
    }

#ifdef SCM_DEBUG
    printf("list->begin: %u, p->num_of_desc: %u\n", list->begin,
            page->number_of_descriptors);
#endif

    if (list->begin == page->number_of_descriptors) {
        //page has already been emptied
        //free this page and proceed with next one at index 0
        list->begin = 0;

        if (list->first == list->last) {
            //this was the last page in list

            recycle_descriptor_page(list->first);

            list->first = NULL;
            list->last = NULL;

            return NULL;
        } else {
            //there are more pages left
            page = list->first->next;

            recycle_descriptor_page(list->first);

            list->first = page;
        }
    }

    if (page == NULL) {
#ifdef SCM_DEBUG
        printf("end of list\n");
#endif
        return NULL;
    }

#ifdef SCM_DEBUG
    if (list->begin == page->number_of_descriptors) {
        printf("more than one empty page in list\n");
        return NULL;
    }
#endif

    object_header_t *expired_object = page->descriptors[list->begin];
    list->begin++;
    return expired_object;
}

void expire_descriptor_if_exists(descriptor_list_t *list) {

    object_header_t *expired_object = get_expired_object(list);
    if (expired_object != NULL) {

        if (atomic_int_dec_and_test((int*) & expired_object->dc)) {
#ifdef SCM_DEBUG
            printf("FREE(%lx)\n",
                    (unsigned long) PAYLOAD_OFFSET(expired_object));
#endif
#ifdef SCM_PRINTOVERHEAD
            dec_overhead(sizeof (object_header_t));
#endif

#ifdef SCM_PRINTMEM
            inc_freed_mem(__real_malloc_usable_size(expired_object));
#endif
            __real_free(expired_object);

        } else {
#ifdef SCM_DEBUG
            printf("decrementing DC==%u\n", expired_object->dc);
#endif
        }
    } else {
#ifdef SCM_DEBUG
        printf("no expired object found\n");
#endif
    }
}

void insert_descriptor(object_header_t *object, descriptor_buffer_t *buffer,
        unsigned int expiration) {

    unsigned int insert_index = (buffer->current_index + expiration) %
            buffer->not_expired_length;

    descriptor_list_t *list = buffer->not_expired[insert_index];

    //insert in the last page
    descriptor_page_t *page = list->last;

    if (page->number_of_descriptors == SCM_DESCRIPTORS_PER_PAGE) {
        //page is full. create new page and append to end of list
        page = new_descriptor_page(get_thread_data());
        list->last->next = page;
        list->last = page;
    }

    page->descriptors[page->number_of_descriptors] = object;
    page->number_of_descriptors++;
}

/*
 * concatenates list b to list a.
 */
static inline void concat_descriptor_lists(descriptor_list_t *a,
        descriptor_list_t *b) {

    if (a->first == NULL) {
        a->first = b->first;
        a->last = b->last;
        a->begin = b->begin;
    } else {
        a->last->next = b->first;
        a->last = b->last;
    }
}

/*
 * expire buffer operates always on the current_index-1 list of the buffer
 */
void expire_buffer(descriptor_buffer_t *buffer, descriptor_list_t *exp_list) {

    int to_be_expired_index = buffer->current_index - 1;
    if (to_be_expired_index < 0)
        to_be_expired_index += buffer->not_expired_length;

    if (buffer->not_expired
            [to_be_expired_index]->first->number_of_descriptors != 0) {

        concat_descriptor_lists(exp_list,
                buffer->not_expired[to_be_expired_index]);

        //create empty page for the next round
        buffer->not_expired[to_be_expired_index]->begin = 0;
        buffer->not_expired[to_be_expired_index]->first =
                new_descriptor_page(get_thread_data());
        buffer->not_expired[to_be_expired_index]->last =
                buffer->not_expired[to_be_expired_index]->first;
    }
}

inline void increment_current_index(descriptor_buffer_t *buffer) {
    buffer->current_index = (buffer->current_index + 1) %
            buffer->not_expired_length;
}
