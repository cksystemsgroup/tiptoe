/*
 * Copyright (c) 2010 Martin Aigner, Andreas Haas
 * http://cs.uni-salzburg.at/~maigner
 * http://cs.uni-salzburg.at/~ahaas
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _ARCH_H
#define	_ARCH_H

/*code adapted from glib http://ftp.gnome.org/pub/gnome/sources/glib/2.24/
 * g_atomic_*: atomic operations.
 * Copyright (C) 2003 Sebastian Wilhelmi
 * Copyright (C) 2007 Nokia Corporation
 */

#define atomic_int_inc(atomic) (atomic_int_add ((atomic), 1))
#define atomic_int_dec_and_test(atomic)				\
  (atomic_int_exchange_and_add ((atomic), -1) == 1)


#if defined __i386__ || defined __x86_64__

static inline int atomic_int_exchange_and_add(volatile int *atomic,
        int val) {

    int result;

    __asm__ __volatile__("lock; xaddl %0,%1"
            : "=r" (result), "=m" (*atomic)
            : "0" (val), "m" (*atomic));
    return result;
}

static inline void atomic_int_add(volatile int *atomic, int val) {
    __asm__ __volatile__("lock; addl %1,%0"
            : "=m" (*atomic)
            : "ir" (val), "m" (*atomic));
}

#endif /* defined __i386__ || defined __x86_64__ */

#endif	/* _ARCH_H */

