/*
 * Copyright (c) 2010 Martin Aigner, Andreas Haas
 * http://cs.uni-salzburg.at/~maigner
 * http://cs.uni-salzburg.at/~ahaas
 *
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Science, cs.uni-salzburg.at
 */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include "stm.h"
#include "scm-desc.h"
#include "meter.h"
#include "arch.h"

#ifdef SCM_PRINTMEM
#include <malloc.h>
#endif //SCM_PRINTMEM

static long global_time = 0;
static unsigned int number_of_threads = 0;

//the number of threads, that have not yet ticked in a global period
static unsigned int ticked_threads_countdown = 1;

//protects global_time, number_of_threads and ticked_threads_countdown
static pthread_spinlock_t global_time_lock;

static terminated_thread_data_t *terminated_thread_data_list;

//protects the data structures of terminated threads
static pthread_mutex_t thread_data_mutex = PTHREAD_MUTEX_INITIALIZER;

//the first thread joining libscm has to initialize the thread local storage
static unsigned int init_threads = 0;
static pthread_key_t thread_data_key;

static inline void lock_global_time();
static inline void unlock_global_time();
static inline void lock_thread_data();
static inline void unlock_thread_data();
static thread_data_t *new_thread_data_structure();
static void refresh(void *ptr, unsigned int extension,
        descriptor_buffer_t *buffer);
static thread_data_t *scm_register_thread();

void *__wrap_malloc(size_t size);
void *__wrap_calloc(size_t nelem, size_t elsize);
void *__wrap_realloc(void *ptr, size_t size);
void __wrap_free(void *ptr);
size_t __wrap_malloc_usable_size(void *ptr);

//avoid ELF interposition of exported but internally used symbols
//by creating static aliases
static void scm_resume_thread_internal(void)
__attribute__((alias("scm_resume_thread")));

static void scm_block_thread_internal(void)
__attribute__((alias("scm_block_thread")));

static void* __wrap_malloc_internal(size_t size)
__attribute__((alias("__wrap_malloc")));

void* scm_malloc(size_t size)
__attribute__((alias("__wrap_malloc")));

void scm_free(void *ptr)
__attribute__((alias("__wrap_free")));

void *__wrap_calloc(size_t nelem, size_t elsize) {

    void *p = __wrap_malloc_internal(nelem * elsize);
    //calloc returns zeroed memory by specification
    memset(p, '\0', nelem * elsize);
    return p;
}

void *__wrap_malloc(size_t size) {

    object_header_t *object =
            (object_header_t*) (__real_malloc(size + sizeof (object_header_t)));
    object->dc = 0;

#ifdef SCM_PRINTOVERHEAD
    inc_overhead(sizeof (object_header_t));
#endif

#ifdef SCM_PRINTMEM
    inc_used_mem(__real_malloc_usable_size(object));
    print_memory_consumption();
#endif
    return PAYLOAD_OFFSET(object);
}

void *__wrap_realloc(void *ptr, size_t size) {

    if (ptr == NULL) return __wrap_malloc_internal(size);
    //else: create new object
    object_header_t *new_object =
            (object_header_t*) __real_malloc(size + sizeof (object_header_t));
    new_object->dc = 0;

#ifdef SCM_PRINTOVERHEAD
    inc_overhead(sizeof (object_header_t));
#endif

    //get the minimum of the old size and the new size
    size_t old_object_size =
            __real_malloc_usable_size(OBJECT_HEADER(ptr))
            - sizeof (object_header_t);
    size_t lesser_object_size;
    if (old_object_size >= size) {
        lesser_object_size = size;
    } else {
        lesser_object_size = old_object_size;
    }

    object_header_t *old_object = OBJECT_HEADER(ptr);
    //copy payload bytes 0..(lesser_size-1) from the old object to the new one
    memcpy(PAYLOAD_OFFSET(new_object),
            PAYLOAD_OFFSET(old_object),
            lesser_object_size);

    if (old_object->dc == 0) {
        //if the old object has no descriptors, we can free it
#ifdef SCM_PRINTMEM
        inc_freed_mem(__real_malloc_usable_size(old_object));
#endif

#ifdef SCM_PRINTOVERHEAD
        dec_overhead(sizeof (object_header_t));
#endif
        __real_free(old_object);
    } //else: the old object will be freed later due to expiration

#ifdef SCM_PRINTMEM
    inc_used_mem(__real_malloc_usable_size(new_object));
    print_memory_consumption();
#endif
    return PAYLOAD_OFFSET(new_object);
}

void __wrap_free(void *ptr) {

    if (ptr == NULL) return;

#ifdef SCM_PRINTOVERHEAD
    dec_overhead(sizeof (object_header_t));
#endif

    object_header_t *object = OBJECT_HEADER(ptr);

    if (object->dc == 0) {
#ifdef SCM_PRINTMEM
        inc_freed_mem(__real_malloc_usable_size(object));
#endif
        __real_free(object);
    }
}

size_t __wrap_malloc_usable_size(void *ptr) {

    object_header_t *object = OBJECT_HEADER(ptr);
    return __real_malloc_usable_size(object) - sizeof (object_header_t);
}

void scm_tick(void) {

    thread_data_t *thread_data = get_thread_data();

#ifdef SCM_DEBUG
    printf("GT: %lu GP: %lu #T:%d ttc:%d\n",
            global_time, thread_data->global_phase,
            number_of_threads, ticked_threads_countdown);
#endif

    if (global_time == thread_data->global_phase) {
        //each thread must expire its own globally clocked buffer,
        //but can only do so on its first tick after the last global
        //time advance

        //my first tick in this global period
        thread_data->global_phase++;

        //current_index is equal to the so-called thread-global time
        increment_current_index(&thread_data->globally_clocked_buffer);

        //expire_buffer operates on current_index - 1, so it is called after
        //we incremented the current_index of the globally_clocked_buffer
        expire_buffer(&thread_data->globally_clocked_buffer,
                thread_data->list_of_expired_descriptors);

        if (atomic_int_dec_and_test((int*) & ticked_threads_countdown)) {

            lock_global_time();

            ticked_threads_countdown = number_of_threads;
            //assert: thread_data->global_phase == global_time + 1
            global_time++;

            unlock_global_time();

        } //else global time does not advance

    } //else: we already ticked in this global_phase

    //make local time progress
    //current_index is equal to the so-called thread-local time
    increment_current_index(&thread_data->locally_clocked_buffer);
    //expire_buffer operates on current_index - 1, so it is called after
    //we incremented the current_index of the locally_clocked_buffer
    expire_buffer(&thread_data->locally_clocked_buffer,
            thread_data->list_of_expired_descriptors);

#ifdef SCM_PRINTMEM
    print_memory_consumption();
#endif
    //we also process expired descriptors at tick
    //to get a cyclic allocation/free scheme. this is optional
    expire_descriptor_if_exists(thread_data->list_of_expired_descriptors);
}

static void refresh(void *ptr, unsigned int extension,
        descriptor_buffer_t *buffer) {
    thread_data_t *thread_data = get_thread_data();
    object_header_t *object = OBJECT_HEADER(ptr);

    atomic_int_inc((int*) & object->dc);
    expire_descriptor_if_exists(thread_data->list_of_expired_descriptors);
    insert_descriptor(object, buffer, extension);
}

void scm_global_refresh(void *ptr, unsigned int extension) {
#ifdef SCM_DEBUG
    printf("scm_global_refresh(%lx, %d)\n", (unsigned long) ptr, extension);
#endif
    if (extension > SCM_MAX_EXPIRATION_EXTENSION) {
#ifdef SCM_DEBUG
        printf("violation of SCM_MAX_EXPIRATION_EXTENT\n");
#endif
        extension = SCM_MAX_EXPIRATION_EXTENSION;
    }
    refresh(ptr, extension + 2, &get_thread_data()->globally_clocked_buffer);

#ifdef SCM_PRINTMEM
    print_memory_consumption();
#endif
}

void scm_local_refresh(void *ptr, unsigned int extension) {
#ifdef SCM_DEBUG
    printf("scm_local_refresh(%lx, %d)\n", (unsigned long) ptr, extension);
#endif
    if (extension > SCM_MAX_EXPIRATION_EXTENSION) {
#ifdef SCM_DEBUG
        printf("violation of SCM_MAX_EXPIRATION_EXTENT\n");
#endif
        extension = SCM_MAX_EXPIRATION_EXTENSION;
    }
    refresh(ptr, extension, &get_thread_data()->locally_clocked_buffer);

#ifdef SCM_PRINTMEM
    print_memory_consumption();
#endif
}

/*
 * get_thread_data is called by operations that need to access the thread data
 * structures.
 */
thread_data_t *get_thread_data() {

    void *ptr = pthread_getspecific(thread_data_key);

    if (ptr == NULL) {
        ptr = scm_register_thread();
    }

    return (thread_data_t*) ptr;
}

/*
 * scm_register_thread is called on a thread when it operates the first time
 * in libscm. The thread data structures are created or reused from previously
 * terminated threads.
 */
static thread_data_t *scm_register_thread() {
    thread_data_t *thread_data;

    lock_thread_data();

    if (init_threads == 0) {
        //initialize thread local data key and the global_time_lock spinlock
        //when the first thread is registered
        pthread_key_create(&thread_data_key, NULL);
        pthread_spin_init(&global_time_lock, PTHREAD_PROCESS_PRIVATE);
        init_threads = 1;
    }

    if (terminated_thread_data_list != NULL) {
        terminated_thread_data_t *first_list_item = terminated_thread_data_list;
        thread_data = first_list_item->thread_data;
        terminated_thread_data_list = first_list_item->next;
#ifdef SCM_PRINTOVERHEAD
        dec_overhead(__real_malloc_usable_size(first_list_item));
#endif
#ifdef SCM_PRINTMEM
        inc_freed_mem(__real_malloc_usable_size(first_list_item));
#endif
        __real_free(first_list_item);
    } else {
        thread_data = new_thread_data_structure();
    }

    unlock_thread_data();

    pthread_setspecific(thread_data_key, thread_data);

    //assert: if thread_data belonged to a terminated thread,
    //block_thread was invoked on this thread
    scm_resume_thread_internal();

    return thread_data;
}

/*
 * scm_unregister_thread is called upon termination of a thread. The thread 
 * leaves the system and passes its data structures in a pool to be reused
 * by other threads upon creation.
 */
void scm_unregister_thread() {

    scm_block_thread_internal();

    lock_thread_data();
    terminated_thread_data_t *thead_data =
            __real_malloc(sizeof (terminated_thread_data_t));
    thead_data->thread_data = get_thread_data();
    thead_data->next = terminated_thread_data_list;
    terminated_thread_data_list = thead_data;

#ifdef SCM_PRINTOVERHEAD
    inc_overhead(__real_malloc_usable_size(thead_data));
#endif
#ifdef SCM_PRINTMEM
    inc_used_mem(__real_malloc_usable_size(thead_data));
#endif

    unlock_thread_data();
}

/*
 * scm_block_thread is called when a thread blocks to notify the system about it
 */
void scm_block_thread() {
    thread_data_t *thread_data = get_thread_data();

    //assert: we do not have the thread_data lock
    lock_global_time();
    number_of_threads--;

    if (global_time == thread_data->global_phase) {
        //we have not ticked in this global period

        if (atomic_int_dec_and_test((int*) & ticked_threads_countdown)) {
            //we are the last thread to tick and therefore need to tick globally
            if (number_of_threads == 0) {
                ticked_threads_countdown = 1;
            } else {
                ticked_threads_countdown = number_of_threads;
            }
            global_time++;
        }
    }
    unlock_global_time();
}

/*
 * scm_resume_thread is called when a thread returns from blocking state to 
 * notify the system about it.
 */
void scm_resume_thread() {
    thread_data_t *thread_data = get_thread_data();

    //assert: we do not have the thread_data lock
    lock_global_time();

    if (number_of_threads == 0) {
        //if this is the first thread to register, then we have to tick to make
        //global progress, unless another thread registers
        //assert: ticked_threads_counter == 1
        thread_data->global_phase = global_time;
    } else {
        //else: we do not tick globally in the current global period
        //to avoid increasing the ticked_threads_counter
        thread_data->global_phase = global_time + 1;
    }
    number_of_threads++;

    unlock_global_time();
}

static thread_data_t *new_thread_data_structure() {
    int i;
    thread_data_t *thread_data = __real_malloc(sizeof (thread_data_t));

#ifdef SCM_PRINTOVERHEAD
    inc_overhead(__real_malloc_usable_size(thread_data));
#endif
#ifdef SCM_PRINTMEM
    inc_used_mem(__real_malloc_usable_size(thread_data));
#endif

    thread_data->globally_clocked_buffer.current_index = 0;
    thread_data->locally_clocked_buffer.current_index = 0;

    thread_data->list_of_expired_descriptors =
            new_descriptor_list(thread_data, 0);

    //allocate memory for the globally clocked descriptor buffers
    //size of the globally clocked buffer is SCM_MAX_EXPIRATION_EXTENSION + 3
    //because of the additional slots for
    // 1. slot for the current time
    // 2. adding descriptors at current + increment + 1
    // 3. removong descriptors from current - 1
    thread_data->globally_clocked_buffer.not_expired_length =
            SCM_MAX_EXPIRATION_EXTENSION + 3;
    thread_data->globally_clocked_buffer.not_expired = __real_malloc(
            sizeof (descriptor_list_t) * SCM_MAX_EXPIRATION_EXTENSION + 3);
    for (i = 0; i < SCM_MAX_EXPIRATION_EXTENSION + 3; i++) {
        thread_data->globally_clocked_buffer.not_expired[i] =
                new_descriptor_list(thread_data, 1);
    }
#ifdef SCM_PRINTOVERHEAD
    inc_overhead(__real_malloc_usable_size(thread_data->
            globally_clocked_buffer.not_expired));
#endif
#ifdef SCM_PRINTMEM
    inc_used_mem(__real_malloc_usable_size(thread_data->
            globally_clocked_buffer.not_expired));
#endif

    //allocate memory for the locally clocked descriptor buffers
    //size of the locally clocked buffer is SCM_MAX_EXPIRATION_EXTENSION + 1
    //because of the additional slots for
    // 1. slot for the current time
    thread_data->locally_clocked_buffer.not_expired_length =
            SCM_MAX_EXPIRATION_EXTENSION + 1;
    thread_data->locally_clocked_buffer.not_expired = __real_malloc(
            sizeof (descriptor_list_t) * SCM_MAX_EXPIRATION_EXTENSION + 1);
    for (i = 0; i < SCM_MAX_EXPIRATION_EXTENSION + 1; i++) {
        thread_data->locally_clocked_buffer.not_expired[i] =
                new_descriptor_list(thread_data, 1);
    }
#ifdef SCM_PRINTOVERHEAD
    inc_overhead(__real_malloc_usable_size(thread_data->
            locally_clocked_buffer.not_expired));
#endif
#ifdef SCM_PRINTMEM
    inc_used_mem(__real_malloc_usable_size(thread_data->
            locally_clocked_buffer.not_expired));
#endif

    thread_data->number_of_pooled_descriptor_pages = 0;

    return thread_data;
}

static inline void lock_global_time() {
#ifdef SCM_PRINTLOCK
    if (pthread_spin_trylock(&global_time_lock)) {
        printf("thread %ld BLOCKS on global_time_lock\n", pthread_self());
        pthread_spin_lock(&global_time_lock);
    }
#else
    pthread_spin_lock(&global_time_lock);
#endif
}

static inline void unlock_global_time() {
    pthread_spin_unlock(&global_time_lock);
}

static inline void lock_thread_data() {
#ifdef SCM_PRINTLOCK
    if (pthread_mutex_trylock(&thread_data_mutex)) {
        printf("thread %ld BLOCKS on thread_data_lock\n", pthread_self());
        pthread_mutex_lock(&thread_data_mutex);
    }
#else
    pthread_mutex_lock(&thread_data_mutex);
#endif
}

static inline void unlock_thread_data() {
    pthread_mutex_unlock(&thread_data_mutex);
}
