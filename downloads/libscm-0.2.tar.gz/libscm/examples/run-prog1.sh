#!/bin/bash

export LD_LIBRARY_PATH=../dist && ./prog1