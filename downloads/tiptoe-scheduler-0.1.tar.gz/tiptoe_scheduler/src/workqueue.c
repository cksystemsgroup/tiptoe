/*
 *  The Tiptoe Project
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include "workqueue.h"
#include "process.h"

#include "queue.h"

static struct queue_head ready;
static struct queue_head blocked;

#if defined DEBUG_QUEUE || defined WQUEUE_TEST
#define print_queue(_a) do {\
	fprintf(stderr, "in (%s) ", __FUNCTION__);\
	if (_a == &ready) { \
		 printf("ready ");\
		fprintf(stderr, "ready "); \
	 } else { \
		 printf("blocked ");\
		fprintf(stderr, "blocked "); \
	 }\
	(_a)->print_queue(_a); \
	} while (0)
#else /* DEBUG_QUEUE */
static inline void print_queue(struct queue_head *head)
{
}
#endif /* DEBUG_QUEUE */

void wqueue_init()
{
	queue_head_init(&ready);
	queue_head_init(&blocked);
}

/**
 * add_ready
 * @policy: workqueue class.
 *
 */
static inline void wqueue_add_ready(struct Process *p)
{
	struct queue_entry *entry;
	entry = process_to_queue(p);
	entry->head = &ready;
	ready.add(&ready, entry, p->task.deadline, p->task.release);
	print_queue(&ready);
	print_queue(&blocked);
}

/**
 * get_head_ready
 * @policy: workqueue class.
 *
 */
struct Process *wqueue_get_ready()
{
	struct Process *p;
	struct queue_entry *q;

	p = NULL;
	q = ready.get(&ready);
	if (q) {
		p = queue_to_process(q);
		q->head = &ready;
	}
	return p;
}

/**
 * add_blocked
 * @policy: workqueue class.
 */
static inline void wqueue_add_blocked(struct Process *p)
{
	struct queue_entry *entry;
	entry = process_to_queue(p);
	entry->head = &blocked;
	blocked.add(&blocked, entry, p->task.release, p->task.deadline);
	print_queue(&blocked);
	print_queue(&ready);
}

/**
 * get_blocked
 * @policy: workqueue class.
 */
struct Process *wqueue_get_blocked()
{
	struct Process *p;
	struct queue_entry *q;

	p = NULL;
	q = blocked.get(&blocked);
	if (q) {
		p = queue_to_process(q);
		q->head = &blocked;
	}
	return p;
}

static int calc_key(struct queue_entry *q)
{
	struct Process *p;

	p = queue_to_process(q);
	set_process_state(p, TASK_STATE_READY);
	return p->task.deadline;
}

int wqueue_advance(int time)
{
	int retval = 0;
	print_queue(&blocked);
	print_queue(&ready);
	retval = ready.move(&ready, &blocked, time, calc_key);
	print_queue(&blocked);
	print_queue(&ready);

	ready.set_current_key(&ready, time);
	blocked.set_current_key(&blocked, time);
	print_queue(&blocked);
	print_queue(&ready);

	return retval;
}

struct Process *wqueue_get_next(struct Process *this)
{
	struct Process *p;
	struct queue_entry *q;
	struct queue_head *head;

	p = NULL;
	q = NULL;

	head = this->queue.head;
	if (head == &blocked && get_process_state(this) != TASK_STATE_BLOCKED)
		fprintf(stderr, "error head is not matching state blocked\n");
	if (head == &ready && get_process_state(this) != TASK_STATE_READY
		&& get_process_state(this) != TASK_STATE_RUNNING)
		fprintf(stderr, "error head is not matching state ready\n");

	if (head) {
		q = head->get_next(head, &this->queue);
		if (q) {
			p = queue_to_process(q);
			if (head == &blocked)
				set_process_state(p, TASK_STATE_BLOCKED);
			else
				set_process_state(p, TASK_STATE_READY);
		}
	}

	return p;
}

void wqueue_add(struct Process *p)
{
	int state;

	wqueue_remove(p);

	state = get_process_state(p);
	if (state == TASK_STATE_BLOCKED)
		wqueue_add_blocked(p);
	else if (state == TASK_STATE_READY)
		wqueue_add_ready(p);
	else
		/*
		 * BUG: unknown state 
		 */
		fprintf(stderr, "ERROR: unknown state of a process\n");
}


long wqueue_to_release(long key)
{
	long retval = 0;
	struct queue_entry *q, *first;
	q = blocked.get_key(&blocked, key);
	first = q;
	while(q && q->key == key) {
		++retval;
		q = blocked.get_next(&blocked, q);
		if(q == first)
			break;
	}
	return retval;

}

void wqueue_remove(struct Process *p)
{
	struct queue_head *head;

	head = p->queue.head;
	if (head) {
		head->remove(head, &p->queue);
		print_queue(head);
	}
}

int wqueue_reschedule(struct Process *p, int release, int deadline)
{
	struct queue_head *head;

	if (release) {
		if (get_process_state(p) != TASK_STATE_BLOCKED) {
			/*
			 * BUG: if we reschedule a new release the process must be blocked! 
			 */
			fprintf(stderr,
					"ERROR: rescheduling a non blocked process with new release time!\n");
			return -1;
		}
		if (release >= deadline) {
			fprintf(stderr, "ERROR: deadline is before release time\n");
			return -1;
		}
	}

	head = p->queue.head;
	if (head) {
		print_queue(head);
		head->remove(head, &p->queue);
		print_queue(head);
	}
	p->queue.head = NULL;

	set_process_deadline(p, deadline);
	if (release) {
		set_process_release(p, release);
		wqueue_add_blocked(p);
	} else {
		wqueue_add_ready(p);
	}
	return 0;
}

long wqueue_mem_usage()
{
	long usage;
	usage = ready.mem_usage();
	return usage;
}

int wqueue_alloc_count()
{
	int count;
	count = ready.alloc_count();
	return count;
}

#ifdef WQUEUE_TEST  /* unit tests */
#define NUM_PROCESS 3
#define TIME_LIMIT 200
static int add_process_resource_descriptor(struct Process *p, int resource,
									int limit, int period)
{
	int res;
	set_process_resource_limit(p, resource, limit);
	set_process_resource_period(p, resource, period);

	for (res = 0; res < NUM_RESOURCES; res++) {
		set_process_context_supply(p, resource,
								   get_process_resource_limit(p, resource));
		set_process_context_instant(p, resource, 0);
	}
	return 0;
}

struct q_matrix m;
int main(int argc, char **argv)
{
	struct Process procs[NUM_PROCESS * 4];
	struct Process *p;
	int i;
	wqueue_init();
	int mem = sizeof(ready) + sizeof(blocked);

	printf("memory reqs workqueue:\t\t%10d b %8d kb %4d mb\n", mem, mem / 1024,
		   mem / (1024 * 1024));
	mem +=
		sizeof(unsigned long) * MAX_ELEMENTS * BITS_TO_LONGS(MAX_ELEMENTS) * 2;
	printf("memory reqs + matrix bitmaps:\t%10d b %8d kb %4d mb\n", mem,
		   mem / 1024, mem / (1024 * 1024));
	mem += sizeof(struct list_head) * MAX_ELEMENTS * MAX_ELEMENTS;
	printf("memory reqs + matrix data:\t%10d b %8d kb %4d mb\n", mem,
		   mem / 1024, mem / (1024 * 1024));
	printf("bitmap sizes %d b\n", BITS_TO_LONGS(MAX_ELEMENTS) * 4);

	for (i = 0; i < NUM_PROCESS; ++i) {
		process_init(&procs[i], i / 2, PROCESS_TYPE_PERIODIC, 200);
	}
	for (; i < NUM_PROCESS * 2; ++i) {
		process_init(&procs[i], MAX_ELEMENTS + 4, PROCESS_TYPE_PERIODIC, 200);
	}
	for (; i < NUM_PROCESS * 3; ++i) {
		process_init(&procs[i], 160, PROCESS_TYPE_PERIODIC, 200);
	}
	for (; i < NUM_PROCESS * 4; ++i) {
		process_init(&procs[i], 150, PROCESS_TYPE_PERIODIC, 200);
	}

	for (i = 0; i < NUM_PROCESS; ++i) {
		add_process_resource_descriptor(&procs[i], 0, 20, 200 - i / 2);
		add_process_resource_descriptor(&procs[i], 1, 20, 200 - i / 2);
		add_process_resource_descriptor(&procs[i], 2, 20, 200 - i / 2);
	}
	for (; i < NUM_PROCESS * 2; ++i) {
		add_process_resource_descriptor(&procs[i], 0, 20, 160 + i / 2);
		add_process_resource_descriptor(&procs[i], 1, 20, 160 + i / 2);
		add_process_resource_descriptor(&procs[i], 2, 20, 160 + i / 2);
	}
	for (; i < NUM_PROCESS * 3; ++i) {
		add_process_resource_descriptor(&procs[i], 0, 20, MAX_ELEMENTS + i / 2);
		add_process_resource_descriptor(&procs[i], 1, 20, MAX_ELEMENTS + i / 2);
		add_process_resource_descriptor(&procs[i], 2, 20, MAX_ELEMENTS + i / 2);
	}
	for (; i < NUM_PROCESS * 4; ++i) {
		add_process_resource_descriptor(&procs[i], 0, 20,
										200 - (i - NUM_PROCESS * 3) / 2);
		add_process_resource_descriptor(&procs[i], 1, 20,
										200 - (i - NUM_PROCESS * 3) / 2);
		add_process_resource_descriptor(&procs[i], 2, 20,
										200 - (i - NUM_PROCESS * 3) / 2);
	}
	for (i = 0; i < NUM_PROCESS; ++i) {
		if (add_process_code(&procs[i], 0, 0, 0))
			printf("error in add_process_code %d\n", i);
		add_process_task(&procs[i], i);
		set_process_state(&procs[i], TASK_STATE_BLOCKED);
		wqueue_add(&procs[i]);
	}
	for (i = NUM_PROCESS * 3; i < NUM_PROCESS * 4; ++i) {
		if (add_process_code(&procs[i], 0, 0, 0))
			printf("error in add_process_code %d\n", i);
		add_process_task(&procs[i], i);
		set_process_state(&procs[i], TASK_STATE_BLOCKED);
		wqueue_add(&procs[i]);
	}

	fprintf(stderr, "============= advance to 0 ============= \n");
	wqueue_advance(0);
	set_process_state(&procs[1], TASK_STATE_READY);
	wqueue_add(&procs[1]);
	set_process_state(&procs[0], TASK_STATE_READY);
	wqueue_add(&procs[0]);

	p = wqueue_get_ready();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in ready queue\n");

	p = wqueue_get_blocked();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in blocked queue\n");

	fprintf(stderr, "============= advance to 1 ============= \n");
	wqueue_advance(1);
	fprintf(stderr, "============= advance to 2 ============= \n");
	wqueue_advance(2);

	/*
	 * test time line wrap
	 */

	/*
	 * the following is an error; the release time is to far into the future
	 */
	fprintf(stderr, "generate an overflow error for Array and matrix\n");
	for (i = NUM_PROCESS * 2; i < NUM_PROCESS * 3; ++i) {
		if (add_process_code(&procs[i], 0, 0, 0))
			printf("error in add_process_code %d\n", i);
		add_process_task(&procs[i], i);
		set_process_state(&procs[i], TASK_STATE_BLOCKED);
		wqueue_add(&procs[i]);
	}
	p = wqueue_get_ready();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in ready queue\n");

	p = wqueue_get_blocked();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in blocked queue\n");

	fprintf(stderr, "============= advance to 100 ============= \n");
	wqueue_advance(100);
	/*
	 * now we should be able to insert the processes
	 */
	for (i = NUM_PROCESS * 2; i < NUM_PROCESS * 3; ++i) {
		wqueue_add(&procs[i]);
	}
	p = wqueue_get_ready();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in ready queue\n");

	p = wqueue_get_blocked();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in blocked queue\n");

	/*
	 * add processes with release time without a wrap these processes should be 
	 * listed first altough they are after the previous processes in the matrix
	 * datastructure (test time line wraping) 
	 */
	for (i = NUM_PROCESS; i < NUM_PROCESS * 2; ++i) {
		if (add_process_code(&procs[i], 0, 0, 0))
			printf("error in add_process_code %d\n", i);
		add_process_task(&procs[i], i);
		set_process_state(&procs[i], TASK_STATE_BLOCKED);
		wqueue_add(&procs[i]);
	}
	p = wqueue_get_ready();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in ready queue\n");

	p = wqueue_get_blocked();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in blocked queue\n");
	/*
	 * advance to time for release of the last added procs 
	 */
	fprintf(stderr, "============= advance to 160 ============= \n");
	wqueue_advance(160);
	p = wqueue_get_ready();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in ready queue\n");

	p = wqueue_get_blocked();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in blocked queue\n");
	/*
	 * advance to time for release of the last added procs 
	 */
	fprintf(stderr, "============= advance to 199 ============= \n");
	wqueue_advance(199);
	p = wqueue_get_ready();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in ready queue\n");

	p = wqueue_get_blocked();
	if (p)
		fprintf(stderr, "-%d<%d,%d>-\n", p->pid, p->task.deadline,
				p->task.release);
	else
		fprintf(stderr, "ERROR: no entry in blocked queue\n");

	/*
	 * now take over some procs in the ready queue 
	 */
	fprintf(stderr, "============= advance to 220 ============= \n");
	wqueue_advance(220);
	return 0;
}
#endif /* WQUEUE_TEST */
