/*
 *  The Tiptoe Project
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "queue.h"

#include <stdio.h>
#include <unistd.h>
#if defined DEBUG_QUEUE || defined WQUEUE_TEST
#include "process.h"
static void _print_queue(struct queue_head *head)
{
	struct list_head *pos;
	struct Process *p;
	int key, prev_key;

	if (list_empty(&head->list)) {
		fprintf(stderr, "\n");
		printf("\n");
		return;
	}

	key = prev_key = 0;

	list_for_each(pos, &head->list) {
		p = queue_to_process(pos);
		key = ((struct queue_entry *)pos)->key;
		fprintf(stderr, "-%d(%d)-", p->pid, key);
		printf("[%d]", p->pid);
		if (prev_key > key)
			fprintf(stderr,
					"******* ERROR: LIST NOT ASCENDING *************\r\n");
		prev_key = key;
	}

	fprintf(stderr, "\trev: ");

	list_for_each_prev(pos, &head->list) {
		p = queue_to_process(pos);
		fprintf(stderr, "-%d-", p->pid);
	}
	printf("\n");
	fprintf(stderr, "\r\n");
}
#else
static void _print_queue(struct queue_head *head)
{
}
#endif

#ifndef NULL
#define NULL (void *)0
#endif


/* return an element with key or the first element with a
 * larger key than key; NULL when the list is empty
 */
static struct queue_entry *find_key(struct queue_head *head, int key)
{
	struct list_head *pos;
	struct queue_entry *retval;

	retval = NULL;
	if (!list_empty(&head->list)) {
		list_for_each(pos, &head->list) {
			retval = (struct queue_entry *)pos;
			if (retval->key >= key)
				break;
		}
		if (pos == &head->list || retval->key != key)
			retval = NULL;
	}
	return retval;
}

/*
 * return pointer to the first element with a larger key than key
 */
static struct list_head *find_next_key(struct queue_head *head, int key)
{
	struct list_head *pos;
	struct queue_entry *entry;

	if (!list_empty(&head->list)) {
		list_for_each(pos, &head->list) {
			entry = (struct queue_entry *)pos;
			if (entry->key > key)
				break;
		}
	} else {
		pos = &head->list;
	}
	return pos;
}

static int _add(struct queue_head *dest, struct queue_entry *new, int key1, int key2)
{
	struct list_head *list;

	if (!list_empty(&new->list) &&
		(new->list.next != LIST_POISON1 || new->list.prev != LIST_POISON2))
		fprintf(stderr,
				"\n\n\t************ ERROR: list not empty ****************\n");

	new->key = key1;
	list = find_next_key(dest, key1);
	list_add_tail(list, &new->list);
	new->head = dest;
	return 0;
}

static struct queue_entry *_get(struct queue_head *head)
{
	struct queue_entry *entry;

	if (list_empty(&head->list))
		entry = NULL;
	else
		entry = (struct queue_entry *)head->list.next;

	return entry;
}

static struct queue_entry *_get_key(struct queue_head *head, int key)
{
	return find_key(head, key);
}

static int _remove(struct queue_head *head, struct queue_entry *entry)
{
	list_del(&entry->list);
	entry->head = NULL;
	return 0;
}

static struct queue_entry *_get_next_entry(struct queue_head *head,
												struct queue_entry *entry)
{
	struct list_head *retval;
	retval = NULL;
	if (!list_empty(&entry->list) && entry->list.next != &head->list) {
		retval = entry->list.next;
	}
	return (struct queue_entry *)retval;
}

static int _move(struct queue_head *dest, struct queue_head *src, int key,
					   int (*op) (struct queue_entry *))
{
	struct queue_entry *entry, *next;
	int count = 0;
	entry = _get(src);
	int new_key;
	while (entry && entry->key <= key) {
		next = _get_next_entry(src, entry);

		_remove(src, entry);
		if (op)
			new_key = op(entry);
		else
			new_key = entry->key;
		_add(dest, entry, new_key, 0);

		entry = next;
		++count;
	}
	return count;
}


static void set_current_key(struct queue_head *head, int key)
{
	int next_key;

	if(!list_empty(&head->list)) {
		next_key = ((struct queue_entry *)head->list.next)->key;
		if (next_key < key)
			fprintf(stderr, "ERROR %s %d: time overrun, new key %d, first key in list %d\n", __FILE__, __LINE__, key, next_key);
	}
}

static int get_alloc_count()
{
	return 0;
}

static long get_mem_usage()
{
	return 0;
}

void queue_entry_init(struct queue_entry *entry)
{
	INIT_LIST_HEAD(&entry->list);
	entry->key = -1;
	entry->head = NULL;
}

void queue_head_init(struct queue_head *head)
{
	INIT_LIST_HEAD(&head->list);
	head->add = _add;
	head->remove = _remove;
	head->get = _get;
	head->get_key = _get_key;
	head->move = _move;
	head->get_next = _get_next_entry;
	head->set_current_key = set_current_key;
	head->mem_usage = get_mem_usage;
	head->alloc_count = get_alloc_count;
	head->print_queue = _print_queue;
}
