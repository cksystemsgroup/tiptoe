/*
 *  The Tiptoe Project
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "queue.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#if defined DEBUG_QUEUE || defined WQUEUE_TEST
#include "process.h"
static void _print_queue(struct queue_head *head)
{
	struct list_head *pos;
	struct Process *p;
	int i, ai;
	int key, prev_key;

	fprintf(stderr, "[%d]: \t====\t", head->array.current_key);
	key = prev_key = 0;

	for(i=0;i<MAX_ELEMENTS; ++i) {
		ai = (head->array.current_key + i)&INDEX_MASK;
		list_for_each(pos, &head->array.array[ai]) {
			p = queue_to_process(pos);
			key = ((struct queue_entry *)pos)->key;
			printf("[%d]", p->pid);
			fprintf(stderr, "-%d(%d, %d)-", p->pid, i, key);
			if (prev_key > key)
				fprintf(stderr,
						"******* ERROR: LIST NOT ASCENDING *************\r\n");
			prev_key = key;
		}
	}

	fprintf(stderr, "\trev: ");

	for(i=1;i<=MAX_ELEMENTS; ++i) {
		ai = (head->array.current_key - i)&INDEX_MASK;
		list_for_each_prev(pos, &head->array.array[ai]) {
			p = queue_to_process(pos);
			fprintf(stderr, "-%d-", p->pid);
		}
	}
	printf("\n");
	fprintf(stderr, "\r\n");
}
#else
static void _print_queue(struct queue_head *head)
{
}
#endif

#ifndef NULL
#define NULL (void *)0
#endif


static inline int find_idx(struct array *q, int key)
{
	int index;
	/* overflow: element to far into the future */
	if(key > q->current_key + MAX_ELEMENTS-1) {
		fprintf(stderr, "ERROR %s %d: key to far into the future: key %d, current %d, resolution %d\n", __FILE__, __LINE__, key, q->current_key, MAX_ELEMENTS);
		return -1;
	}

	index = (key) & INDEX_MASK;
	return index;
}

#ifdef USE_BITMAP
static inline void _add_bit(struct array *q, int index)
{
	bitmap_set(q->map, MAX_ELEMENTS, index);
}

static inline void _rm_bit(struct array *q, int index)
{
	if (list_empty(&q->array[index]))
		bitmap_clear(q->map, MAX_ELEMENTS, index);
}

static inline struct list_head *_get_entry(struct array *q, int offset)
{
	int i;
	struct list_head *retval;

	retval = NULL;
	i = find_next_bit_circular(q->map, MAX_ELEMENTS, offset&INDEX_MASK);
	if (i < MAX_ELEMENTS) {
		if (list_empty(&q->array[i])) {
			/* ERROR: if bit is set there has to be an element */
			fprintf(stderr, "ERROR: bitmap is not matching array\n");
			exit(6);
		}
		retval = q->array[i].next;
	}
	return retval;
}
#else
static inline void _add_bit(struct array *q, int index)
{
}
static inline void _rm_bit(struct array *q, int index)
{
}

static inline struct list_head *_get_entry(struct array *q, int offset)
{
	struct list_head *retval;
	int i;

	retval = NULL;
	for (i=0;i<MAX_ELEMENTS; ++i) {
		if (!list_empty(&q->array[(offset + i)&INDEX_MASK])) {
			retval = q->array[(offset + i)&INDEX_MASK].next;
			break;
		}
	}
	return retval;
}
#endif /* USE_BITMAP */

static int _add(struct queue_head *dest, struct queue_entry *new, int key1, int key2)
{
	int i;
	struct array *q = &dest->array;

	i = find_idx(q, key1);
	if (i < 0) {
		fprintf(stderr, "OVERFLOW ERROR: could not add entry to ready queue\r\n");
		exit(5);
	}

	new->key = key1;
	list_add_tail(&q->array[i], &new->list);
	_add_bit(q, i);
	new->head = dest;
	return 0;
}

static struct queue_entry *_get(struct queue_head *head)
{
	struct array *q = &head->array;
	return (struct queue_entry *)_get_entry(q, q->current_key);
}

static struct queue_entry *_get_key(struct queue_head *head, int key)
{
	struct array *q = &head->array;
	struct queue_entry *retval;
	retval = (struct queue_entry *)_get_entry(q, key);

	if (retval && retval->key == key)
		return retval;
	else
		return NULL;
}

static int _remove(struct queue_head *head, struct queue_entry *entry)
{
	list_del_init(&entry->list);
	_rm_bit(&head->array, find_idx(&head->array, entry->key));
	entry->head = NULL;
	return 0;
}

static struct queue_entry *_get_next_entry(struct queue_head *head,
											struct queue_entry *entry)
{
	struct queue_entry *retval;

	if (list_empty(&entry->list))
		return NULL;

	if (entry->list.next >= &head->array.array[0]
		&&	entry->list.next <= &head->array.array[MAX_ELEMENTS -1] ) {
		retval = (struct queue_entry *)_get_entry(&head->array, entry->key + 1);
	 } else {
		retval = (struct queue_entry *)entry->list.next;
	 }

	return retval;
}

static int _move(struct queue_head *dest, struct queue_head *src, int key,
					   int (*op) (struct queue_entry *))
{
	struct queue_entry *entry, *next, *start;
	start = _get(src);
	int new_key;
	int count;

	count = 0;
	entry = start;
	while (entry && entry->key <= key) {
		next = _get_next_entry(src, entry);

		_remove(src, entry);
		if (op)
			new_key = op(entry);
		else
			new_key = entry->key;

		if (_add(dest, entry, new_key, 0)) {
			fprintf(stderr, "OVERFLOW ERROR: could not add entry to ready queue\r\n");
			exit(5);
		}

		if (next == start)
			break;

		entry = next;
		++count;
	}
	return count;
}

static void set_current_key(struct queue_head *head, int key)
{
	head->array.current_key = key;
}

static int get_alloc_count()
{
#ifdef USE_BITMAP
	long count, calls;
	count = get_bitmap_loop_count();
	calls = get_bitmap_loop_calls();
#endif
	return 0;
}

static long mem_usage = 0;
static long get_mem_usage()
{
	return mem_usage;
}

void queue_entry_init(struct queue_entry *entry)
{
	INIT_LIST_HEAD(&entry->list);
	entry->key = -1;
	entry->head = NULL;
}

void queue_head_init(struct queue_head *head)
{
	int i;
	for (i=0;i<MAX_ELEMENTS;++i) {
		INIT_LIST_HEAD(&head->array.array[i]);
	}
	head->array.current_key = 0;
	bitmap_zero(head->array.map, MAX_ELEMENTS);
	mem_usage += sizeof(head->array);

	head->add = _add;
	head->remove = _remove;
	head->get = _get;
	head->get_key = _get_key;
	head->move = _move;
	head->get_next = _get_next_entry;
	head->set_current_key = set_current_key;
	head->mem_usage = get_mem_usage;
	head->alloc_count = get_alloc_count;
	head->print_queue = _print_queue;
}

