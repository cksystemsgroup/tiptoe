/*
 *  The Tiptoe Project
 *  Copyright (c) 2008 Silviu Craciunas (scraciunas@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <curses.h>
#include <stdbool.h>
#include <curses.h>
#include <syscall.h>
#include <sys/ptrace.h>
#include <stdint.h>
#include <sys/time.h>

#include "workqueue.h"
#include "process.h"
#include "scheduler.h"
#include "err.h"
#include "analysis.h"
#include "generic.h"

static long call_limit = 2000000;
#define TIMER_LIMIT call_limit
#define CALL_LIMIT call_limit
#define MAX_PROCESSES 1000
#define MAX_NAME 255
#define PROCESS_COMM_LEN 300
#define MIN_RATE 20
#define MAX_LINES 50000

static int timer = 0;
#define C_RED          1
#define C_GREEN        2
#define C_WHITE        3

static int64_t overhead = 0, sec_overhead = 0, sched_calls =
	0, overhead_square = 0, sec_overhead_square;

static int nr_procs;
static int create_log;

/* FIXME: for IA32 only */
static inline uint64_t rdtsc()
{
	uint32_t lo, hi;
	__asm__ __volatile__("rdtsc":"=a"(lo), "=d"(hi));
	return (uint64_t) hi << 32 | lo;
}


static float process_utilization[MAX_PROCESSES];

/**
 * add_process_resource_descriptor
 *
 * adds a process resource descriptor for process p
 */
static int add_process_resource_descriptor(struct Process *p, int resource,
		int limit, int period)
{
	float u;

	if (p == NULL)
		return -1;

	add_process_descriptor(p, resource, limit, period);

	u = (float)get_process_resource_limit(p, resource) / (float)period;
	if (u > process_utilization[get_pid(p)])
		process_utilization[get_pid(p)] = u;

	return 1;
}

static int read_input(char *filename)
{
	int i, j, l, period, type, index, res_limit, res_period, code_load,
		code_res;
	char code[MAX_LINES][128];
	char line[128];				/* or other suitable maximum line size */
	struct Process *process;
	FILE *file = fopen(filename, "r");
	if (!file) {
		perror(filename);
		return -1;
	}

	l = 0;
	while (feof(file) == 0) {
		fgets(line, 128, file);	/* Read next record */
		if (line[0] == '#')
			continue;			/* filter out the comments */
		strcpy(code[l], line);
		l++;
		if (l >= MAX_LINES) {
			fprintf(stderr,
					"ERROR %s %d: buffer smaller than file"
					"(we should not read the whole file at once)\n",
					__FILE__, __LINE__);
			return -1;
		}
	}
	fclose(file);

	nr_procs = atoi(code[1]);

	index = 2;
	for (i = 0; i < nr_procs; i++) {
		log("adding new process %d\n", i + 1);
		type = atoi(code[index++]);
		period = atoi(code[index++]);
		if (index >= l) {
			fprintf(stderr, "WARNING %s %d: reached end of input\n", __FILE__,
					__LINE__);
			return 0;
		}
		log("process %d, period : %d\n", i + 1, period);
		log("process %d, type : %d\n", i + 1, type);

		process = new_process(timer, type, period);

		for (j = 0; j < NUM_RESOURCES; j++) {
			res_limit = atoi(code[index++]);
			res_period = atoi(code[index++]);
			if (index >= l) {
				fprintf(stderr, "WARNING %s %d: reached end of input\n",
						__FILE__, __LINE__);
				return -1;
			}
			if (res_period == 0) {
				fprintf(stderr,
						"ERROR %s %d: i=%d j=%d period of 0 is invalid\n",
						__FILE__, __LINE__, i, j);
				return -1;

			}
			add_process_resource_descriptor(process, j, res_limit, res_period);
		}
		for (j = 0; j < period; j++) {
			code_load = atoi(code[index++]);
			code_res = atoi(code[index++]);
			if (index >= l) {
				fprintf(stderr, "WARNING %s %d: reached end of input\n",
						__FILE__, __LINE__);
				return -1;
			}
			add_process_code(process, code_load, code_res, j);
		}
		add_process_task(process, timer);
		log("process %d, put on blocked\n", i + 1);
		set_process_state(process, TASK_STATE_BLOCKED);
		wqueue_add(process);
	}
	return 0;
}


#ifndef NUSE_CURSES
static float idle_time;
static int io_utilization, mem_utilization;

static WINDOW *mainwnd;
static WINDOW *screen;

static float calculate_utilization(int n)
{
	float u = 0.0;
	int i;
	for (i = 1; i <= n; i++) {
		if (process_utilization[i] > 0.0)
			u += process_utilization[i];
		log("U : %3.1f", u);
	}
	return (float)u;
}

static void screen_init(void)
{
	mainwnd = initscr();
	if (has_colors() == FALSE) {
		endwin();
		printf("Your terminal does not support color\n");
		exit(1);
	}
	start_color();				/* Start color */
	init_pair(C_GREEN, 2, 0);
	init_pair(C_RED, 1, 0);
	init_pair(C_WHITE, 7, 0);
	noecho();
	cbreak();
	refresh();
	wrefresh(mainwnd);
	screen = newwin(33, 90, 1, 1);
	box(screen, ACS_VLINE, ACS_HLINE);
}

static void screen_end(void)
{
	endwin();
}

static void refresh_screen(int time)
{
	int posy = 0;
	int time2;
	struct Process *start;
	struct Process *tmp;

	if (time == 0)
		time2 = 1;
	else
		time2 = time;
	curs_set(0);
	mvwprintw(screen, 1, 1,
			  "----------------------- SYSTEM ------------------------");
	mvwprintw(screen, 2, 2, "TIME: %4d", time);
	if (get_pid(sched_get_current()) != sched_get_idle_pid())
		mvwprintw(screen, 3, 2, "Running pid [%4d] for time [%d]    ",
				  get_pid(sched_get_current()),
				  get_process_run_time(sched_get_current()));
	else
		mvwprintw(screen, 3, 2, "System idle for time [%d]        ",
				  get_process_run_time(sched_get_current()));

	if (sched_overload()
		|| (get_pid(sched_get_current()) != sched_get_idle_pid()
			&& get_process_deadline(sched_get_current()) < time)) {
		wattron(screen, COLOR_PAIR(C_RED));
		mvwprintw(screen, 20, 2,
				  " SCHEDULING FAILED!                                                          ");
		wattroff(screen, COLOR_PAIR(C_RED));
		getch();
	}

	mvwprintw(screen, 4, 2,
			  "Scheduler overhead: %lld sec %lld usec Scheduler calls: %lld   ",
			  sec_overhead, overhead, sched_calls);
	mvwprintw(screen, 5, 2,
			  "PID |  Load  | Release | Deadline | Supply    | Resource | CPU [%]");
	if (get_pid(sched_get_current()) != sched_get_idle_pid()) {
		wattron(screen, COLOR_PAIR(C_GREEN));
		mvwprintw(screen, 6, 2, "%3d | %6d | %7d | %8d | %9d | %8d | %3.1f   ",
				  get_pid(sched_get_current()),
				  get_process_load(sched_get_current()),
				  get_process_release(sched_get_current()),
				  get_process_deadline(sched_get_current()),
				  get_process_supply(sched_get_current()),
				  get_process_resource(sched_get_current()),
				  (sched_get_current()->sum_run_time * 100) / time2);
		wattroff(screen, COLOR_PAIR(C_GREEN));
	} else {
		wattron(screen, COLOR_PAIR(C_GREEN));
		mvwprintw(screen, 6, 2,
				  " idle                                                                 ");
		wattroff(screen, COLOR_PAIR(C_GREEN));
	}

	// ready
	start = wqueue_get_ready();

	tmp = start;
	while (tmp != NULL) {
		wattron(screen, COLOR_PAIR(C_WHITE));
		mvwprintw(screen, 7 + posy, 2,
				  "%3d | %6d | %7d | %8d | %9d | %8d | %3.1f   ", get_pid(tmp),
				  get_process_load(tmp), get_process_release(tmp),
				  get_process_deadline(tmp), get_process_supply(tmp),
				  get_process_resource(tmp), (tmp->sum_run_time * 100) / time2);
		wattroff(screen, COLOR_PAIR(C_WHITE));
		tmp = wqueue_get_next(tmp);
		posy++;
		if (tmp == start)
			break;
	}

	// blocked
	start = wqueue_get_blocked();

	tmp = start;
	while (tmp != NULL) {
		wattron(screen, COLOR_PAIR(C_RED));
		mvwprintw(screen, 7 + posy, 2,
				  "%3d | %6d | %7d | %8d | %9d | %8d | %3.1f   ",
				  get_pid(tmp), get_process_load(tmp),
				  get_process_release(tmp), get_process_deadline(tmp),
				  get_process_supply(tmp), get_process_resource(tmp),
				  tmp->sum_run_time * 100 / time2);
		wattroff(screen, COLOR_PAIR(C_RED));
		tmp = wqueue_get_next(tmp);
		posy++;
		if (tmp == start)
			break;
	}

	mvwprintw(screen, 7 + posy, 2,
			  "                                                                ");
	mvwprintw(screen, 7 + posy + 1, 2,
			  "                                                              ");

	wattron(screen, COLOR_PAIR(C_WHITE));
	mvwprintw(screen, 23, 2, " CPU idle for %3.1f\%     ",
			  (idle_time * 100) / time2);
	wattroff(screen, COLOR_PAIR(C_WHITE));

	wattron(screen, COLOR_PAIR(C_WHITE));
	mvwprintw(screen, 24, 2, " CPU utilization : TOTAL[%1.3f] ", calculate_utilization(nr_procs));
	mvwprintw(screen, 25, 2, " MEM utilization : %8d KB  / %8d KB ",
			  mem_utilization, AVAILABLE_MEM);
	mvwprintw(screen, 26, 2, " IO utilization  : %8d KB/s / %8d KB/s ",
			  io_utilization, AVAILABLE_IO);
	wattroff(screen, COLOR_PAIR(C_WHITE));

	wattron(screen, COLOR_PAIR(C_RED));
	if (mem_utilization > AVAILABLE_MEM)
		mvwprintw(screen, 27, 2, " RESOURCE OVERLOAD : [MEM]");
	if (io_utilization > AVAILABLE_IO)
		mvwprintw(screen, 28, 2, " RESOURCE OVERLOAD : [IO]");
	wattroff(screen, COLOR_PAIR(C_RED));

	wrefresh(screen);

	refresh();
}
#else
static inline void screen_init(void)
{
}
static inline void screen_end(void)
{
}

static inline void refresh_screen(int time)
{
}
#endif

#ifndef TF_TRACE
static inline void TF_open(const char *name)
{
}
static inline void TF_trace(uint64_t before, uint64_t after, long lreleased)
{

}
#else  /* TF_TRACE */
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>

#define TF_PORT 9001
#define TF_SERVER "192.168.1.7"
#define TF_FILE tf_file
static int tf_file = 0;
static void TF_open(const char *name)
{
	int s;
	int err;
	struct sockaddr_in sin;
	struct hostent *host = gethostbyname(TF_SERVER);

	s = socket(PF_INET, SOCK_STREAM, 0);
	if (!s) {
		perror("socket");
		return;
	}

	memcpy(&sin.sin_addr.s_addr, host->h_addr, host->h_length);
	sin.sin_family = AF_INET;
	sin.sin_port = htons(TF_PORT);

	printf("connect to %s on port %d\n", TF_SERVER, TF_PORT);
	err = connect(s, (struct sockaddr *)&sin, sizeof(sin));
	if (err) {
		perror("connect");
		return;
	}

	printf("connected\n");
	tf_file = s;
	write(s, name, strlen(name));
	write(s, "\n", 1);
}

#define LINE_LENGTH 512
#define TICKS_PER_SECOND 2000000000l	/* 2 GHz */
#define TICKS_PER_USEC   (TICKS_PER_SECOND/1000000)
static void TF_trace(uint64_t before, uint64_t after, long lreleased)
{
	if (tf_file) {
		char buf[LINE_LENGTH];
		int len;
		len =
			snprintf(buf, LINE_LENGTH, "%lld Scheduler Start\n",
					 before / TICKS_PER_USEC);
		write(TF_FILE, buf, len);
		len =
			snprintf(buf, LINE_LENGTH, "%lld released %ld\n",
					 before / TICKS_PER_USEC, lreleased);
		write(TF_FILE, buf, len);
		len =
			snprintf(buf, LINE_LENGTH, "%lld duration %lld\n",
					 before / TICKS_PER_USEC,
					 (after - before) / TICKS_PER_USEC);
		write(TF_FILE, buf, len);
		len =
			snprintf(buf, LINE_LENGTH, "%lld Scheduler Stop\n",
					 after / TICKS_PER_USEC);
		write(TF_FILE, buf, len);
	}
}
#endif  /* TF_TRACE */

static int run_simulation()
{
	struct timeval before, after;
	int64_t duration;
	int64_t max, min;
	int changed = 0;
	int released = 0;
	long lreleased = 0;
	uint64_t ts_before, ts_after, ts_start;

	max = min = -1;

	screen_init();

	ts_start = rdtsc(); /* use timestamp counter to measure overhead */
	while (sched_calls < CALL_LIMIT) {
		released = wqueue_to_release(timer);
		gettimeofday(&before, NULL);

		ts_before = rdtsc();
		if (scheduler(timer) < 0)
			break; /* no more processes */
		ts_after = rdtsc();

		gettimeofday(&after, NULL);
		if (sched_calls > 10)
			TF_trace(ts_before - ts_start, ts_after - ts_start, lreleased);

		timer += get_process_run_time(sched_get_current());

		duration =
			after.tv_usec + 1000000 * (after.tv_sec - before.tv_sec) -
			before.tv_usec;

		if (sched_calls > 10 && duration > max) {
			changed = 1;
			max = duration;
		}
		if (sched_calls > 10 && (min == -1 || duration < min)) {
			changed = 1;
			min = duration;
		}

		overhead += duration;
		overhead_square += duration * duration;
		if (overhead > 1000000) {
			++sec_overhead;
			overhead -= 1000000;
		}
		if (overhead_square > 1000000) {
			++sec_overhead_square;
			overhead_square -= 1000000;
		}
		++sched_calls;

		refresh_screen(timer);

		if (changed) {
			log("dur: %4lld min: %4lld max: %4lld ohd: %lld.%06lld calls: %7lld ",
				 duration, min, max, sec_overhead, overhead, sched_calls);
			log("running <%4d> timer: [%8d] released: %d \n",
				   sched_get_current()->pid, timer, released);
			changed = 0;
		}
	}
	getch();

	screen_end();

	{ /* not nice */
		double stddev =
			sqrt((sched_calls *
						((double)sec_overhead_square * 1000000.0 + overhead_square) -
						(((double)sec_overhead * 1000000.0 +
						  overhead) * ((double)sec_overhead * 1000000.0 +
							  overhead))) / (((double)sched_calls) *
						  ((double)sched_calls - 1)));
		double avg = ((double)sec_overhead * 1000000 + overhead) / sched_calls;
		printf("average response time : %d \n", get_average_response_time());
		printf
			("DONE: min: %4lld max: %4lld avg: %f stdev: %f ohd: %lld,%06lld calls: %7lld\n",
			 min, max, avg, stddev, sec_overhead, overhead, sched_calls);
		printf("timer: %d\n", timer);
	}
	return 0;
}

static void usage(char *name)
{
	printf("usage: %s call_limit input_file [-l]\n", name);
}

int main(int argc, char **argv)
{
	int res = 1;
	long mem_usage;

	create_log = 0;

	if (argc < 3 || argc > 5) {
		usage(argv[0]);
		exit(0);
	}

	if (argc == 5)
		if (!strcmp(argv[4], "-l"))
			create_log = 1;

	call_limit = atoi(argv[1]);

	sched_init();

	if (argc >= 4)
		TF_open(argv[3]);

	if (!read_input(argv[2])) {
		res = run_simulation();
		mem_usage = wqueue_mem_usage();
		printf("memory usage: %ld b %ld kb %ld mb\n", mem_usage,
			   mem_usage / 1024, mem_usage / (1024 * 1024));
		printf("alloc count: %d\n", wqueue_alloc_count());

	}
	return res;
}
