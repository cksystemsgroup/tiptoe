/*
 *  The Tiptoe Project
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#ifndef T_MATRIX_QUEUE_H
#define T_MATRIX_QUEUE_H

#include <utils/list.h>
#include <utils/bitmap.h>

typedef unsigned long map_t[MAX_ELEMENTS];

struct q_matrix
{
	unsigned long row_map[MAX_ELEMENTS][BITS_TO_LONGS(MAX_ELEMENTS) + BITMAP_OVERHEAD];
	unsigned long col_map[MAX_ELEMENTS][BITS_TO_LONGS(MAX_ELEMENTS) + BITMAP_OVERHEAD];
};

struct matrix
{
	int current_key;
	int _rel_; /* row or column used of the matrix */
	int next_started;
	DECLARE_BITMAP(master_map, MAX_ELEMENTS);
};

#define DECLARE_MATRIX_HEAD(l) struct matrix l

#endif
