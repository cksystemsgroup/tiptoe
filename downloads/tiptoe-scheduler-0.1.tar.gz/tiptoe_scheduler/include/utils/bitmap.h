/*
 * original version taken from the linux kernel sources
 * modified to use bitmap trees to speed up operations from
 * linear to logarithmic
 */
#ifndef T_BITMAP_H
#define T_BITMAP_H

#include "asm/bitmap.h"
#include <string.h>

/*
 * bitmap trees
 *
 * FIXME: make it cleaner
 */
#define MAX_BITMAP_LEVELS 3
/* this works up to 2^14; the +1 is need for the level word */
#define BITMAP_OVERHEAD   (17+1) /* if set to zero no tree will be used */

/* standard bitmaps */
#define BITS_TO_LONGS(bits) \
	(((bits)+BITS_PER_LONG-1)/BITS_PER_LONG)

#define DECLARE_BITMAP(name,bits) \
	unsigned long name[BITS_TO_LONGS(bits) + BITMAP_OVERHEAD]

extern int __bitmap_empty(const unsigned long *bitmap, int bits);
extern int __bitmap_full(const unsigned long *bitmap, int bits);
extern int __bitmap_equal(const unsigned long *bitmap1,
                	const unsigned long *bitmap2, int bits);
extern void __bitmap_complement(unsigned long *dst, const unsigned long *src,
			int bits);
extern void __bitmap_shift_right(unsigned long *dst,
                        const unsigned long *src, int shift, int bits);
extern void __bitmap_shift_left(unsigned long *dst,
                        const unsigned long *src, int shift, int bits);
extern void __bitmap_and(unsigned long *dst, const unsigned long *bitmap1,
			const unsigned long *bitmap2, int bits);
extern void __bitmap_or(unsigned long *dst, const unsigned long *bitmap1,
			const unsigned long *bitmap2, int bits);
extern void __bitmap_xor(unsigned long *dst, const unsigned long *bitmap1,
			const unsigned long *bitmap2, int bits);
extern void __bitmap_andnot(unsigned long *dst, const unsigned long *bitmap1,
			const unsigned long *bitmap2, int bits);
extern int __bitmap_intersects(const unsigned long *bitmap1,
			const unsigned long *bitmap2, int bits);
extern int __bitmap_subset(const unsigned long *bitmap1,
			const unsigned long *bitmap2, int bits);

extern long __find_first_bit(const unsigned long *addr, long size);
extern long long get_bitmap_loop_count();
extern long long get_bitmap_loop_calls();
extern void inc_bitmap_loop_count();
extern void inc_bitmap_loop_calls();


#define BITMAP_LAST_WORD_MASK(nbits)					\
(									\
	((nbits) % BITS_PER_LONG) ?					\
		(1UL<<((nbits) % BITS_PER_LONG))-1 : ~0UL		\
)

static inline void bitmap_set(unsigned long *dst, int size, int bit)
{
	inc_bitmap_loop_calls();
	inc_bitmap_loop_count();
	set_bit(bit, dst);

#if BITMAP_OVERHEAD > 0
	unsigned long *maps[MAX_BITMAP_LEVELS];
	long levels = *(dst + BITS_TO_LONGS(size));
	int i;
	maps[0] = dst + BITS_TO_LONGS(size) + 1;
	maps[1] = maps[0] + 1;
	maps[2] = maps[1] + BITS_PER_LONG;

	for(i=0; i < levels; ++i) {
		bit >>= BITS_PER_LEVEL;
		set_bit(bit, maps[levels - 1 - i]);
	}
#endif
}

static inline void bitmap_clear(unsigned long *dst, int size, int bit)
{
	inc_bitmap_loop_calls();
	inc_bitmap_loop_count();
	clear_bit(bit, dst);

#if BITMAP_OVERHEAD > 0
	if(!dst[bit/BITS_PER_LONG]) {
		unsigned long *maps[MAX_BITMAP_LEVELS];
		long levels = *(dst + BITS_TO_LONGS(size));
		int i;

		maps[0] = dst + BITS_TO_LONGS(size) + 1;
		maps[1] = maps[0] + 1;
		maps[2] = maps[1] + BITS_PER_LONG;
		for(i=0; i < levels; ++i) {
			bit >>= BITS_PER_LEVEL;
			clear_bit(bit, maps[levels - 1 - i]);
			if(maps[levels - 1 - i][bit/BITS_PER_LONG])
				break;
		}
	}
#endif
}

static inline void bitmap_zero(unsigned long *dst, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		*dst = 0UL;
	else {
		int len = BITS_TO_LONGS(nbits) * sizeof(unsigned long);
		memset(dst, 0, len + BITMAP_OVERHEAD*sizeof(unsigned long));
#if BITMAP_OVERHEAD > 0
		int levels = 0;
		int i = BITS_TO_LONGS(nbits);
		while (i > 1){
			i = BITS_TO_LONGS(i);
			levels++;
		}
		dst[BITS_TO_LONGS(nbits)] = levels;
#endif
	}
}

static inline void bitmap_fill(unsigned long *dst, int nbits)
{
	int nlongs = BITS_TO_LONGS(nbits);
	if (nlongs > 1) {
		int len = (nlongs - 1) * sizeof(unsigned long);
		memset(dst, 0xff,  len);
	}
	dst[nlongs - 1] = BITMAP_LAST_WORD_MASK(nbits);
}

static inline void bitmap_copy(unsigned long *dst, const unsigned long *src,
			int nbits)
{
	if (nbits <= BITS_PER_LONG)
		*dst = *src;
	else {
		int len = BITS_TO_LONGS(nbits) * sizeof(unsigned long);
		memcpy(dst, src, len);
	}
}

static inline void bitmap_and(unsigned long *dst, const unsigned long *src1,
			const unsigned long *src2, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		*dst = *src1 & *src2;
	else
		__bitmap_and(dst, src1, src2, nbits);
}

static inline void bitmap_or(unsigned long *dst, const unsigned long *src1,
			const unsigned long *src2, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		*dst = *src1 | *src2;
	else
		__bitmap_or(dst, src1, src2, nbits);
}

static inline void bitmap_xor(unsigned long *dst, const unsigned long *src1,
			const unsigned long *src2, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		*dst = *src1 ^ *src2;
	else
		__bitmap_xor(dst, src1, src2, nbits);
}

static inline void bitmap_andnot(unsigned long *dst, const unsigned long *src1,
			const unsigned long *src2, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		*dst = *src1 & ~(*src2);
	else
		__bitmap_andnot(dst, src1, src2, nbits);
}

static inline void bitmap_complement(unsigned long *dst, const unsigned long *src,
			int nbits)
{
	if (nbits <= BITS_PER_LONG)
		*dst = ~(*src) & BITMAP_LAST_WORD_MASK(nbits);
	else
		__bitmap_complement(dst, src, nbits);
}

static inline int bitmap_equal(const unsigned long *src1,
			const unsigned long *src2, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		return ! ((*src1 ^ *src2) & BITMAP_LAST_WORD_MASK(nbits));
	else
		return __bitmap_equal(src1, src2, nbits);
}

static inline int bitmap_intersects(const unsigned long *src1,
			const unsigned long *src2, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		return ((*src1 & *src2) & BITMAP_LAST_WORD_MASK(nbits)) != 0;
	else
		return __bitmap_intersects(src1, src2, nbits);
}

static inline int bitmap_subset(const unsigned long *src1,
			const unsigned long *src2, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		return ! ((*src1 & ~(*src2)) & BITMAP_LAST_WORD_MASK(nbits));
	else
		return __bitmap_subset(src1, src2, nbits);
}

static inline int bitmap_empty(const unsigned long *src, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		return ! (*src & BITMAP_LAST_WORD_MASK(nbits));
	else
		return __bitmap_empty(src, nbits);
}

static inline int bitmap_full(const unsigned long *src, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		return ! (~(*src) & BITMAP_LAST_WORD_MASK(nbits));
	else
		return __bitmap_full(src, nbits);
}

static inline void bitmap_shift_right(unsigned long *dst,
			const unsigned long *src, int n, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		*dst = *src >> n;
	else
		__bitmap_shift_right(dst, src, n, nbits);
}

static inline void bitmap_shift_left(unsigned long *dst,
			const unsigned long *src, int n, int nbits)
{
	if (nbits <= BITS_PER_LONG)
		*dst = (*src << n) & BITMAP_LAST_WORD_MASK(nbits);
	else
		__bitmap_shift_left(dst, src, n, nbits);
}

/**
 * find_first_bit - find the first set bit in a memory region
 * @addr: The address to start the search at
 * @size: The maximum size to search
 *
 * Returns the bit-number of the first set bit, not the number of the byte
 * containing a bit.
 */
static inline long find_first_bit(const unsigned long *addr, unsigned long size)
{
	unsigned long x = 0;

	while (x < size) {
		inc_bitmap_loop_count();
		unsigned long val = *addr++;
		if (val)
			return __ffs(val) + x;
		x += (sizeof(*addr)<<3);
	}
	return x;
}

/**
 * find_next_bit - find the first set bit in a memory region
 * @addr: The address to base the search on
 * @offset: The bitnumber to start searching at
 * @size: The maximum size to search
 */
long find_next_bit(const unsigned long *addr, long size, long offset);
long __find_next_bit(const unsigned long *addr, long size, long offset);
void print_bitmap(unsigned long *map, int size);

static inline long find_next_bit_circular(const unsigned long *addr, int size, int offset)
{
	long res;

	inc_bitmap_loop_calls();
#if BITMAP_OVERHEAD > 0
	res = __find_next_bit(addr, size, offset);
	/* we found a bit */
	if (res < size)
		return res;

	/* no bit after offset; start over at the first bit */
	res = __find_first_bit(addr, size);
#else
	res = find_next_bit(addr, size, offset);
	/* we found a bit */
	if (res < size)
		return res;

	/* no bit after offset; start over at the first bit */
	res = find_first_bit(addr, size);
#endif
	return res;
}


#endif /* T_BITMAP_H */

