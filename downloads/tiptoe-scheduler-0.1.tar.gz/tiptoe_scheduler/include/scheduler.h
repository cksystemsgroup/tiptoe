/*
 *  The Tiptoe Project
 *  Copyright (c) Silviu Craciunas (scraciunas@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef SCHEDULER_H
#define SCHEDULER_H

/* FIXME : I spotted an error when changing these to other values than 1, needs debugging */
#define SYSTEM_CONVERSION_CPU 1		/* 1 time unit = 1 time unit */
#define SYSTEM_CONVERSION_MEM 1		/* 1 KB MEM = 1 time unit */
#define SYSTEM_CONVERSION_IO 1		/* 1 KB IO = 1 time unit */

#define AVAILABLE_MEM 512000
#define AVAILABLE_IO 10000
/*
 * init the scheduler infrastructure
 */
int sched_init();

/*
 * scheduler entry function
 */
int scheduler(int time);

/*
 * return true on overload
 */
int sched_overload();

/*
 * return pointer to the current process
 */
struct Process *sched_get_current();

/*
 * return pid of the idle process
 */
int sched_get_idle_pid();

#endif /* SCHEDULER_H */
