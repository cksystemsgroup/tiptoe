/*
 *  The Tiptoe Project
 *  Copyright (c) Silviu Craciunas (scraciunas@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef PROCESS_H
#define PROCESS_H

#include "queue.h"

#define PROCESS_STATE_FINISHED 0
#define PROCESS_STATE_SAME 1
#define PROCESS_STATE_DIFFERENT 2

#define MAX_CODE 255

struct ProcessState
{
	enum {
		RESOURCE_CPU = 0,
		RESOURCE_MEM,
		RESOURCE_IO,
		NUM_RESOURCES
	} resource;

	int load;	/* the exact amount of work the process will do
			 * on resource */
};

struct ProcessCode
{
	int period;					/* the period of the code */
	struct ProcessState pstate[MAX_CODE];
};

struct ResourceMargin
{
	int limit;		/* maximum amount of work a process can perform
				 * on a resource within period */
	int period;		/* the period */
};

struct Accounting
{
	int work;
	int instant;
};

struct ProcessShape
{
	int supply;
	int instant;
	
};

struct ProcessContext
{
	struct ProcessShape ps[NUM_RESOURCES];
	
};

struct Task
{
	int release;
	int deadline;
	struct ProcessState p;
};

struct Process
{
	int pid;
	enum {
		PROCESS_TYPE_PERIODIC = 0,
		PROCESS_TYPE_APERIODIC
	} type;						/* periodic or aperiodic */
	int index;					/* where we are in the code */
	struct ResourceMargin descriptor[NUM_RESOURCES];
	struct ProcessCode code;
	struct ProcessContext pc;
	struct Task task;
	struct Accounting accounting[NUM_RESOURCES];
	enum {
		TASK_STATE_RUNNING = 0,
		TASK_STATE_READY,
		TASK_STATE_BLOCKED,
		TASK_STATE_ZOMBIE
	} state;

	enum {
		TASK_RUN_IDLE = 0,
		TASK_RUN_COMPLETION,
		TASK_RUN_SUPPLY,
		TASK_RUN_RELEASE
	} run_type;

	int run_time;
	long sum_run_time;
	int last_state_change;
	
	struct queue_entry queue;
};

#define process_to_queue(p) (&p->queue)
#define queue_to_process(q) container_of((struct queue_entry *)q, struct Process, queue)

struct Process *new_process(int time, int type, int period);
void process_init(struct Process *p, int time, int type, int period);
int add_process_code(struct Process *p, int load, int resource, int state_id);
int add_process_task(struct Process *p, int time);
int set_next_process_state(struct Process *p);
int add_process_descriptor(struct Process *p, int resource, int limit, int period);

int get_pid(struct Process *p);
int set_pid(struct Process *p, int pid);
int get_process_resource_limit(struct Process *p, int resource);
int set_process_resource_limit(struct Process *p, int resource, int limit);
int get_process_resource_period(struct Process *p, int resource);
int set_process_resource_period(struct Process *p, int resource, int period);
int set_process_context_supply(struct Process *p, int resource, int supply);
int set_process_context_instant(struct Process *p, int resource, int instant);
int get_process_deadline(struct Process *p);
int set_process_deadline(struct Process *p, int deadline);
int get_process_release(struct Process *p);
int set_process_release(struct Process *p, int release);
int get_process_load(struct Process *p);
int set_process_load(struct Process *p, int load);
int sub_process_load(struct Process *p, int load);
int get_process_resource(struct Process *p);
int set_process_resource(struct Process *p, int resource);
int get_process_limit(struct Process *p);
int set_process_limit(struct Process *p, int limit);
int get_process_period(struct Process *p);
int set_process_period(struct Process *p, int period);
int get_process_supply(struct Process *p);
int set_process_supply(struct Process *p, int supply);
int get_process_instant(struct Process *p);
int set_process_instant(struct Process *p, int instant);
int get_process_state(struct Process *p);
int set_process_state(struct Process *p, int state);
int get_process_run_type(struct Process *p);
int set_process_run_type(struct Process *p, int run_type);
int get_process_run_time(struct Process *p);
int set_process_run_time(struct Process *p, int run_time);
int get_process_accounting_work(struct Process *p, int resource); 
int set_process_accounting_work(struct Process *p, int resource, int work);
int get_process_accounting_instant(struct Process *p, int resource);
int set_process_accounting_instant(struct Process *p, int resource, int instant);
int calculate_average_response_time(struct Process *p, int time);
int get_average_response_time();
#endif /* PROCESS_H */
