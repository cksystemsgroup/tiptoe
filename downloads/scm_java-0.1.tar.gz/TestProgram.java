/* Copyright (c) 2010 Andreas Haas, Stephanie Stroka
 *
 * http://cs.uni-salzburg.at/~ahaas
 * andreas.haas@sbg.ac.at
 *
 * http://cs.uni-salzburg.at/~sstroka
 * stephanie.stroka@sbg.ac.at
 * 
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Sciences, cs.uni-salzburg.at
 *
 * 
 * This file is licensed to You under the Eclipse Public License (EPL); You may
 * not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 * 
 * http://www.opensource.org/licenses/eclipse-1.0.php
 */

@org.csg.UserApplication
public class TestProgram
{
	int value;
	
	public static void main(String[] args)
	{
		TestProgram counter = create();
                int lastValue = counter.value;

                for(int i = 0; i < 200000; i++)
                {
                        if(lastValue != counter.value)
                        {
                                System.out.println("Error: The object counter was reused too early.");
                        }
                        counter.value++;
                        lastValue = counter.value;
                        for(int j = 1; j < 5; j++)
                        {
                                TestProgram a = create();
                                a.value = lastValue - j;
                        }

                        if(i % 2 == 0)
                        {
                                Runtime.getRuntime().refreshObject(counter, 2);
                        }
			Runtime.getRuntime().setGlobalTick();
		}
		
		System.out.println("Finished");
	}
	
	public static TestProgram create()
	{
		return new TestProgram();
	}	
}
