/*
 * original version taken from the linux kernel sources
 * modified to use bitmap trees to speed up operations from
 * linear to logarithmic
 */

/*
 * lib/bitmap.c
 * Helper functions for bitmap.h.
 *
 * This source code is licensed under the GNU General Public License,
 * Version 2.  See the file COPYING for more details.
 */
#include "utils/bitmap.h"
#include <stdint.h>
/*
 * bitmaps provide an array of bits, implemented using an an
 * array of unsigned longs.  The number of valid bits in a
 * given bitmap does _not_ need to be an exact multiple of
 * BITS_PER_LONG.
 *
 * The possible unused bits in the last, partially used word
 * of a bitmap are 'don't care'.  The implementation makes
 * no particular effort to keep them zero.  It ensures that
 * their value will not affect the results of any operation.
 * The bitmap operations that return Boolean (bitmap_empty,
 * for example) or scalar (bitmap_weight, for example) results
 * carefully filter out these unused bits from impacting their
 * results.
 *
 * These operations actually hold to a slightly stronger rule:
 * if you don't input any bitmaps to these ops that have some
 * unused bits set, then they won't output any set unused bits
 * in output bitmaps.
 *
 * The byte ordering of bitmaps is more natural on little
 * endian architectures.  See the big-endian headers
 * include/asm-ppc64/bitops.h and include/asm-s390/bitops.h
 * for the best explanations of this ordering.
 */

static int64_t bitmap_loop_count = 1;
static int64_t bitmap_loop_calls = 1;

int64_t get_bitmap_loop_count()
{
	return bitmap_loop_count;
}

int64_t get_bitmap_loop_calls()
{
	return bitmap_loop_calls;
}

void inc_bitmap_loop_count()
{
	++bitmap_loop_count;
}

void inc_bitmap_loop_calls()
{
	++bitmap_loop_calls;
}

int __bitmap_empty(const unsigned long *bitmap, int bits)
{
#if BITMAP_OVERHEAD == 0
	int k, lim = bits/BITS_PER_LONG + BITMAP_OVERHEAD;
	inc_bitmap_loop_calls();
	for (k = 0; k < lim; ++k) {
		inc_bitmap_loop_count();
		if (bitmap[k])
			return 0;
	}
	if (bits % BITS_PER_LONG)
		if (bitmap[k] & BITMAP_LAST_WORD_MASK(bits))
			return 0;

	return 1;
#else
	return !(bitmap + BITS_TO_LONGS(bits) + 1)[0];
#endif
}

int __bitmap_full(const unsigned long *bitmap, int bits)
{
	int k, lim = bits/BITS_PER_LONG;
	inc_bitmap_loop_calls();
	for (k = 0; k < lim; ++k) {
		inc_bitmap_loop_count();
		if (~bitmap[k])
			return 0;
	}
	if (bits % BITS_PER_LONG)
		if (~bitmap[k] & BITMAP_LAST_WORD_MASK(bits))
			return 0;

	return 1;
}

int __bitmap_equal(const unsigned long *bitmap1,
		const unsigned long *bitmap2, int bits)
{
	int k, lim = bits/BITS_PER_LONG;
	for (k = 0; k < lim; ++k) {
		if (bitmap1[k] != bitmap2[k])
			return 0;
	}

	if (bits % BITS_PER_LONG)
		if ((bitmap1[k] ^ bitmap2[k]) & BITMAP_LAST_WORD_MASK(bits))
			return 0;

	return 1;
}

void __bitmap_complement(unsigned long *dst, const unsigned long *src, int bits)
{
	int k, lim = bits/BITS_PER_LONG;
	for (k = 0; k < lim; ++k) {
		dst[k] = ~src[k];
	}

	if (bits % BITS_PER_LONG)
		dst[k] = ~src[k] & BITMAP_LAST_WORD_MASK(bits);
}

/**
 * __bitmap_shift_right - logical right shift of the bits in a bitmap
 *   @dst : destination bitmap
 *   @src : source bitmap
 *   @shift : shift by this many bits
 *   @bits : bitmap size, in bits
 *
 * Shifting right (dividing) means moving bits in the MS -> LS bit
 * direction.  Zeros are fed into the vacated MS positions and the
 * LS bits shifted off the bottom are lost.
 */
void __bitmap_shift_right(unsigned long *dst,
			const unsigned long *src, int shift, int bits)
{
	int k, lim = BITS_TO_LONGS(bits), left = bits % BITS_PER_LONG;
	int off = shift/BITS_PER_LONG, rem = shift % BITS_PER_LONG;
	unsigned long mask = (1UL << left) - 1;
	for (k = 0; off + k < lim; ++k) {
		unsigned long upper, lower;

		/*
		 * If shift is not word aligned, take lower rem bits of
		 * word above and make them the top rem bits of result.
		 */
		if (!rem || off + k + 1 >= lim)
			upper = 0;
		else {
			upper = src[off + k + 1];
			if (off + k + 1 == lim - 1 && left)
				upper &= mask;
		}
		lower = src[off + k];
		if (left && off + k == lim - 1)
			lower &= mask;
		dst[k] = upper << (BITS_PER_LONG - rem) | lower >> rem;
		if (left && k == lim - 1)
			dst[k] &= mask;
	}
	if (off)
		memset(&dst[lim - off], 0, off*sizeof(unsigned long));
}


/**
 * __bitmap_shift_left - logical left shift of the bits in a bitmap
 *   @dst : destination bitmap
 *   @src : source bitmap
 *   @shift : shift by this many bits
 *   @bits : bitmap size, in bits
 *
 * Shifting left (multiplying) means moving bits in the LS -> MS
 * direction.  Zeros are fed into the vacated LS bit positions
 * and those MS bits shifted off the top are lost.
 */

void __bitmap_shift_left(unsigned long *dst,
			const unsigned long *src, int shift, int bits)
{
	int k, lim = BITS_TO_LONGS(bits), left = bits % BITS_PER_LONG;
	int off = shift/BITS_PER_LONG, rem = shift % BITS_PER_LONG;
	for (k = lim - off - 1; k >= 0; --k) {
		unsigned long upper, lower;

		/*
		 * If shift is not word aligned, take upper rem bits of
		 * word below and make them the bottom rem bits of result.
		 */
		if (rem && k > 0)
			lower = src[k - 1];
		else
			lower = 0;
		upper = src[k];
		if (left && k == lim - 1)
			upper &= (1UL << left) - 1;
		dst[k + off] = lower  >> (BITS_PER_LONG - rem) | upper << rem;
		if (left && k + off == lim - 1)
			dst[k + off] &= (1UL << left) - 1;
	}
	if (off)
		memset(dst, 0, off*sizeof(unsigned long));
}

void __bitmap_and(unsigned long *dst, const unsigned long *bitmap1,
				const unsigned long *bitmap2, int bits)
{
	int k;
	int nr = BITS_TO_LONGS(bits);

	for (k = 0; k < nr; k++)
		dst[k] = bitmap1[k] & bitmap2[k];
}

void __bitmap_or(unsigned long *dst, const unsigned long *bitmap1,
				const unsigned long *bitmap2, int bits)
{
	int k;
	int nr = BITS_TO_LONGS(bits) + BITMAP_OVERHEAD;

	for (k = 0; k < nr; k++)
		dst[k] = bitmap1[k] | bitmap2[k];
}

void __bitmap_xor(unsigned long *dst, const unsigned long *bitmap1,
				const unsigned long *bitmap2, int bits)
{
	int k;
	int nr = BITS_TO_LONGS(bits);

	for (k = 0; k < nr; k++)
		dst[k] = bitmap1[k] ^ bitmap2[k];
}

void __bitmap_andnot(unsigned long *dst, const unsigned long *bitmap1,
				const unsigned long *bitmap2, int bits)
{
	int k;
	int nr = BITS_TO_LONGS(bits);

	for (k = 0; k < nr; k++)
		dst[k] = bitmap1[k] & ~bitmap2[k];
}

int __bitmap_intersects(const unsigned long *bitmap1,
				const unsigned long *bitmap2, int bits)
{
	int k, lim = bits/BITS_PER_LONG;
	for (k = 0; k < lim; ++k)
		if (bitmap1[k] & bitmap2[k])
			return 1;

	if (bits % BITS_PER_LONG)
		if ((bitmap1[k] & bitmap2[k]) & BITMAP_LAST_WORD_MASK(bits))
			return 1;
	return 0;
}

int __bitmap_subset(const unsigned long *bitmap1,
				const unsigned long *bitmap2, int bits)
{
	int k, lim = bits/BITS_PER_LONG;
	for (k = 0; k < lim; ++k)
		if (bitmap1[k] & ~bitmap2[k])
			return 0;

	if (bits % BITS_PER_LONG)
		if ((bitmap1[k] & ~bitmap2[k]) & BITMAP_LAST_WORD_MASK(bits))
			return 0;
	return 1;
}

/**
 * find_next_bit - find the first set bit in a memory region
 * @addr: The address to base the search on
 * @offset: The bitnumber to start searching at
 * @size: The maximum size to search
 */
long __find_next_bit(const unsigned long *addr, long size, long offset)
{
	const unsigned long *maps[MAX_BITMAP_LEVELS]; 
	const unsigned long *p = addr + (offset >> BITS_PER_LEVEL);
	long set = 0, bit = offset & (BITS_PER_LONG - 1);
	long levels = *(addr + BITS_TO_LONGS(size));

	long retval;
	long i;

	if (offset >= size) {
		return -1;
	}

	/*
	 * Look for nonzero in the first 32 bits:
	 */
	set = next_bit(*p, bit);
	if (set < (BITS_PER_LONG - bit)) {
		return set + offset;
	}
	set = set + bit;

	if (levels > MAX_BITMAP_LEVELS) {
		return -1;
	}
	maps[0] = addr + BITS_TO_LONGS(size) + 1;
	maps[1] = maps[0] + 1;
	maps[2] = maps[1] + BITS_PER_LONG;

	for (i = 0; i < levels; ++i) {
		inc_bitmap_loop_count();
		p = maps[levels - 1 - i] + (offset >> (BITS_PER_LEVEL*(i+2)));
		bit = (offset >> (BITS_PER_LEVEL*(i+1)))&(BITS_PER_LONG - 1);
		++bit;
		set = next_bit(*p, bit);
		if (set < (BITS_PER_LONG - bit)) {
			set = set + bit;
			break;
		}
	}

	if (set >= BITS_PER_LONG) {
		/* no next bit */ 
		return size;
	}

	retval = (offset >> (BITS_PER_LEVEL*(i+2))) * (BITS_PER_LONG << (BITS_PER_LEVEL*(i+1)));
	--i;
	for (; i >= 0; --i) {
		inc_bitmap_loop_count();
		retval += set * (BITS_PER_LONG<<(BITS_PER_LEVEL*(i + 1)));
		p = maps[levels - 1 - i] + set;
		set = __ffs(*p);
	}
	retval += set * BITS_PER_LONG;

	p = addr + (retval >> BITS_PER_LEVEL);
	set = __ffs(*p);
	retval += set;
	return retval;
}

long find_next_bit(const unsigned long *addr, long size, long offset)
{
	const unsigned long *p = addr + (offset >> BITS_PER_LEVEL);
	long set = 0, bit = offset & (BITS_PER_LONG - 1), res;

	if (bit) {
		inc_bitmap_loop_count();
		/*
		 * Look for nonzero in the first 32 bits:
		 */
		set = next_bit(*p, bit);
		if (set < (BITS_PER_LONG - bit)) {
			++bitmap_loop_calls;
			return set + offset;
		}
		set = BITS_PER_LONG - bit;
		p++;
	}

	/*
	 * No set bit yet, search remaining full words for a bit
	 */
	res = find_first_bit (p, size - BITS_PER_LONG * (p - addr));
	return (offset + set + res);
}

long __find_first_bit(const unsigned long *addr, long size)
{
	const unsigned long *map = addr + BITS_TO_LONGS(size);
	long pos, res = 0;
	int i;
	unsigned long shift;
	long levels = map[0];
	++map;

	if(!map[0]) 
		return size;

	pos = 0;
	shift = 1 << (BITS_PER_LEVEL * levels );
	for (i = 0; i < levels; ++i) {
		inc_bitmap_loop_count();
		pos = __ffs(map[i+pos]);
		res += pos * shift; 
		addr += pos*(levels-1-i)<<BITS_PER_LEVEL;
		shift >>= BITS_PER_LEVEL;
	}

	res += __ffs(addr[pos]);
	return res;
}

#ifdef TEST_BITMAP  /* unit tests */
#include <unistd.h>
#include <stdio.h>
void print_bitmap(unsigned long *map, int size)
{
	int i;
	int mod = 0;
	for(i=0; i<size; ++i) {
		fprintf(stdout, "%c", test_bit(i, map)?'.':'_');
		if(++mod == 32) {
			fprintf(stdout, "|");
			mod = 0;
		}
	}
	fprintf(stdout, "\n");
}
static void print_map(unsigned char *map, int size)
{
	int i;
	for(i=0; i<size; ++i) {
		fprintf(stderr, "%02x", (unsigned int)map[i]);
	}
	fprintf(stderr, "\n");
}

static void test_matrix_map()
{
	int i, j;
	DECLARE_BITMAP(master, 180);
	unsigned long m[80][BITS_TO_LONGS(80)];
	unsigned long *matrix[80];

	for (i=0; i<80; i++) {
		matrix[i] = &m[i][0];
	}

	bitmap_zero(master, 180);
	for (i=0; i< 80; i++)
		bitmap_zero(matrix[i], 80);


	set_bit(5, master);
	set_bit(9, master);
	set_bit(10, matrix[5]);

	i = find_first_bit(master, 80);
	printf("first bit in master map: %d\n", i);
	i = find_first_bit(matrix[i], 80);
	printf("first bit in matrix map: %d\n", i);

	clear_bit(10, matrix[5]);
	set_bit(3, m[5]);
	set_bit(5, m[9]);
	set_bit(0, m[10]);
	set_bit(9, m[9]);
	set_bit(76, m[9]);

	i = find_first_bit(master, 80);
	printf("first bit in master map: %d\n", i);

	j = find_next_bit(master, 80, i+1);
	printf("next bit in master map: %d\n", j);

	j = find_first_bit(m[i], 80);
	printf("first bit in m map %d: %d\n", i, j);

	j = find_next_bit(master, 80, i+1);
	i = find_first_bit(m[j], 80);
	printf("first bit in m map %d: %d\n", j, i);
	i = find_next_bit(m[j], 80, i+1);
	printf("next bit in m map %d: %d\n", j, i);
	i = find_next_bit(m[j], 80, i+1);
	printf("next bit in m map %d: %d\n", j, i);
	i = find_next_bit_circular(m[j], 80, i+1);
	printf("next bit in m map %d: %d\n", j, i);

}
#define BSIZE (1024*16)
#undef printf
int main(int argc, char **argv)
{
	int n, k;
	int res = 0;
	DECLARE_BITMAP(map, BSIZE);

	bitmap_zero(map, BSIZE);
	print_bitmap(map, BSIZE);

	n = find_next_bit_circular(map, BSIZE, 35);
	printf("next bit is %d\n", n);

	bitmap_set(map, BSIZE, 23);
	bitmap_set(map, BSIZE, 57);
	bitmap_set(map, BSIZE, 64);
	bitmap_set(map, BSIZE, 130);
	bitmap_set(map, BSIZE, 131);
	bitmap_set(map, BSIZE, BSIZE/2 - 5);
	bitmap_set(map, BSIZE, BSIZE/2 - 15);
	bitmap_set(map, BSIZE, BSIZE/2 - 45);
	bitmap_set(map, BSIZE, BSIZE - 5);
	
	print_bitmap(map, BSIZE);
	printf("======== map ========\n");
	print_bitmap(map + BITS_TO_LONGS(BSIZE) + 1, BITMAP_OVERHEAD*BITS_PER_LONG);

	n = find_first_bit(map, BSIZE);
	printf("first bit is %d\n", n);
	n = __find_first_bit(map, BSIZE);
	printf("__first bit is %d\n", n);
	bitmap_clear(map, BSIZE, 5);
//	bitmap_clear(map, BSIZE, 57);
//	bitmap_clear(map, BSIZE, 64);
	bitmap_clear(map, BSIZE, BSIZE/2 - 5);
	if (test_bit(130, map))
		fprintf(stdout, "bit at 130\n");
	bitmap_clear(map, BSIZE, 130);
	if (test_bit(130, map))
		fprintf(stdout, "bit at 130\n");
	if (test_bit(131, map))
		fprintf(stdout, "bit at 131\n");
	print_bitmap(map, BSIZE);
	printf("======== map ========\n");
	print_bitmap(map + BITS_TO_LONGS(BSIZE) + 1, BITMAP_OVERHEAD*BITS_PER_LONG);
	n = __find_first_bit(map, BSIZE);
	printf("__first bit is %d\n", n);
	n = find_first_bit(map, BSIZE);
	printf("first bit is %d\n", n);
//	n = find_next_bit(map, BSIZE, n+ 1);
//	printf("next bit is %d\n", n);
	n = __find_next_bit(map, BSIZE, 0);
	printf("__next bit 0 is %d\n", n);
	k = find_next_bit(map, BSIZE, 0);
	printf("next bit 0 is %d\n", k);
	res += (n != k);
	n = __find_next_bit(map, BSIZE, 58);
	printf("__next bit 58 is %d\n", n);
	k = find_next_bit(map, BSIZE, 58);
	printf("next bit 58 is %d\n", k);
	res += (n != k);
	n = __find_next_bit(map, BSIZE, 68);
	printf("__next bit 68 is %d\n", n);
	k = find_next_bit(map, BSIZE, 68);
	printf("next bit 68 is %d\n", k);
	res += (n != k);
	n = __find_next_bit(map, BSIZE, n);
	printf("__next bit is %d\n", n);
	k = find_next_bit(map, BSIZE, k);
	printf("next bit is %d\n", k);
	res += (n != k);
	n = __find_next_bit(map, BSIZE, n+ 1);
	printf("__next bit is %d\n", n);
	k = find_next_bit(map, BSIZE, k+ 1);
	printf("next bit is %d\n", k);
	res += (n != k);
	n = __find_next_bit(map, BSIZE, n+ 1);
	printf("__next bit is %d\n", n);
	k = find_next_bit(map, BSIZE, k+ 1);
	printf("next bit is %d\n", k);
	res += (n != k);
	n = __find_next_bit(map, BSIZE, n+ 1);
	printf("__next bit is %d\n", n);
	k = find_next_bit(map, BSIZE, k+ 1);
	printf("next bit is %d\n", k);
	
	res += (n != k);
	n = __find_next_bit(map, BSIZE, 8000);
	printf("__next bit 8000 is %d\n", n);
	k = find_next_bit(map, BSIZE, 8000);
	printf("next bit 8000 is %d\n", k);
	
	printf("======= result %d ===========\n", res);
	return 0;

	n = find_next_bit(map, BSIZE, n+ 1);
	printf("next bit is %d\n", n);
	n = find_next_bit(map, BSIZE, n +1);
	printf("next bit is %d\n", n);

	printf("****************************\n");
	n = find_first_bit(map, BSIZE);
	printf("first bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n+ 1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n+ 1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n +1);
	printf("next bit is %d\n", n);

	bitmap_shift_left(map, map, 42, BSIZE);
	printf("************* shift left for 32 ***************\n");
	n = find_first_bit(map, BSIZE);
	printf("first bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n+ 1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n+ 1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n +1);
	printf("next bit is %d\n", n);

	bitmap_shift_right(map, map, 32, BSIZE);
	printf("************* shift right for 32 ***************\n");
	n = find_first_bit(map, BSIZE);
	printf("first bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n+ 1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n+ 1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n +1);
	printf("next bit is %d\n", n);

	clear_bit(5, map);
	clear_bit(57, map);
	set_bit(2, map);
	set_bit(10, map);
	printf("********* clear 5 57 /set bits 2 10 *******************\n");
	n = find_first_bit(map, BSIZE);
	printf("first bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n+ 1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n+ 1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n +1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n +1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n +1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n +1);
	printf("next bit is %d\n", n);
	n = find_next_bit_circular(map, BSIZE, n +1);
	printf("next bit is %d\n", n);

	test_matrix_map();
	return 0;
}
#endif /* TEST_BITMAP */
