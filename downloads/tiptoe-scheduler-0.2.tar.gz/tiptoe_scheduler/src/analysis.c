/*
 *  The Tiptoe Project
 *  Copyright (c) Silviu Craciunas (scraciunas@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "process.h"

#define MAX_LOG_PROC 10000

static FILE *file;
static FILE *file2;
static int load_cpu[MAX_LOG_PROC], load_mem[MAX_LOG_PROC], load_io[MAX_LOG_PROC], 
	limit_cpu[MAX_LOG_PROC], limit_io[MAX_LOG_PROC], limit_mem[MAX_LOG_PROC], 
	load_total[MAX_LOG_PROC], limit_total[MAX_LOG_PROC];

void analysis_run(struct Process *p, int time){

	struct stat buf;
	char filename[25];
	char filename2[25];
	sprintf(filename,"analysis/log%d",get_pid(p));
	sprintf(filename2,"analysis/log_total");

	if (stat(filename2, &buf) == 0) 
		file = fopen(filename2, "a");
	else
		file = fopen(filename2, "w");

	if (stat(filename, &buf) == 0) 
		file2 = fopen(filename, "a");
	else {
		file2 = fopen(filename, "w");
		fprintf(file2,"# Analysis file for process %d\n", get_pid(p));
		load_cpu[get_pid(p)] = 0;
		load_mem[get_pid(p)] = 0;
		load_io[get_pid(p)] = 0;
		limit_cpu[get_pid(p)] = 0;
		limit_mem[get_pid(p)] = 0;
		limit_io[get_pid(p)] = 0;
		load_total[get_pid(p)] = 0;
		limit_total[get_pid(p)] = 0;
	}


	if(!file2) {
		perror("open");
		exit(1);
	}

	if(!file) {
		perror("open");
		exit(1);
	}

	switch(get_process_resource(p)) {
		case RESOURCE_CPU :
			load_cpu[0] += get_process_run_time(p); 
			limit_cpu[0] += get_process_limit(p); 
			load_cpu[get_pid(p)] += get_process_run_time(p); 
			limit_cpu[get_pid(p)] += get_process_limit(p);
			break;
		case RESOURCE_MEM : 
			load_mem[0] += get_process_run_time(p); 
			limit_mem[0] += get_process_limit(p); 
			load_mem[get_pid(p)] += get_process_run_time(p); 
			limit_mem[get_pid(p)] += get_process_limit(p); 
			break;
		case RESOURCE_IO  : 
			load_io[0]  += get_process_run_time(p); 
			limit_io[0] += get_process_limit(p); 
			load_io[get_pid(p)]  += get_process_run_time(p); 
			limit_io[get_pid(p)] += get_process_limit(p); 
			break;
	}
	load_total[0] += get_process_run_time(p);
	limit_total[0] += get_process_limit(p);
	load_total[get_pid(p)] += get_process_run_time(p);
	limit_total[get_pid(p)] += get_process_limit(p);
	
	fprintf(file,"%d %d %d %d %d %d %d %d %d \n", time, load_cpu[0], limit_cpu[0], load_mem[0], limit_mem[0], load_io[0], limit_io[0], load_total[0], limit_total[0]);

	fprintf(file2,"%d %d %d %d %d %d %d %d %d %d\n", time, load_cpu[get_pid(p)], limit_cpu[get_pid(p)], load_mem[get_pid(p)], 
							limit_mem[get_pid(p)], load_io[get_pid(p)], limit_io[get_pid(p)], load_total[get_pid(p)], limit_total[get_pid(p)],
							get_process_deadline(p)-time-get_process_run_time(p));

	fclose(file2);
	fclose(file);

}

void analysis_init_file() {
	char filename[25];
	sprintf(filename,"log");
	file = fopen(filename, "w");

	if(!file) {
		perror("open");
		exit(1);
	}

	fprintf(file,"# Analysis file\n");
	load_cpu[0] = 0;
	load_mem[0] = 0;
	load_io[0] = 0;
	limit_cpu[0] = 0;
	limit_mem[0] = 0;
	limit_io[0] = 0;
	load_total[0] = 0;
	limit_total[0] = 0;

}

void analysis_close_file(){
	 fclose(file);
}

