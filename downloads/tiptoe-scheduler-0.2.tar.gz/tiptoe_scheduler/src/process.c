/*
 *  The Tiptoe Project
 *  Copyright (c) Silviu Craciunas (scraciunas@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include "process.h"
#include "scheduler.h"
#include "generic.h"

static int pid = 1;
static long average_response_time = 1;
static int average_response_samples = 1;
//-------------------------------------------------------------------------

/**
 * get_next_pid
 * @policy: process class.
 *
 * gets the next unique pid
 */
static int get_next_pid()
{
	return (pid++);
}

//--------------------------------------------------------------------------

int get_pid(struct Process *p)
{
	if (p != NULL)
		return p->pid;
	else
		return -1;
}

int set_pid(struct Process *p, int pid)
{
	int retval;
	if (p != NULL) {
		p->pid = pid;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

static int get_process_type(struct Process *p)
{
	if (p != NULL)
		return p->type;
	else
		return -1;
}

static int set_process_type(struct Process *p, int type)
{
	int retval;
	if (p != NULL) {
		p->type = type;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

static int get_process_counter(struct Process *p)
{
	if (p != NULL)
		return p->index;
	else
		return -1;
}

static int inc_process_counter(struct Process *p)
{
	if (p != NULL) {
		p->index++;
		return p->index;
	} else
		return -1;
}

static int set_process_counter(struct Process *p, int index)
{
	int retval;
	if (p != NULL) {
		p->index = index;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int get_process_resource_limit(struct Process *p, int resource)
{
	if (p != NULL && resource < NUM_RESOURCES && resource >= 0)
		return p->descriptor[resource].limit;
	else
		return -1;
}

int set_process_resource_limit(struct Process *p, int resource, int limit)
{
	int retval;
	if (p != NULL && resource < NUM_RESOURCES && resource >= 0) {
		p->descriptor[resource].limit = limit;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int get_process_resource_period(struct Process *p, int resource)
{
	if (p != NULL && resource < NUM_RESOURCES && resource >= 0)
		return p->descriptor[resource].period;
	else
		return -1;
}

int set_process_resource_period(struct Process *p, int resource, int period)
{
	int retval;
	if (p != NULL 
			&& resource < NUM_RESOURCES && resource >= 0
			&& period > 0) {
		p->descriptor[resource].period = period;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

static int get_process_code_load(struct Process *p, int pc)
{
	if (p != NULL && pc < MAX_CODE && pc >= 0)
		return p->code.pstate[pc].load;
	else
		return -1;
}

static int set_process_code_load(struct Process *p, int pc, int load)
{
	int retval;
	if (p != NULL && pc < MAX_CODE && pc >= 0) {
		p->code.pstate[pc].load = load;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

static int get_process_code_resource(struct Process *p, int pc)
{
	if (p != NULL && pc < MAX_CODE && pc >= 0)
		return p->code.pstate[pc].resource;
	else
		return -1;
}

static int set_process_code_resource(struct Process *p, int pc, int resource)
{
	int retval;
	if (p != NULL && pc < MAX_CODE && pc >= 0 && resource < NUM_RESOURCES) {
		p->code.pstate[pc].resource = resource;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

static int get_process_code_period(struct Process *p)
{
	if (p != NULL)
		return p->code.period;
	else
		return -1;
}

static int set_process_code_period(struct Process *p, int period)
{
	int retval;
	if (p != NULL) {
		p->code.period = period;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

static int get_process_context_supply(struct Process *p, int resource)
{
	if (p != NULL && resource < NUM_RESOURCES)
		return p->pc.ps[resource].supply;
	else
		return -1;
}

int set_process_context_supply(struct Process *p, int resource, int supply)
{
	int retval;
	if (p != NULL && resource < NUM_RESOURCES) {
		p->pc.ps[resource].supply = supply;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

static int get_process_context_instant(struct Process *p, int resource)
{
	if (p != NULL && resource < NUM_RESOURCES)
		return p->pc.ps[resource].instant;
	else
		return -1;
}

int set_process_context_instant(struct Process *p, int resource, int instant)
{
	int retval;
	if (p != NULL && resource < NUM_RESOURCES) {
		p->pc.ps[resource].instant = instant;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int get_process_deadline(struct Process *p)
{
	if (p != NULL)
		return p->task.deadline;
	else
		return -1;
}

int set_process_deadline(struct Process *p, int deadline)
{
	int retval;
	if (p != NULL) {
		p->task.deadline = deadline;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int get_process_release(struct Process *p)
{
	if (p != NULL)
		return p->task.release;
	else
		return -1;
}

int set_process_release(struct Process *p, int release)
{
	int retval;
	if (p != NULL) {
		p->task.release = release;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int get_process_load(struct Process *p)
{
	if (p != NULL)
		return p->task.p.load;
	else
		return -1;
}

int set_process_load(struct Process *p, int load)
{
	int retval;
	if (p != NULL) {
		p->task.p.load = load;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int sub_process_load(struct Process *p, int load)
{
	int retval;
	if (p != NULL) {
		p->task.p.load -= load;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int get_process_resource(struct Process *p)
{
	if (p != NULL)
		return p->task.p.resource;
	else
		return -1;
}

int set_process_resource(struct Process *p, int resource)
{
	int retval;
	if (p != NULL) {
		p->task.p.resource = resource;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int get_process_limit(struct Process *p)
{
	return get_process_resource_limit(p, get_process_resource(p));
}

int set_process_limit(struct Process *p, int limit)
{
	return set_process_resource_limit(p, get_process_resource(p), limit);
}

int get_process_period(struct Process *p)
{
	return get_process_resource_period(p, get_process_resource(p));
}

int set_process_period(struct Process *p, int period)
{
	return set_process_resource_period(p, get_process_resource(p), period);
}

int get_process_supply(struct Process *p)
{
	return get_process_context_supply(p, get_process_resource(p));
}

int set_process_supply(struct Process *p, int supply)
{
	return set_process_context_supply(p, get_process_resource(p), supply);
}

int get_process_instant(struct Process *p)
{
	return get_process_context_instant(p, get_process_resource(p));
}

int set_process_instant(struct Process *p, int instant)
{
	return set_process_context_instant(p, get_process_resource(p), instant);
}

int get_process_state(struct Process *p)
{
	if (p != NULL)
		return p->state;
	else
		return -1;
}

int set_process_state(struct Process *p, int state)
{
	int retval;
	if (p != NULL) {
		p->state = state;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int get_process_run_type(struct Process *p)
{
	if (p != NULL)
		return p->run_type;
	else
		return -1;
}

int set_process_run_type(struct Process *p, int run_type)
{
	int retval;
	if (p != NULL) {
		p->run_type = run_type;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int get_process_run_time(struct Process *p)
{
	if (p != NULL)
		return p->run_time;
	else
		return -1;
}

int set_process_run_time(struct Process *p, int run_time)
{
	int retval;
	if (p != NULL) {
		p->run_time = run_time;
		p->sum_run_time += run_time;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int get_process_accounting_work(struct Process *p, int resource) 
{
	if (p != NULL)
		return p->accounting[resource].work;
	else
		return -1;
}

int set_process_accounting_work(struct Process *p, int resource, int work)
{
	int retval;
	if (p != NULL) {
		retval = 0;
		p->accounting[resource].work = work;
	} else
		retval = -1;

	return retval;
}

int get_process_accounting_instant(struct Process *p, int resource)
{
	if (p != NULL)
		return p->accounting[resource].instant;
	else
		return -1;
}

int set_process_accounting_instant(struct Process *p, int resource, int instant)
{
	int retval;
	if (p != NULL) {
		retval = 0;
		p->accounting[resource].instant = instant;
	} else
		retval = -1;

	return retval;
}

//--------------------------------------------------------------------------
/**
 * load_to_time
 * @policy: scheduling class.
 *
 * converts a load of a resource into time
 */
static int load_to_time(int load, int resource)
{
	int ret = -1;
	switch (resource) {
	case RESOURCE_CPU:
		ret = load / SYSTEM_CONVERSION_CPU;
		break;
	case RESOURCE_MEM:
		ret = load / SYSTEM_CONVERSION_MEM;
		break;
	case RESOURCE_IO:
		ret = load / SYSTEM_CONVERSION_IO;
		break;
	default:
		/*
		 * FIXME: ERROR 
		 */
		fprintf(stderr, "ERROR %s %d: unkown resource\n", __FILE__, __LINE__);
		break;
	}
	if(ret == 0)
		return 1;

	return ret;
}

/**
 * time_to_load
 * @policy: scheduling class.
 *
 * converts time of a resource into load
 */
int time_to_load(int time, int resource)
{
	switch (resource) {
	case RESOURCE_CPU:
		return time * SYSTEM_CONVERSION_CPU;
		break;
	case RESOURCE_MEM:
		return time * SYSTEM_CONVERSION_MEM;
		break;
	case RESOURCE_IO:
		return time * SYSTEM_CONVERSION_IO;
		break;
	default:
		/*
		 * FIXME: ERROR 
		 */
		fprintf(stderr, "ERROR %s %d: unkown resource\n", __FILE__, __LINE__);
		break;
	}
	return 0;
}

static struct Process *alloc_process()
{
	return (struct Process *)malloc(sizeof(struct Process));
}

void process_init(struct Process *p, int time, int type, int period)
{
	memset(p, 0, sizeof(struct Process));
	set_pid(p, get_next_pid());
	set_process_type(p, type);
	set_process_counter(p, 0);
	if (type == PROCESS_TYPE_PERIODIC)
		set_process_code_period(p, period);

	set_process_release(p, time);
	set_process_deadline(p, 0);

	queue_entry_init(&p->queue);
}

/**
 * new_process
 * @policy: process class.
 *
 * creates a new process and allocates memory for it
 */
struct Process *new_process(int time, int type, int period)
{
	struct Process *p;

	p = alloc_process();	
	if (p == NULL) {
		printf("unable to allocate memory\n");
		perror("malloc");
		exit(EXIT_FAILURE);		/* out of memory */
	}

	process_init(p, time, type, period);
	log("process [%d] | created\n", get_pid(p));

	return p;
}

/**
 * add_process_code
 * @policy: process class.
 *
 * adds process code to the process
 */
int add_process_code(struct Process *p, int load, int resource, int state_id)
{
	int retval = 0;
	int load_in_time;
	
	load_in_time = load_to_time(load, resource);
	retval = set_process_code_load(p, state_id, load_in_time);
	if (!retval) {
		retval = set_process_code_resource(p, state_id, resource);

		log("process [%d] | process code %d : %d -> %d \n", get_pid(p),
				state_id, load_in_time, resource);
		log("process [%d] | process code added\n", get_pid(p));
	}
	return retval;
}

int add_process_task(struct Process *p, int time)
{
	int deadline = (time / get_process_period(p) + 1) * get_process_period(p);
	set_process_deadline(p, deadline);
	set_process_load(p, get_process_code_load(p, get_process_counter(p)));
	set_process_resource(p,
						 get_process_code_resource(p, get_process_counter(p)));
	return 0;
}

int add_process_descriptor(struct Process *p, int resource, int limit, int period)
{
	int res = 0;
	int limit_to_time;

	limit_to_time = load_to_time(limit, resource);

	set_process_resource_limit(p, resource, limit_to_time);
	set_process_resource_period(p, resource, period);

	set_process_context_supply(p, resource, get_process_resource_limit(p, resource));
	set_process_context_instant(p, resource, 0);

	return res;
}

/**
 * set_next_process_state
 * @policy: process class.
 *
 * set the new process state
 */
int set_next_process_state(struct Process *p)
{
	int ret = 0;
	int used_resource;
	
	/*
	 * if periodic then restart 
	 */
	used_resource = get_process_resource(p);
	inc_process_counter(p);

	if (get_process_type(p) == PROCESS_TYPE_PERIODIC) {
		if (get_process_counter(p) == get_process_code_period(p))
			set_process_counter(p, 0);
	}

	set_process_load(p, get_process_code_load(p, get_process_counter(p)));
	set_process_resource(p,
						 get_process_code_resource(p, get_process_counter(p)));

	if (get_process_load(p) == 0) {
		return PROCESS_STATE_FINISHED;
	}

	if (used_resource == get_process_resource(p))
		ret = PROCESS_STATE_SAME;
	else
		ret = PROCESS_STATE_DIFFERENT;

	return ret;
}

int calculate_average_response_time(struct Process *p, int time)
{
	int response_time;
	response_time = time - p->last_state_change;
	p->last_state_change = time;
	average_response_time += response_time;
	average_response_samples++;
	return response_time;
}

int get_average_response_time() {
	return average_response_time / average_response_samples;
}
