/*
 *  The Tiptoe Project
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include "queue.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdint.h>


/* 
 * Instrumentation 
 */
static long mem_usage;
static long add_calls, remove_calls;
static uint64_t get_duration = 0, get_calls, sched_calls;
static uint64_t find_duration = 0;
static uint64_t find_calls = 0;

#ifdef BITMAP_INSTRUMENT
static uint64_t bitmap_clear_duration = 0, bitmap_clear_calls = 0;
static uint64_t bitmap_set_duration = 0, bitmap_set_calls = 0;
static uint64_t bitmap_or_duration = 0, bitmap_or_calls = 0;
static uint64_t bitmap_zero_duration = 0, bitmap_zero_calls = 0;

#define bitmap_clear(a,b,c) do { \
	uint64_t start = rdtsc(); \
	bitmap_clear(a,b,c); \
	bitmap_clear_duration += rdtsc() - start; \
	++bitmap_clear_calls; \
} while (0)

#define bitmap_set(a,b,c) do { \
	uint64_t start = rdtsc(); \
	bitmap_set(a,b,c); \
	bitmap_set_duration += rdtsc() - start; \
	++bitmap_set_calls; \
} while (0)

#define bitmap_or(a,b,c,d) do { \
	uint64_t start = rdtsc(); \
	bitmap_or(a,b,c,d); \
	bitmap_or_duration += rdtsc() - start; \
	++bitmap_or_calls; \
} while (0)

#define bitmap_zero(a,b) do { \
	uint64_t start = rdtsc(); \
	bitmap_zero(a,b); \
	bitmap_zero_duration += rdtsc() - start; \
	++bitmap_zero_calls; \
} while (0)

static inline void print_bitmap_stats() 
{
	printf
		("bitmap_clear_calls: %lld bitmap_clear_duration: %lld avg: %lld call_avg: %lld\n",
		 bitmap_clear_calls, bitmap_clear_duration,
		 bitmap_clear_duration / bitmap_clear_calls,
		 bitmap_clear_duration / sched_calls);
	printf
		("bitmap_set_calls: %lld bitmap_set_duration: %lld avg: %lld call_avg: %lld\n",
		 bitmap_set_calls, bitmap_set_duration,
		 bitmap_set_duration / bitmap_set_calls,
		 bitmap_set_duration / sched_calls);

	printf
		("bitmap_or_calls: %lld bitmap_or_duration: %lld avg: %lld call_avg: %lld\n",
		 bitmap_or_calls, bitmap_or_duration,
		 bitmap_or_duration / bitmap_or_calls,
		 bitmap_or_duration / sched_calls);

	printf
		("bitmap_zero_calls: %lld bitmap_zero_duration: %lld avg: %lld call_avg: %lld\n",
		 bitmap_zero_calls, bitmap_zero_duration,
		 bitmap_zero_duration / bitmap_zero_calls,
		 bitmap_zero_duration / sched_calls);

}
#else
static inline void print_bitmap_stats()
{
}
#endif

static inline uint64_t rdtsc()
{
	uint32_t lo, hi;
	__asm__ __volatile__("rdtsc":"=a"(lo), "=d"(hi));
	return (uint64_t) hi << 32 | lo;
}

static inline void print_stats()
{
	int64_t count, calls;
	uint64_t start, duration;

	count = get_bitmap_loop_count();
	calls = get_bitmap_loop_calls();
	printf("%lld %lld %lld\n", count, calls, count / calls);
	printf("add: %ld remove: %ld\n", add_calls, remove_calls);
	printf("find_calls: %lld find_duration: %lld avg: %lld call_avg: %lld\n",
		   find_calls, find_duration, find_duration / find_calls,
		   find_duration / sched_calls);
	printf("get_calls: %lld get_duration: %lld avg: %lld call_avg: %lld\n",
		   get_calls, get_duration, get_duration / get_calls,
		   get_duration / sched_calls);

	start = rdtsc();
	duration = rdtsc() - start;
	printf("rdtsc() overhead %lld\n", duration);
	print_bitmap_stats();

}

static long get_mem_usage()
{
	return mem_usage;			/* mem_usage accounts for both queues */
}

static struct q_matrix _matrix;
static void _init()
{
	mem_usage = sizeof(_matrix);
	add_calls = remove_calls = get_calls = sched_calls = 0;
}


#ifndef USE_TREE
static struct list_head *__m[MAX_ELEMENTS][MAX_ELEMENTS];
#define PREF(a,b) &__m[a][b]
#define REF(a,b) __m[a][b]

static void init()
{
	_init();
	memset(&__m, 0, sizeof(__m));
	mem_usage += sizeof(__m);
}

static inline void free_head(struct list_head **head, int key1, int key2)
{

}

static int get_alloc_count()
{
	print_stats();
	return 0;
}

#else /* ifndef USE_TREE */

#define TREE_LEVELS 3
#define TREE_BITS   5
#define TREE_CHILDS  (1 << TREE_BITS)
#define TREE_CHILD_MASK  (TREE_CHILDS-1)

#if TREE_LEVELS * TREE_BITS < INDEX_BITS
#error tree is to small for the number of elements
#endif

struct tree_node;
struct tree_node
{
	union
	{
		struct tree_node *childs[TREE_CHILDS];
		struct list_head *leafs[TREE_CHILDS];
		struct list_head free_list;
	};
	uint32_t magic;
	struct tree_node *parent;
};

static struct tree_node tree_head;
static int nodes_in_use = 0;
static int max_nodes_in_use = 0;

static inline void inc_nodes_in_use()
{
	++nodes_in_use;
	if(nodes_in_use > max_nodes_in_use)
		max_nodes_in_use = nodes_in_use;
}

static inline int get_index(int level, int key)
{
	if (level >= TREE_LEVELS || level < 0) {
		/*
		 * BUG
		 */
	}

	return (key >> (level * TREE_BITS)) & TREE_CHILD_MASK;
}

static int alloc_count = 0;
static int free_count = 0;
static int get_alloc_count()
{
	print_stats();
	return alloc_count;
}

#ifdef TREE_POOL
#define POOL_SIZE (24*1024)

static struct list_head free_nodes;
static struct tree_node node_pool[POOL_SIZE];
static inline void init_node_pool()
{
	int i;
	INIT_LIST_HEAD(&free_nodes);
	for(i = 0; i < POOL_SIZE; ++i) {
		INIT_LIST_HEAD(&node_pool[i].free_list);
		list_add_tail(&free_nodes, &node_pool[i].free_list);
	}
}

static struct tree_node *alloc_node()
{
	struct tree_node *new;
	if (list_empty(&free_nodes)) {
		fprintf(stderr, "ERROR: out of memory, node pool empty\n");	/* BUG */
		get_alloc_count();
		exit(2);
	}
	alloc_count++;
	new = (struct tree_node *)free_nodes.next;
	list_del(free_nodes.next);
	memset(new, 0, sizeof(struct tree_node));
	return new;
}

static inline void free_node_struct(struct tree_node *node)
{
	INIT_LIST_HEAD(&node->free_list);
	list_add_tail(&free_nodes, &node->free_list);
}
#else
static struct tree_node *alloc_node()
{
	struct tree_node *new = (struct tree_node *)malloc(sizeof(struct tree_node));
	if (!new) {
		fprintf(stderr, "ERROR: out of memory\n");	/* BUG */
		get_alloc_count();
		exit(2);
	}
	memset(new, 0, sizeof(struct tree_node));
	mem_usage += sizeof(struct tree_node);
	alloc_count++;
	return new;
}

static inline void free_node_struct(struct tree_node *node)
{
	mem_usage -= sizeof(struct tree_node);
	free(node);
}
#endif /* TREE_POOL */

static void free_node(struct tree_node *node, int level, int key1, int key2)
{
	int i;
	int l;
	struct tree_node *parent;

	assert(node->magic == 0xdeadbeef);
	if (node == NULL) { /* reached head of tree */
		return;
	}

	/* TODO: this loop could be removed by using a bitmap in each node */
	for(i = 0; i < TREE_CHILDS; ++i)
		if (node->childs[i] != NULL) /* node has oder kids, leave it alone */
			return;

	parent = node->parent;
	assert(parent->magic == 0xdeadbeef);
	l = (level < TREE_LEVELS)? level:level - TREE_LEVELS;
	i =  get_index(l, (level < TREE_LEVELS)? key2: key1);

	assert( (i < TREE_CHILDS) && (i >= 0));

	parent->childs[i] = NULL;
	++free_count;
	--nodes_in_use;
	free_node_struct(node);
	free_node(parent, level + 1, key1, key2);
}

static inline void free_head(struct list_head **head, int key1, int key2)
{
	int index = get_index(0, key2);
	struct list_head **h;
	struct tree_node *node;
	int i = 0;
		
	node = (struct tree_node *)(head - index); /* HACK alert! */
	
	h = head;
	while(*h != (struct list_head*)0xdeadbeef) {
		++h;
		++i;
	}

	assert(node->magic == 0xdeadbeef);
	free_node(node, 1, key1, key2);
}

static struct tree_node *find_leave_node(struct tree_node *node, int level, int key)
{
	int i;

	if (!node) {
		/*
		 * BUG 
		 */
		fprintf(stderr, "ERROR %s %d: node is NULL\n", __FILE__, __LINE__);
	}

	i = get_index(level, key);
	if (node->childs[i] == NULL) {
		node->childs[i] = alloc_node();
		inc_nodes_in_use();
		node->childs[i]->parent = node;
		node->childs[i]->magic = 0xdeadbeef;
	}
	if (level > 1) {
		return find_leave_node(node->childs[i], level - 1, key);
	} else {
		return node->childs[i];
	}
}

static struct list_head **find_leave(int key1, int key2)
{
	struct tree_node *node;
	int i;
	node = find_leave_node(&tree_head, TREE_LEVELS - 1, key1);
	i = get_index(0, key1);
	if (node->childs[i] == NULL) {
		node->childs[i] = alloc_node();
		inc_nodes_in_use();
		node->childs[i]->parent = node;
		node->childs[i]->magic = 0xdeadbeef;
	}
	node = find_leave_node(node->childs[i], TREE_LEVELS - 1, key2);

	i = get_index(0, key2);
	return &node->leafs[i];
}

static void init()
{
	_init();
#ifdef TREE_POOL
	mem_usage += sizeof(node_pool);
	memset(&node_pool, 0, sizeof(node_pool));
	init_node_pool();
#endif
	memset(&tree_head, 0, sizeof(struct tree_node));
	tree_head.parent = NULL;
	tree_head.magic = 0xdeadbeef;
}

#define PREF(a, b) find_leave(a, b)
#define REF(a, b) (*PREF(a, b))

#endif /* USE_TREE */

static inline void delete(int key1, int key2)
{
	struct list_head **head;
	head = PREF(key1, key2);
	*head = NULL;
	free_head(head, key1, key2);
}

static inline struct list_head *get_list_head(struct matrix *m, int key1, int key2)
{
	if (m->_rel_)
		return REF(key1, key2);
	else
		return REF(key2, key1);

}

static inline int released(int curr, int release, int deadline)
{
	return (deadline > release && release <= curr && curr < deadline)
		|| (deadline < release && (curr < deadline || curr >= release));
}

#if defined DEBUG_QUEUE || defined WQUEUE_TEST
#include "process.h"
static void _print_col(struct matrix *m)
{
	struct list_head *pos, *head;
	int i, j, key1, key2, _key1, _key2;
	int prev_key;
	struct Process *p;
	unsigned long *addr;

	prev_key = 0;
	fprintf(stderr, "%d ", m->current_key);
	for (i = 0; i < MAX_ELEMENTS; ++i) {
		key1 = (m->current_key + i) & INDEX_MASK;
		addr = _matrix.col_map[key1];

		if (test_bit(key1, m->master_map)) {
			int k = find_first_bit(addr, MAX_ELEMENTS);
			fprintf(stderr, "[%d,%d]", i + m->current_key, k);
			for (j = 0; j < MAX_ELEMENTS - i; ++j) {
				key2 = (key1 + j + 1) & INDEX_MASK;
				if (test_bit(key2, addr)) {
					fprintf(stderr, "<%d,%d>", key2, j);
					/*
					 * handle first element extra
					 */
					head = get_list_head(m, key1, key2);
					if (!head) {
						fprintf(stderr, "bitmap not matching entries\n");
						break;
					}
					p = queue_to_process(head);
					_key1 = ((struct queue_entry *)head)->keys[0];
					_key2 = ((struct queue_entry *)head)->keys[1];
					fprintf(stderr, "\t*%d*(%d, (%d,%d)) ", p->pid, key1, _key1,
							_key2);
					printf("[%d]", p->pid);
					if (prev_key > _key2)
						fprintf(stderr,
								"******* ERROR: LIST NOT ASCENDING *************\r\n");
					prev_key = _key2;

					list_for_each(pos, head) {
						p = queue_to_process(pos);
						_key1 = ((struct queue_entry *)pos)->keys[0];
						_key2 = ((struct queue_entry *)pos)->keys[1];
						fprintf(stderr, "\t*%d*(%d, (%d,%d)) ", p->pid, key1,
								_key1, _key2);
						printf("[%d]", p->pid);
						if (prev_key > _key2)
							fprintf(stderr,
									"******* ERROR: LIST NOT ASCENDING *************\r\n");
						prev_key = _key2;
					}
				}
			}
		}
	}
}

static void _print_row(struct matrix *m)
{
	struct list_head *pos, *head;
	int i, j, key1, key2, _key1, _key2;
	int prev_key;
	struct Process *p;
	unsigned long *addr;

	prev_key = 0;
	fprintf(stderr, "%d ", m->current_key);
	for (i = 0; i < MAX_ELEMENTS; ++i) {
		key1 = (m->current_key + i) & INDEX_MASK;
		addr = _matrix.row_map[key1];

		if (test_bit(key1, m->master_map)) {
			fprintf(stderr, "[%d]", i + m->current_key);
			for (j = 0; j < MAX_ELEMENTS; ++j) {
				key2 = (m->current_key + j) & INDEX_MASK;
				if (test_bit(key2, addr)) {
					fprintf(stderr, "<%d,%d>", key2, j);
					head = get_list_head(m, key1, key2);
					if (!head) {
						fprintf(stderr, "bitmap not matching entries\n");
						break;
					}
					p = queue_to_process(head);
					_key1 = ((struct queue_entry *)head)->keys[0];
					_key2 = ((struct queue_entry *)head)->keys[1];
					fprintf(stderr, "\t*%d*(%d, (%d,%d)) ", p->pid, key1, _key1,
							_key2);
					printf("[%d]", p->pid);
					if (prev_key > _key1)
						fprintf(stderr,
								"******* ERROR: LIST NOT ASCENDING *************\r\n");
					prev_key = _key1;

					list_for_each(pos, head) {
						p = queue_to_process(pos);
						_key1 = ((struct queue_entry *)pos)->keys[0];
						_key2 = ((struct queue_entry *)pos)->keys[1];
						fprintf(stderr, "\t*%d*(%d, (%d,%d)) ", p->pid, key1,
								_key1, _key2);
						printf("[%d]", p->pid);
						if (prev_key > _key1)
							fprintf(stderr,
									"******* ERROR: LIST NOT ASCENDING *************\r\n");
						prev_key = _key1;
					}
				}
			}
		}
	}
}

static void _print_queue(struct queue_head *head)
{
	struct matrix *m;

	m = &head->matrix;
	if (m->_rel_) {
		_print_row(m);
	} else {
		_print_col(m);
	}

	printf("\n");
	fprintf(stderr, "\n");
}

#undef printf
#else
static void _print_queue(struct queue_head *head)
{
}
#endif

static inline int __find_next_bit_circular__(const unsigned long *a, int b,
											 int c)
{
	uint64_t start = rdtsc();
	int i = find_next_bit_circular(a, b, c);
	find_duration += rdtsc() - start;
	++find_calls;
	return i;
}

#define find_next_bit_circular(a, b, c) __find_next_bit_circular__(a, b, c)

static inline int find_idx(struct matrix *m, int key)
{
	int index;
	/*
	 * overflow: element to far into the future
	 */
	if (key > m->current_key + MAX_ELEMENTS - 1) {
		fprintf(stderr,
				"ERROR %s %d: key to far into the future: key %d, current %d, resolution %d\n",
				__FILE__, __LINE__, key, m->current_key, MAX_ELEMENTS);
		return -1;
	}

	index = (key) & INDEX_MASK;
	return index;
}

static unsigned long *get_bitmap_addr(struct matrix *m, int key)
{
	unsigned long *addr;
	int i;

	i = find_idx(m, key);
	addr = NULL;
	if (i == -1) {
		fprintf(stderr, "OVERFLOW ERROR: %s %d\n", __FILE__, __LINE__);
	} else {
		if (m->_rel_)
			addr = _matrix.row_map[i];
		else
			addr = _matrix.col_map[i];
	}
	return addr;
}

static struct list_head **get_head_entry(struct matrix *m, int key1, int key2)
{
	struct list_head **retval;
	int i, j;

	i = find_idx(m, key1);
	j = find_idx(m, key2);

	retval = NULL;
	if (i != -1 && j != -1) {
		retval = PREF(i, j);
	}

	return retval;
}

static inline void _add_bit(struct matrix *m, int key1, int key2)
{
	if (key1 < m->current_key + MAX_ELEMENTS
		&& key2 < m->current_key + MAX_ELEMENTS) {
		if (m->_rel_) {
			bitmap_set(m->master_map, MAX_ELEMENTS, key1 & INDEX_MASK);
			bitmap_set(_matrix.row_map[key1 & INDEX_MASK], MAX_ELEMENTS,
					   key2 & INDEX_MASK);
			bitmap_set(_matrix.col_map[key2 & INDEX_MASK], MAX_ELEMENTS,
					   key1 & INDEX_MASK);
		} else {
			bitmap_set(m->master_map, MAX_ELEMENTS, key2 & INDEX_MASK);
			bitmap_set(_matrix.col_map[key2 & INDEX_MASK], MAX_ELEMENTS,
					   key1 & INDEX_MASK);
		}
	}
}

static inline struct list_head *_get_entry(struct matrix *m, int key)
{
	struct list_head *retval;
	int i, j;
	unsigned long *addr;
	uint64_t start;

	retval = 0;
	get_calls++;

	start = rdtsc();
	i = find_next_bit_circular(m->master_map, MAX_ELEMENTS, key);

	if (i < MAX_ELEMENTS) {
		addr = get_bitmap_addr(m, i);

		j = find_next_bit_circular(addr, MAX_ELEMENTS, i);
		if (m->_rel_) {			/* release dimension */
			if (j < MAX_ELEMENTS) {
				retval = get_list_head(m, i, j);

				if (!retval) {
					/*
					 * BUG
					 */
					fprintf(stderr,
							"ERROR: %s %d bitmap not matching entries for %s in %d %d\n",
							__FILE__, __LINE__, "blocked", i, j);
					retval = NULL;
				}
			}
		} else {				/* deadline dimension */
			int curr = m->current_key & INDEX_MASK;
			if (j < MAX_ELEMENTS && released(curr, j, i)) {
				retval = get_list_head(m, i, j);

				if (!retval) {
					/*
					 * BUG: bitmap is not matching entries in the matrix
					 */
					fprintf(stderr,
							"ERROR: %s %d bitmap not matching entries for %s in %d %d\n",
							__FILE__, __LINE__, "ready", i, j);
					retval = NULL;
				}
			} else {
				fprintf(stderr,
						"\n\rERROR deadline miss %s:%d: current time %d\n",
						__FILE__, __LINE__, m->current_key);
			}
		}
	}
	get_duration += rdtsc() - start;
	return retval;
}

static int _add(struct queue_head *dest, struct queue_entry *new, int key1,
				int key2)
{
	struct list_head **h;

	add_calls++;

	if (dest->matrix._rel_) {	/* release dimension */
		h = get_head_entry(&dest->matrix, key1, key2);
		if (!h)
			goto out_err;

		new->keys[0] = key1;
		new->keys[1] = key2;
		_add_bit(&dest->matrix, key1, key2);
	} else {					/* deadline dimension */
		h = get_head_entry(&dest->matrix, key2, key1);
		if (!h)
			goto out_err;
		new->keys[1] = key1;
		new->keys[0] = key2;
		_add_bit(&dest->matrix, key2, key1);
	}
	if (*h)
		list_add_tail(*h, &new->list);
	else
		*h = &new->list;

	new->head = dest;
	return 0;

  out_err:
	fprintf(stderr, "ERROR: %s %d OVERFLOW error\n", __FILE__, __LINE__);
	return -1;
}

static struct queue_entry *_get(struct queue_head *head)
{
	struct matrix *m = &head->matrix;
	head->matrix.next_started = -1;
	return (struct queue_entry *)_get_entry(m, m->current_key & INDEX_MASK);
}

static struct queue_entry *_get_key(struct queue_head *head, int key)
{
	struct matrix *m = &head->matrix;
	struct queue_entry *retval;
	retval = (struct queue_entry *)_get_entry(m, key & INDEX_MASK);

	return retval;
}

static inline void _rm_bit(struct matrix *m, int key1, int key2, int empty)
{
	unsigned long *addr;
	int master_key, node_key;

	if (m->_rel_) {
		master_key = key1;
		node_key = key2;
	} else {
		node_key = key1;
		master_key = key2;
	}

	addr = get_bitmap_addr(m, master_key);
	if (addr && empty) {
		bitmap_clear(addr, MAX_ELEMENTS, node_key);
		if (m->_rel_) {
			if (bitmap_empty(addr, MAX_ELEMENTS)) {
				bitmap_clear(m->master_map, MAX_ELEMENTS, master_key);
			}
		} else {
			int i = find_next_bit_circular(addr, MAX_ELEMENTS,
										   (master_key + 1) & INDEX_MASK);
			if (i >= MAX_ELEMENTS
				|| !released(m->current_key & INDEX_MASK, i, master_key)) {
				bitmap_clear(m->master_map, MAX_ELEMENTS, master_key);
			}
		}
	}
}

static int _remove(struct queue_head *head, struct queue_entry *entry)
{
	struct list_head *addr, **paddr;
	int key1, key2, empty;

	remove_calls++;

	key1 = entry->keys[0] & INDEX_MASK;
	key2 = entry->keys[1] & INDEX_MASK;

	paddr = PREF(key1, key2);
	addr = *paddr;
	empty = 0;
	if (addr == &entry->list) {
		if (list_empty(&entry->list)) {
			empty = 1;
			delete(key1, key2);
		} else
			*paddr = entry->list.next;
	}

	list_del_init(&entry->list);
	_rm_bit(&head->matrix, key1, key2, empty);
	entry->head = NULL;
	return 0;
}

/*
 * only used by the simulation yet. not performance critical
 */
static struct queue_entry *_get_next_entry(struct queue_head *head,
										   struct queue_entry *entry)
{
	struct queue_entry *retval;
	struct list_head *list;
	unsigned long *addr;
	int key1, _key1, key2, next, curr;

	if (list_empty(&entry->list))
		return NULL;

	retval = 0;

	if (head->matrix._rel_) {
		_key1 = entry->keys[0];
		key1 = entry->keys[0] & INDEX_MASK;
		key2 = entry->keys[1] & INDEX_MASK;
	} else {
		_key1 = entry->keys[1];
		key1 = entry->keys[1] & INDEX_MASK;
		key2 = entry->keys[0] & INDEX_MASK;
	}

	addr = get_bitmap_addr(&head->matrix, key1);
	next = find_next_bit_circular(addr, MAX_ELEMENTS, (key2 + 1) & INDEX_MASK);

	if (head->matrix.next_started == -1) {
		head->matrix.next_started = key2;
	}

	curr = head->matrix.current_key & INDEX_MASK;
	if (head->matrix._rel_) {
		if (next == head->matrix.next_started) {	/* ending up in the same
													 * list */
			next = MAX_ELEMENTS;
		}
	} else {
		if (next == head->matrix.next_started	/* ending up in the same list */
			|| !released(curr, next, key1)) {
			next = MAX_ELEMENTS;
		}
	}

	list = get_list_head(&head->matrix, key1, key2);
	if (entry->list.next != list) {
		retval = (struct queue_entry *)entry->list.next;
		retval->head = head;
	} else if (next != MAX_ELEMENTS) {
		list = get_list_head(&head->matrix, key1, next);
		if (!list) {
			fprintf(stderr, "ERROR: %s %d bitmap not matching matrix\n",
					__FILE__, __LINE__);
		} else {
			retval = (struct queue_entry *)list;
			retval->head = head;
		}
	} else {
		int i;
		head->matrix.next_started = -1;
		i = find_next_bit_circular(head->matrix.master_map, MAX_ELEMENTS,
								   (key1 + 1) & INDEX_MASK);
		if (i < MAX_ELEMENTS && i != key1) {
			retval = (struct queue_entry *)_get_entry(&head->matrix, i);
			if (retval) {
				retval->head = head;
			}
		}
	}
	return retval;
}

static int _move(struct queue_head *dest, struct queue_head *src, int key,
				 int (*op) (struct queue_entry *))
{
	int key1;
	struct matrix *md, *ms;
	unsigned long *addr;

	md = &dest->matrix;
	ms = &src->matrix;

	sched_calls++;
	key1 = key & INDEX_MASK;
	addr = get_bitmap_addr(ms, key1);
	if (addr) {
		if (test_bit(key1, ms->master_map)) {
			/*
			 * this if statement increases the standard deviation
			 * and changes the complexity from Theta to big O. however, on 
			 * average it improves the performance by a factor of 2 
			 */
			bitmap_or(md->master_map, md->master_map, addr, MAX_ELEMENTS);
			bitmap_zero(addr, MAX_ELEMENTS);
			bitmap_clear(ms->master_map, MAX_ELEMENTS, key1);
		}
	} else {
		fprintf(stderr, "ERROR %s %d: could not move bitmaps\n", __FILE__,
				__LINE__);
		return -1;
	}
	return 0;
}

static void set_current_key(struct queue_head *head, int key)
{
	head->matrix.current_key = key;
}

void queue_entry_init(struct queue_entry *entry)
{
	INIT_LIST_HEAD(&entry->list);
	entry->keys[0] = -1;
	entry->keys[1] = -1;
	entry->head = NULL;
}

static inline void init_matrix()
{
	int i;
	init();

	for (i = 0; i < MAX_ELEMENTS; ++i) {
		bitmap_zero(_matrix.row_map[i], MAX_ELEMENTS);
		bitmap_zero(_matrix.col_map[i], MAX_ELEMENTS);
	}
}

void queue_head_init(struct queue_head *head)
{
	struct matrix *m;
	static int is_init = 0;
	static unsigned int _rel_ = 0;

	if (!is_init) {
		is_init = 1;
		init_matrix();
	}

	m = &head->matrix;
	memset(m, 0, sizeof(struct matrix));
	bitmap_zero(m->master_map, MAX_ELEMENTS);
	m->_rel_ = _rel_++ & 0x1;
	m->current_key = -1;
	m->next_started = -1;

	head->add = _add;
	head->remove = _remove;
	head->get = _get;
	head->get_key = _get_key;
	head->move = _move;
	head->get_next = _get_next_entry;
	head->set_current_key = set_current_key;
	head->mem_usage = get_mem_usage;
	head->alloc_count = get_alloc_count;
	head->print_queue = _print_queue;
}
