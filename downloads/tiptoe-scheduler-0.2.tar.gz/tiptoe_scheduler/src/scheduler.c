/*
 *  The Tiptoe Project
 *  Copyright (c) Silviu Craciunas (scraciunas@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include "process.h"
#include "scheduler.h"
#include "workqueue.h"
#include "generic.h"

#ifndef SCHEDULER_STRATEGY
#define SCHEDULER_STRATEGY 2
#endif /* SCHEDULER_STRATEGY */

#define OVERLOAD_OK       0
#define OVERLOAD_OVERLOAD 1

static struct Process *current;
static struct Process *idle;
static int overload;

struct Process *sched_get_current()
{
	return current;
}

static inline int set_current(struct Process *p)
{
	int retval;
	if (p != NULL) {
		current = p;
		retval = 0;
	} else
		retval = -1;

	return retval;
}

int sched_get_idle_pid()
{
	return idle->pid;
}

int sched_overload()
{
	return overload != 0;
}

/**
 * scheduler_init
 * @policy: system class.
 *
 */
int sched_init()
{
	/*
	 * init idle task 
	 */
	idle = (struct Process *)malloc(sizeof(struct Process));
	if (idle == NULL) {
		printf("unable to allocate memory\n");
		perror("malloc");
		exit(EXIT_FAILURE);		/* out of memory */
	}

	set_pid(idle, 0);
	idle->run_time = 0;
	current = idle;

	wqueue_init();
	return 0;
}

/**
 * calculate_min
 * @policy: scheduling class.
 *
 * search minimum of 3 values with priorities
 */
static int calculate_min(int i1, int i2, int i3)
{
	int min;
	min = i1;
	if (i2 < min)
		min = i2;
	if (i3 < min)
		min = i3;

	return min;
}

/**
 * shaper
 * @policy: scheduling class.
 *
 */
static void calculate_supply_load(struct Process *p, int value, int time)
{
	int period;
	int current_supply;

	period = get_process_period(p);

	log("Time [%d] | shaper_load(%d,%d,%d) \n", time, get_pid(p),
			value, time);
	current_supply = get_process_supply(p);
	set_process_supply(p, current_supply - value);
	if (time % period != 0)
		set_process_instant(p, time / period);

}

static void calculate_supply_new(struct Process *p, int value, int time)
{
	int period;

	period = get_process_period(p);

	log("Time [%d] | shaper_new(%d,%d,%d) \n", time, get_pid(p), 
			value, time);
	set_process_supply(p, get_process_limit(p));
	set_process_instant(p, time / period);
}

static int calculate_supply_remaining(struct Process *p, int value, int time)
{
	int period;
	int remaining_period;
	int fraction_remaining;
	int current_instant;

	period = get_process_period(p);

	current_instant = time / period;

	if (time < period) {
		remaining_period = period - time;
	} else {
		remaining_period = (current_instant + 1) * period - time;
	}
	fraction_remaining = (get_process_limit(p) * remaining_period) / period;

	set_process_supply(p, fraction_remaining);
	set_process_instant(p, current_instant);
	
	return fraction_remaining;
}

/**
 * calculate_release
 * @policy: scheduling class.
 *
 * calculate new release
 */
static int calculate_release(struct Process *p, int time)
{
	log("Time [%d] | calculate_release(%d,%d) \n", time, get_pid(p), time);
	int release;

	if(time % get_process_period(p) == 0)
		release = time;
	else
		release = (time / get_process_period(p) + 1) * get_process_period(p);

	return release;
}

/**
 * calculate_deadline
 * @policy: scheduling class.
 *
 * calculate new deadline
 */
static int calculate_deadline(struct Process *p, int time)
{
	int deadline;
	log("Time [%d] | calculate_deadline(%d,%d) \n", time, get_pid(p), time);

	deadline = (time / get_process_period(p) + 1) * get_process_period(p);
	log("PROCESS [%d] | deadline [%d]\n", get_pid(p), deadline);
	return deadline;
}

/**
 * check_deadline
 * @policy: scheduling class.
 *
 * checks if the deadline has been missed
 */
static int check_deadline(struct Process *p, int time)
{
	if (p != NULL)
		/*
		 * did we meet the deadline?
		 */
		if (get_process_deadline(p) < time) {
			/*
			 * oops, resource utilization was too high
			 */
			log("ERROR: %d\n", 1);
			return 1;
		}
	return 0;
}

static inline void block_process(struct Process *p, int time)
{
	int release, deadline;

	log("Time [%d] | block_process(%d,%d) \n", time, get_pid(p), time);
	calculate_supply_new(p, 0, time);
	release = calculate_release(p, time);
	deadline = calculate_deadline(p, release);
	set_process_state(p, TASK_STATE_BLOCKED);
	wqueue_reschedule(p, release, deadline);
}

#if SCHEDULER_STRATEGY == 1
static void strategy(struct Process *p, int time)
{
	set_process_supply(p, 0);
	block_process(p, time);
}
#elif SCHEDULER_STRATEGY == 2
static void strategy(struct Process *p, int time)
{
	int new_deadline;
	int new_supply;

	log("Time [%d] | strategy(%d,%d) \n", time, get_pid(p), time);
	new_supply = calculate_supply_remaining(p, 0, time);

	if(new_supply == 0) {
		block_process(p, time);
	} else {
		new_deadline = calculate_deadline(p, time);
		set_process_state(p, TASK_STATE_BLOCKED);
		wqueue_reschedule(p, time, new_deadline);
	}
}
#elif SCHEDULER_STRATEGY == 3
static void strategy(struct Process *p, int time)
{
	int period;
	int deadline, wasted_time;
	int load;
	load = get_process_limit(p);
	period = get_process_period(p);
	if (get_process_instant(p) == time / period) {
		load -= get_process_supply(p);
		wasted_time = time - (time / period) * period;
		wasted_time -= load;
	} else {
		wasted_time = time - (time / period) * period;
	}
	deadline = (time / period + 1) * period + wasted_time;

	set_process_supply(p, load);
}
#else
#error unknown scheduler strategy
#endif /* SCHEDULER_STRATEGY */

static void change_state(struct Process *p, int time)
{
	log("Time [%d] | change_state(%d,%d) \n", time, get_pid(p), time);
	strategy(p, time);
}

static void reschedule(struct Process *p, int time)
{
	if (check_deadline(p, time)) {
		overload = OVERLOAD_OVERLOAD;
		fprintf(stderr,
				"WARNING %s %d: overload set while rescheduling %d at %d\n",
				__FILE__, __LINE__, p->pid, time);
	}


	/*
	 * last run process preempted with release time
	 */
	if (get_process_run_type(p) == TASK_RUN_RELEASE) {
		int new_deadline;
		/*
		 * calculate remaining load
		 */
		sub_process_load(p, get_process_run_time(p));

		calculate_supply_load(p, get_process_run_time(p), time);
		new_deadline = calculate_deadline(p, time);
		set_process_state(p, TASK_STATE_READY);
		wqueue_reschedule(p, 0, new_deadline);
	} else if (get_process_run_type(p) == TASK_RUN_COMPLETION) {
		log("Time [%d] | completion \n", time);

		/*
		 * last run process preempted with completion
		 */
		int new_state;

		calculate_supply_load(p, p->run_time, time);
		int previous_period = get_process_period(p);
		/*
		 * go to next process state
		 */
		new_state = set_next_process_state(p);

		/*
		 * check that the process is not finished
		 */
		if (new_state != PROCESS_STATE_FINISHED) {
			if (new_state == PROCESS_STATE_DIFFERENT) {
				int end_previous_period;
				
				if(time % previous_period == 0)
					end_previous_period = time;
				else
					end_previous_period = (time / previous_period + 1) * previous_period;
				calculate_average_response_time(p, end_previous_period);
				change_state(p, end_previous_period);
			} else {
				if (get_process_supply(p) > 0) {
					int new_deadline;
					new_deadline = calculate_deadline(p, time);
					set_process_state(p, TASK_STATE_READY);
					wqueue_reschedule(p, 0, new_deadline);
				} else {
					block_process(p, time);
				}
			}
		} else {
			/* FIXME: clean up process struct */
		}
	} else {
		/*
		 * last run process preempted with supply
		 */
		if (get_process_run_type(p) == TASK_RUN_SUPPLY) {
			int load;

			/*
			 * update load
			 */
			load = get_process_run_time(p);
			sub_process_load(p, load);

			block_process(p, time);
		}
	}
	if (overload)
		fprintf(stderr, "new deadline %d\n", get_process_deadline(p));
	
}

/**
 * scheduler
 *
 * main scheduler function
 *
 */
int scheduler(int time)
{
	struct Process *current = sched_get_current();
	struct Process *next_ready_proc, *next_blocked_proc;
	int released;
	/*
	 * reset overload information, for soft recovery
	 */
	overload = OVERLOAD_OK;

	/*
	 * check that everything is ok with the last run process
	 */
	if (current == idle && get_process_run_type(current) != TASK_RUN_IDLE) {
		exit(2);
	}
	log("current process is %d \n", get_pid(current));

	if (current != idle)
		reschedule(current, time);

	/*
	 * see if there are any processes on the blocked queue with release = now
	 */
	released = wqueue_advance(time);

	next_ready_proc = wqueue_get_ready();
	next_blocked_proc = wqueue_get_blocked();

	if (!next_ready_proc) {
		/*
		 * calculate idle time
		 */
		set_current(idle);
		if (next_blocked_proc) {
			int idle_time = get_process_release(next_blocked_proc) - time;
			set_process_run_time(idle, idle_time);
			fprintf(stderr, "[%d] idle for %d next pid %d\n", time, idle_time,
					next_blocked_proc->pid);
		} else {
			/*
			 * no processes in the blocked or in the ready => system is
			 * finished
			 */
			printf("no more processes!\n");
			return -1;
		}

		set_process_run_type(sched_get_current(), TASK_RUN_IDLE);
	} else {
		int min_time, time_release, time_load, time_supply;

		/*
		 * order is important
		 */
		time_load = time + get_process_load(next_ready_proc);

		time_supply = time + get_process_supply(next_ready_proc);
		log("SYSTEM [%d] | time load[%d] time supply[%d]\n", time,
			time_load, time_supply);

		if (!next_blocked_proc) {
			if (time_load <= time_supply)
				min_time = time_load;
			else
				min_time = time_supply;
			time_release = 0;
		} else {
			time_release = get_process_release(next_blocked_proc);
			min_time = calculate_min(time_load, time_supply, time_release);
		}

		if (min_time == time_load) {
			set_process_run_type(next_ready_proc, TASK_RUN_COMPLETION);
		} else if (min_time == time_supply) {
			set_process_run_type(next_ready_proc, TASK_RUN_SUPPLY);
		} else if (min_time == time_release) {
			set_process_run_type(next_ready_proc, TASK_RUN_RELEASE);
		}

		if (min_time <= time) {
			fprintf(stderr, "ERROR %s %d: invalid runtime %d\n", __FILE__,
					__LINE__, min_time - time);
			min_time = time + 1;
		}

		set_process_run_time(next_ready_proc, min_time - time);

		log("SYSTEM [%d] | running [%d] for time [%d]\n", time,
			get_pid(next_ready_proc), get_process_run_time(next_ready_proc));

		set_process_state(next_ready_proc, TASK_STATE_RUNNING);
		set_current(next_ready_proc);

	}
	return released;
}

// ex: ts=4 sw=4
