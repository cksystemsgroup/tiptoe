/*
 *  The Tiptoe Project
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef QUEUE_H
#define QUEUE_H

#define INDEX_BITS    14
#define MAX_ELEMENTS (1<<INDEX_BITS)
#define INDEX_MASK (MAX_ELEMENTS-1)

#include "queues/array.h"
#include "queues/list.h"
#include "queues/matrix.h"

struct queue_head;

struct queue_entry
{
	struct list_head list;
	union
	{
		unsigned int key;
		unsigned int keys[2]; /* for the matrix we need two keys per entry */
	};
	struct queue_head *head;
};

/*
 * maintain a queue sorted by keys
 */
struct queue_head
{
	union
	{
		DECLARE_LIST_HEAD(list);
		DECLARE_ARRAY_HEAD(array);
		DECLARE_MATRIX_HEAD(matrix);
	};
	/*
	 * adds an element with key 
	 */
	int (*add) (struct queue_head * dest, struct queue_entry * new, int key1,
				int key2);
	/*
	 * removes an entry 
	 */
	int (*remove) (struct queue_head * head, struct queue_entry * entry);
	/*
	 * returns the first element in the queue or NULL if queue is empty; does
	 * not remove the entry from the queue 
	 */
	struct queue_entry *(*get) (struct queue_head * head);
	/*
	 * returns the first entry with key "key" in the queue or NULL if the queue 
	 * is empty or there is no entry with this key 
	 */
	struct queue_entry *(*get_key) (struct queue_head * head, int key);
	/*
	 * moves all elements with key "key" from the queue src to queue dest.
	 * calls an "op" function for each element moved. the op function shall
	 * return the new key that is used to insert the entry in the destination
	 * queue. 
	 */
	int (*move) (struct queue_head * dest, struct queue_head * src, int key,
				 int (*op) (struct queue_entry *));

	/*
	 * returns the next element in the queue after entry "entry" Note: if
	 * entry is the last element in the queue, the next element is the first
	 * entry in the queue (i.e. circular iterator) 
	 */
	struct queue_entry *(*get_next) (struct queue_head * head,
									 struct queue_entry * entry);

	/*
	 * advance internal start time to "key" and update meta data 
	 */
	void (*set_current_key) (struct queue_head * head, int key);

	/* get some statistics */
	long (*mem_usage)();
	int (*alloc_count)();
	/* debug function */
	void (*print_queue)(struct queue_head *head);
};

/* init functions */
extern void queue_entry_init(struct queue_entry *entry);
extern void queue_head_init(struct queue_head *head);
#endif
