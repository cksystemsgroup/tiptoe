/*
 *  The Tiptoe Project
 *  Copyright (c) Harald Roeck (hroeck@cs.uni-salzburg.at)
 *
 *  University Salzburg, www.uni-salzburg.at
 *  Department of Computer Science, cs.uni-salzburg.at
 *
 *  This project is funded by the Austrian Science Fund project nummer P18913
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#ifndef WORKQUEUE_H
#define WORKQUEUE_H
/*
 * Defines the interface the scheduler uses to
 * manage its ready and blocked queue.
 */

struct Process;
/*
 * add a process to the run queue
 */
void wqueue_add(struct Process *p);
/*
 * remove a process from the system
 */
void wqueue_remove(struct Process *p);

/*
 * reschedule the currently running process
 * if release is 0 we do not change the release
 * time only the deadline
 * if release is not 0 the process has to be in the
 * blocked state
 */
int wqueue_reschedule(struct Process *p, int release, int deadline);

/*
 * returns the first process in the ready queue.
 * or NULL if the queue is empty
 * Note: the process is not removed from the queue
 */
struct Process *wqueue_get_ready();

/*
 * returns the first process in the blocked queue
 * or NULL if the queue is empty
 * Note: the process is not removed from the queue
 */
struct Process *wqueue_get_blocked();

/*
 * advance time of the workqueue to time.
 * do all necessary bookkeeping, e.g.,
 * release process with a release time <= time.
 */
int wqueue_advance(int time);

/*
 * get the next process after p in the queue
 * returns NULL if p is not in a queue.
 * returns the first element if p is the last entry in the queue
 */
struct Process *wqueue_get_next(struct Process *p);
/*
 * initialize the workqueue data structures
 */
void wqueue_init();

long wqueue_to_release(long key);

/* statistics */
long wqueue_mem_usage();
int wqueue_alloc_count();

#endif /* WORKQUEUE_H */
