/* Copyright (c) 2010 Andreas Haas, Stephanie Stroka
 *
 * http://cs.uni-salzburg.at/~ahaas
 * andreas.haas@sbg.ac.at
 *
 * http://cs.uni-salzburg.at/~sstroka
 * stephanie.stroka@sbg.ac.at
 * 
 * University Salzburg, www.uni-salzburg.at
 * Department of Computer Sciences, cs.uni-salzburg.at
 *
 * 
 * This file is licensed to You under the Eclipse Public License (EPL); You may
 * not use this file except in compliance with the License. You may obtain a
 * copy of the License at
 * 
 * http://www.opensource.org/licenses/eclipse-1.0.php
 */

public class TestProgram
{
	int value;
	
	public static void main(String[] args)
	{
        for(int i = 0; i < 200000; i++)
        {
      		TestProgram program = new TestProgram();
      		Runtime.getRuntime().refreshObject(program, 0);
      		// use program
            Runtime.getRuntime().tick();
		}
		
		System.out.println("Finished");
	}
}
